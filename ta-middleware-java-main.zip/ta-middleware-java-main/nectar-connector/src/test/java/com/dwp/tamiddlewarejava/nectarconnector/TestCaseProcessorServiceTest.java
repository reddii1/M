package com.dwp.tamiddlewarejava.nectarconnector;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.time.Instant;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.nectarconnector.service.testcaseprocessor.TestCaseProcessorService;
import com.dwp.tamiddlewarejava.nectarconnector.service.testrecord.ActiveRecordService;
import com.dwp.tamiddlewarejava.nectarconnector.service.testrecord.ExpiredRecordService;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

class TestCaseProcessorServiceTest {

  @Mock private ActiveRecordService activeRecordService;

  @Mock private ExpiredRecordService expiredRecordService;

  @Mock private TestCaseOperationsService testCaseOperationsService;

  @Mock private Logger logger;

  @InjectMocks private TestCaseProcessorService nectarProcessorService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    nectarProcessorService =
        new TestCaseProcessorService(
            expiredRecordService, testCaseOperationsService, activeRecordService);
  }

  @Test
  void whenTestCaseIsExpired_thenHandleExpiredRecord() {
    TestCase testCase = new TestCase();
    testCase.setRequestTime(Timestamp.from(Instant.now().minusSeconds(3600)));
    testCase.setOrchestrationStatus(OrchestrationStatusEnum.NEW.toString());
    Instant expiry = Instant.now().minusSeconds(1800);

    nectarProcessorService.processTestCase(testCase, expiry);

    verify(expiredRecordService)
        .handleExpiredRecord(eq(testCase), any(ConnectorData.class), any(Timestamp.class));
  }

  @Test
  void whenTestCaseIsNotExpired_thenHandleActiveRecord() {
    TestCase testCase = new TestCase();
    testCase.setRequestTime(Timestamp.from(Instant.now().minusSeconds(1800)));
    testCase.setOrchestrationStatus(OrchestrationStatusEnum.NEW.toString());
    Instant expiry = Instant.now().minusSeconds(3600);

    nectarProcessorService.processTestCase(testCase, expiry);

    verify(activeRecordService).handleActiveRecord(eq(testCase), any(ConnectorData.class));
  }
}
