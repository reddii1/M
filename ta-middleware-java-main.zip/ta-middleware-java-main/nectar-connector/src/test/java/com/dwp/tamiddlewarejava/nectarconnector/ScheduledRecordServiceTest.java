package com.dwp.tamiddlewarejava.nectarconnector;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.util.ReflectionTestUtils;

import com.dwp.tamiddlewarejava.nectarconnector.config.NectarClientConfig;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.TestCaseRunResultData;
import com.dwp.tamiddlewarejava.nectarconnector.service.client.ClientService;
import com.dwp.tamiddlewarejava.nectarconnector.service.testrecord.ScheduledRecordService;
import com.dwp.tamiddlewarejava.nectarconnector.utils.NectarUtils;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

class ScheduledRecordServiceTest {

  @Mock private Logger logger;

  @Mock private HostOperationsService hostOperationsService;
  @Mock private TestCaseOperationsService testCaseOperationsService;
  @Mock private NectarUtils nectarUtils;
  @Mock private NectarClientConfig nectarClientConfig;
  @Mock private ClientService nectarClient;

  @InjectMocks private ScheduledRecordService scheduledRecordService;

  private TestCase testCase;
  private ConnectorData data;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    testCase = new TestCase();
    data = new ConnectorData();

    when(nectarClientConfig.createNectarClient(anyString(), anyString(), anyString()))
        .thenReturn(nectarClient);
    when(hostOperationsService.getHostCredentials(anyString()))
        .thenReturn(new HostCredentials("username", "password"));

    ReflectionTestUtils.setField(scheduledRecordService, "nectarBaseUrl", "http://test");
  }

  @Test
  void whenExecutionIdIsNull_shouldNotProceedWithRunResultRetrieval() {
    data.setExecutionId(null);

    scheduledRecordService.handleScheduledRecord(testCase, data);

    verifyNoInteractions(nectarClient);
  }

  @Test
  void whenExecutionIdIsNotEmpty_shouldRetrieveRunResult() throws Exception {
    data.setExecutionId("1234");
    when(nectarClient.getRunResult(anyString()))
        .thenReturn(new TestCaseRunResultData("SUCCESS", "", "", ""));

    scheduledRecordService.handleScheduledRecord(testCase, data);

    verify(nectarClient).getRunResult("1234");
  }

  @Test
  void whenRunResultIsContinue_shouldNotUpdateTestCase() throws Exception {
    data.setExecutionId("1234");
    when(nectarClient.getRunResult(anyString()))
        .thenReturn(new TestCaseRunResultData("CONTINUE", "", "", ""));

    scheduledRecordService.handleScheduledRecord(testCase, data);

    verify(testCaseOperationsService, never())
        .updateNectarExecuted(
            eq(testCase.getId()),
            anyString(),
            anyString(),
            anyString(),
            anyLong(),
            any(Timestamp.class));
    ;
  }

  @Test
  void whenRunResultIsNotContinue_shouldUpdateTestCase() throws Exception {
    data.setExecutionId("1234");
    when(nectarClient.getRunResult(anyString()))
        .thenReturn(new TestCaseRunResultData("SUCCESS", "Message", "1", "2022-01-01T00:00:00Z"));
    when(nectarUtils.getTestOutcome(anyString())).thenReturn(TestOutcomeEnum.PASSED.toString());
    when(nectarUtils.parseResultStartTimeToTimestamp(anyString()))
        .thenReturn(new Timestamp(new Date().getTime()));

    scheduledRecordService.handleScheduledRecord(testCase, data);

    verify(testCaseOperationsService)
        .updateNectarExecuted(
            eq(testCase.getId()),
            anyString(),
            anyString(),
            anyString(),
            anyLong(),
            any(Timestamp.class));
  }

  @Test
  void whenExceptionOccurs_shouldLogError() {
    data.setExecutionId("1234");

    try {
      when(nectarClient.getRunResult(anyString())).thenThrow(new RuntimeException("Failure"));

      scheduledRecordService.handleScheduledRecord(testCase, data);
    } catch (Exception e) {
      logger.error("Error performing Nectar Scheduled Record test for when exception occurs");
    }
  }
}
