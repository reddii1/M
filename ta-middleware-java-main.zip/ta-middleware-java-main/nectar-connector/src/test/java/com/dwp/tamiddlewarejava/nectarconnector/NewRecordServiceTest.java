package com.dwp.tamiddlewarejava.nectarconnector;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.dwp.tamiddlewarejava.nectarconnector.config.NectarClientConfig;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.nectarconnector.service.client.ClientService;
import com.dwp.tamiddlewarejava.nectarconnector.service.testrecord.NewRecordService;
import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.host.Host;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

class NewRecordServiceTest {

  @Mock private Logger logger;
  @Mock private HostOperationsService hostOperationsService;
  @Mock private TestCaseOperationsService testCaseOperationsService;
  @Mock private NectarClientConfig nectarClientConfig;
  @Mock private ClientService nectarClient;

  @InjectMocks private NewRecordService newRecordService;

  private TestCase testCase;
  private ConnectorData data;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    testCase = new TestCase();
    data = new ConnectorData();
    when(nectarClientConfig.createNectarClient(anyString(), anyString(), anyString()))
        .thenReturn(nectarClient);
  }

  @Test
  void whenHostDoesNotExist_thenUpdateTestCaseStatusToMWHostDoesNotExist() {
    when(hostOperationsService.selectHost(anyString(), anyString())).thenReturn(null);

    newRecordService.handleNewRecord(testCase, data);

    verify(testCaseOperationsService)
        .updateStatusAndOutcome(
            eq(testCase.getId()),
            eq(OrchestrationStatusEnum.EXECUTED.toString()),
            eq(TestOutcomeEnum.MW_HOST_DOES_NOT_EXIST.toString()),
            any(Timestamp.class));
  }

  @Test
  void whenHostIsNotAvailable_thenDoNotProceed() {
    Host host = new Host();
    host.setHostStatus(HostStateEnum.EXECUTING.toString());
    when(hostOperationsService.selectHost(anyString(), anyString())).thenReturn(host);

    newRecordService.handleNewRecord(testCase, data);

    verifyNoInteractions(nectarClient);
  }
}
