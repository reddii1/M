package com.dwp.tamiddlewarejava.nectarconnector;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ScheduledTestCase;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.TestCaseRunResultData;
import com.dwp.tamiddlewarejava.nectarconnector.service.client.ClientService;
import com.dwp.tamiddlewarejava.shared.utils.EncryptionUtil;

class ClientServiceTest {

  @Mock private HttpClient mockHttpClient;

  @Mock private HttpResponse<String> mockResponse;

  private ClientService client;
  private String encryptedPassword;

  @BeforeEach
  void setUp() throws Exception {
    MockitoAnnotations.openMocks(this);

    String secretKey = "fvrbwtbefgwefrv42342352";
    String passwordToEncrypt = "plainPassword";
    encryptedPassword = EncryptionUtil.encryptPassword(passwordToEncrypt, secretKey);

    client = new ClientService("http://baseUrl", "username", encryptedPassword);
    ReflectionTestUtils.setField(client, "hostsPasswordEncryptionKey", "fvrbwtbefgwefrv42342352");
    ReflectionTestUtils.setField(client, "shouldRetryRequest", false);

    Field httpClientField = ClientService.class.getDeclaredField("httpClient");
    httpClientField.setAccessible(true);
    httpClientField.set(client, mockHttpClient);

    when(mockHttpClient.send(
            any(HttpRequest.class), any(HttpResponse.BodyHandlers.ofString().getClass())))
        .thenReturn(mockResponse);

    when(mockResponse.body()).thenReturn("expected jsonResponse");
    when(mockResponse.statusCode()).thenReturn(200);
  }

  @Test
  void shouldCorrectlyReturnScheduledTestCaseDetailsWhenQuickScheduling() throws Exception {
    String jsonResponse =
        "{\"executionId\":\"123\",\"nextRunTime\":\"2024-10-31T01:48:52Z\",\"scheduled\":false}";
    when(mockResponse.body()).thenReturn(jsonResponse);
    when(mockResponse.statusCode()).thenReturn(200);

    ScheduledTestCase expectedTestCase =
        new ScheduledTestCase("123", "2024-10-31T01:48:52Z", false);

    ScheduledTestCase result = client.quickScheduleTestCase("123", "123456789", "987654321");

    assertNotNull(result);

    assertAll(
        "Result should match expected data",
        () ->
            assertEquals(
                expectedTestCase.getExecutionId(),
                result.getExecutionId(),
                "Execution ID should match"),
        () ->
            assertEquals(
                expectedTestCase.getNextRunTime(),
                result.getNextRunTime(),
                "Next Run Time should match"),
        () ->
            assertEquals(
                expectedTestCase.isScheduled(),
                result.isScheduled(),
                "Scheduled value should match"));
  }

  @Test
  void shouldCorrectlyReturnRunResultDataWhenRequested() throws Exception {
    String jsonResponse =
        "{\"totalRecords\": 1,\"data\":[{\"result\":\"SUCCESS\",\"message\":\"Run result is successful\",\"duration\":\"1104356\",\"startTime\":\"01-01-2024\"}]}";
    when(mockResponse.body()).thenReturn(jsonResponse);
    when(mockResponse.statusCode()).thenReturn(200);

    TestCaseRunResultData expectedData =
        new TestCaseRunResultData("SUCCESS", "Run result is successful", "1104356", "01-01-2024");

    TestCaseRunResultData result = client.getRunResult("123");

    assertNotNull(result);

    assertAll(
        "Result should match expected data",
        () -> assertEquals(expectedData.getResult(), result.getResult(), "Results should match"),
        () -> assertEquals(expectedData.getMessage(), result.getMessage(), "Messages should match"),
        () ->
            assertEquals(
                expectedData.getDuration(), result.getDuration(), "Durations should match"),
        () ->
            assertEquals(
                expectedData.getStartTime(), result.getStartTime(), "Start times should match"));
  }
}
