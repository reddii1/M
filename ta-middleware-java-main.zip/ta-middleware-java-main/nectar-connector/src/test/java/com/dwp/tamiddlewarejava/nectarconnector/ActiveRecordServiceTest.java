package com.dwp.tamiddlewarejava.nectarconnector;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.util.ReflectionTestUtils;

import com.dwp.tamiddlewarejava.nectarconnector.model.enums.TestRecordStateEnum;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.nectarconnector.service.testrecord.ActiveRecordService;
import com.dwp.tamiddlewarejava.nectarconnector.service.testrecord.NewRecordService;
import com.dwp.tamiddlewarejava.nectarconnector.service.testrecord.ScheduledRecordService;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;

class ActiveRecordServiceTest {

  @Mock private NewRecordService newRecordService;

  @Mock private HostOperationsService hostOperationsService;

  @Mock private ScheduledRecordService scheduledRecordService;

  @Mock private Logger logger;

  @InjectMocks private ActiveRecordService activeRecordService;

  private TestCase testCase;
  private ConnectorData data;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    testCase = new TestCase();
    data = new ConnectorData();

    activeRecordService =
        new ActiveRecordService(newRecordService, hostOperationsService, scheduledRecordService);

    ReflectionTestUtils.setField(activeRecordService, "maxStartAttempts", 3);
  }

  @Test
  void whenStateIsEmpty_thenHandleNewRecordIsInvoked() {
    data.setState("");

    activeRecordService.handleActiveRecord(testCase, data);

    verify(newRecordService).handleNewRecord(testCase, data);
  }

  @Test
  void whenStateIsScheduled_thenHandleFinalizingIsInvoked() {
    data.setState(TestRecordStateEnum.SCHEDULED.toString());

    activeRecordService.handleActiveRecord(testCase, data);

    verify(scheduledRecordService).handleScheduledRecord(testCase, data);
  }

  @Test
  void whenStartAttemptsExceedMax_AndStateIsEmpty_thenFailTestAndReleaseHostIsInvoked() {
    testCase.setStartAttempts(4);
    data.setState("");

    activeRecordService.handleActiveRecord(testCase, data);

    verify(hostOperationsService)
        .failTestAndReleaseHost(eq(testCase), eq(data.getHost()), anyString());
  }
}
