package com.dwp.tamiddlewarejava.nectarconnector.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.dwp.tamiddlewarejava.nectarconnector.service.client.ClientService;

@Configuration
public class NectarClientConfig {

  @Value("${host.encryptionkey}")
  private String hostsPasswordEncryptionKey;

  @Value("${nectar.retry}")
  private Boolean shouldRetryRequest;

  public ClientService createNectarClient(String baseUrl, String username, String password) {
    ClientService client = new ClientService(baseUrl, username, password);
    client.setHostsPasswordEncryptionKey(this.hostsPasswordEncryptionKey);
    client.setShouldRetryRequest(this.shouldRetryRequest);
    return client;
  }
}
