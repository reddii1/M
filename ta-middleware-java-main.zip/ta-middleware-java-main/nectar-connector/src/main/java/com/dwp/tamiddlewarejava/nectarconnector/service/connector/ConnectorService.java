package com.dwp.tamiddlewarejava.nectarconnector.service.connector;

import java.time.Instant;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.nectarconnector.service.testcaseprocessor.TestCaseProcessorService;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.repository.TestCaseRepository;
import com.dwp.tamiddlewarejava.shared.utils.TimeUtil;

@Service
public class ConnectorService {

  private static final Logger logger = LoggerFactory.getLogger(ConnectorService.class);
  private TestCaseRepository testCaseRepository;
  private TestCaseProcessorService testCaseProcessorService;
  private @Value("${TIMEOUT_HOURS:24}") Integer timeoutHours;

  public ConnectorService(
      TestCaseRepository testCaseRepository, TestCaseProcessorService testCaseProcessorService) {
    this.testCaseRepository = testCaseRepository;
    this.testCaseProcessorService = testCaseProcessorService;
  }

  /** Periodically fetches and processes Nectar test cases from the repository every 5 seconds. */
  @Scheduled(fixedRate = 5000)
  public void connector() {
    List<TestCase> testCases = fetchTestCases();
    Instant expiry = TimeUtil.calculateExpiry(timeoutHours);

    if (!testCases.isEmpty()) {
      for (TestCase testCase : testCases) {
        try {
          MDC.put("testCaseRecordId", testCase.getId().toString());
          testCaseProcessorService.processTestCase(testCase, expiry);
        } finally {
          MDC.clear();
        }
      }
    }
  }

  /**
   * Fetches test cases associated with the "Nectar" test provider from the repository.
   *
   * @return A list of test cases for the "Nectar" provider, or an empty list if an error occurs or
   *     no cases are found.
   */
  private List<TestCase> fetchTestCases() {
    try {
      return testCaseRepository.getTestProviderTestCases("Nectar");
    } catch (Exception e) {
      logger.error("Error fetching Nectar records", e);
      return Collections.emptyList(); // Return an empty list to avoid null checks
    }
  }
}
