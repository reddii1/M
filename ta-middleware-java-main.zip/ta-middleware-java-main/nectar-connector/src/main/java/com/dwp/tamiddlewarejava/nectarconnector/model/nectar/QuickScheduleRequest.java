package com.dwp.tamiddlewarejava.nectarconnector.model.nectar;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QuickScheduleRequest {
  private String testCaseId;
  private String cli;
  private String calledNumber;
  private boolean retry;
}
