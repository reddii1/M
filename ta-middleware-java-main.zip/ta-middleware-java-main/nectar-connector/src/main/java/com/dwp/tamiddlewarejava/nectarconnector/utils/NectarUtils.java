package com.dwp.tamiddlewarejava.nectarconnector.utils;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dwp.tamiddlewarejava.nectarconnector.model.enums.RunResultTestOutcomeState;

@Component
public class NectarUtils {

  private static final Logger logger = LoggerFactory.getLogger(NectarUtils.class);

  /**
   * Converts a raw test result string into a standardized outcome description.
   *
   * @param result The raw result string obtained from a test execution.
   * @return A string representing the standardized outcome, either "Passed" or "Failed".
   */
  public String getTestOutcome(String result) {
    return RunResultTestOutcomeState.SUCCESSFUL.toString().equals(result) ? "Passed" : "Failed";
  }

  /**
   * Converts a string representation of a start time into a Timestamp object.
   *
   * @param runResultStartTime The start time of the run result as a string.
   * @return A Timestamp representing the parsed start time, or null if parsing fails.
   */
  public Timestamp parseResultStartTimeToTimestamp(String runResultStartTime) {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss");
    Timestamp resultStartTime = null;

    try {
      LocalDateTime localDateTime = LocalDateTime.parse(runResultStartTime, formatter);
      resultStartTime = Timestamp.valueOf(localDateTime);
    } catch (DateTimeParseException e) {
      logger.error("error parsing result start time");
    }

    return resultStartTime;
  }
}
