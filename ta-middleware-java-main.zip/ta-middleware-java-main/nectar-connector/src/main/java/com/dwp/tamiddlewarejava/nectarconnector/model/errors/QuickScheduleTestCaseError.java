package com.dwp.tamiddlewarejava.nectarconnector.model.errors;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class QuickScheduleTestCaseError {
  private List<String> errors;
}
