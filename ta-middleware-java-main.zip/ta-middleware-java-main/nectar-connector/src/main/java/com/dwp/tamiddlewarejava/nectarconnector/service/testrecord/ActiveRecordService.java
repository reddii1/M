package com.dwp.tamiddlewarejava.nectarconnector.service.testrecord;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.nectarconnector.model.enums.TestRecordStateEnum;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;

@Service
public class ActiveRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ActiveRecordService.class);
  private HostOperationsService hostOperationsService;
  private NewRecordService newRecordService;
  private ScheduledRecordService scheduledRecordService;
  private @Value("${MAX_START_ATTEMPTS:3}") Integer maxStartAttempts;

  public ActiveRecordService(
      NewRecordService newRecordService,
      HostOperationsService hostOperationsService,
      ScheduledRecordService scheduledRecordService) {
    this.scheduledRecordService = scheduledRecordService;
    this.hostOperationsService = hostOperationsService;
    this.newRecordService = newRecordService;
  }

  /**
   * Handles active test cases by determining their current state. Delegates to different services
   * based on whether the test case is new or has been scheduled.
   *
   * @param testCase The active test case to handle.
   * @param data The connector data associated with the test case.
   */
  public void handleActiveRecord(TestCase testCase, ConnectorData data) {
    try {
      if (data.getState().isEmpty()) {
        newRecordService.handleNewRecord(testCase, data);

        if (testCase.getStartAttempts() > maxStartAttempts) {
          logger.debug("Test failed to execute - max start attempts reached");
          hostOperationsService.failTestAndReleaseHost(
              testCase, data.getHost(), "Test failed to execute - max start attempts reached");
        }
      } else if (TestRecordStateEnum.SCHEDULED.toString().equals(data.getState())) {
        scheduledRecordService.handleScheduledRecord(testCase, data);
      }
    } catch (Exception e) {
      logger.error("Error processing record {}", testCase.getId(), e);
    }
  }
}
