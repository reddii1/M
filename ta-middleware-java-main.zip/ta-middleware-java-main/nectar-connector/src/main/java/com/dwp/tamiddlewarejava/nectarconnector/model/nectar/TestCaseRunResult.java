package com.dwp.tamiddlewarejava.nectarconnector.model.nectar;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TestCaseRunResult {
  private Integer totalRecords;
  private List<TestCaseRunResultData> data;
}
