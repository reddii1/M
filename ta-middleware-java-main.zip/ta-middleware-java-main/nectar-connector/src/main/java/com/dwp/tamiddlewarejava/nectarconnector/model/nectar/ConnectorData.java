package com.dwp.tamiddlewarejava.nectarconnector.model.nectar;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConnectorData {
  @JsonProperty("State")
  private String state = "";

  @JsonProperty("Cli")
  private String cli = "";

  @JsonProperty("CalledNumber")
  private String calledNumber = "";

  @JsonProperty("ExecutionId")
  private String executionId = "";

  @JsonProperty("Host")
  private String host = "";
}
