package com.dwp.tamiddlewarejava.nectarconnector.model.enums;

public enum RunResultTestOutcomeState {
  SUCCESSFUL("SUCCESSFUL");

  private final String testOutcomeState;

  RunResultTestOutcomeState(String testOutcomeState) {
    this.testOutcomeState = testOutcomeState;
  }

  @Override
  public String toString() {
    return testOutcomeState;
  }
}
