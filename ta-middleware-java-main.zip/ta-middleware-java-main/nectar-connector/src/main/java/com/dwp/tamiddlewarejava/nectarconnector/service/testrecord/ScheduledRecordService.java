package com.dwp.tamiddlewarejava.nectarconnector.service.testrecord;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.nectarconnector.config.NectarClientConfig;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.TestCaseRunResultData;
import com.dwp.tamiddlewarejava.nectarconnector.service.client.ClientService;
import com.dwp.tamiddlewarejava.nectarconnector.utils.NectarUtils;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.shared.utils.TimeUtil;

@Service
public class ScheduledRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ScheduledRecordService.class);
  private HostOperationsService hostOperationsService;
  private final NectarClientConfig nectarClientConfig;
  private TestCaseOperationsService testCaseOperationsService;
  private NectarUtils nectarUtils;
  private @Value("${MAX_START_ATTEMPTS:3}") Integer maxStartAttempts;
  private @Value("${nectar.url}") String nectarBaseUrl;

  public ScheduledRecordService(
      NectarClientConfig nectarClientConfig,
      HostOperationsService hostOperationsService,
      TestCaseOperationsService testCaseOperationsService,
      NectarUtils nectarUtils) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.hostOperationsService = hostOperationsService;
    this.nectarClientConfig = nectarClientConfig;
    this.nectarUtils = nectarUtils;
  }

  /**
   * Processes a test case that has been scheduled. Updates the test case status to "EXECUTING" and
   * retrieves the run result for further processing.
   *
   * @param testCase The scheduled test case to process.
   * @param data The connector data associated with the test case.
   */
  public void handleScheduledRecord(TestCase testCase, ConnectorData data) {
    try {
      testCaseOperationsService.updateStatusAndOutcome(
          testCase.getId(),
          OrchestrationStatusEnum.EXECUTING.toString(),
          "",
          new Timestamp(new Date().getTime()));

      HostCredentials credentials = hostOperationsService.getHostCredentials(data.getHost());
      String urlTemplate = String.format(nectarBaseUrl, data.getHost());
      ClientService client =
          nectarClientConfig.createNectarClient(
              urlTemplate, credentials.getUsername(), credentials.getPassword());

      if (data.getExecutionId() == null || data.getExecutionId().isEmpty()) {
        return;
      }

      TestCaseRunResultData runResult = getRunResult(client, data);
      if (runResult == null || "CONTINUE".equals(runResult.getResult())) {
        return;
      }

      testCase = updateRecordWithRunResult(testCase, runResult);
      testCaseOperationsService.updateNectarExecuted(
          testCase.getId(),
          testCase.getOrchestrationStatus(),
          testCase.getTestOutcome(),
          testCase.getNotes(),
          testCase.getDuration(),
          testCase.getStartTime());

      logger.debug("Setting test status to Executed");
    } catch (Exception e) {
      logger.error("Error handling scheduled Nectar record: {}", e.getMessage(), e);
    }
  }

  /**
   * Retrieves the run result for a test case from the Nectar Client Service.
   *
   * @param client The Nectar Client Service instance.
   * @param data The connector data containing the execution ID to fetch results for.
   * @return The run result data, or null if retrieval fails.
   */
  private TestCaseRunResultData getRunResult(ClientService client, ConnectorData data)
      throws Exception {
    try {
      return client.getRunResult(data.getExecutionId());
    } catch (Exception e) {
      logger.error("Error retrieving run result:{}", e.getMessage());
      return null;
    }
  }

  /**
   * Updates a test case record based on the retrieved run result. Sets the test outcome, status,
   * notes, duration, and start time based on the run result.
   *
   * @param testCase The test case to update.
   * @param runResult The run result data used to update the test case.
   * @return The updated test case.
   */
  private TestCase updateRecordWithRunResult(TestCase testCase, TestCaseRunResultData runResult) {
    long duration = TimeUtil.clockDuration(runResult.getDuration());

    testCase.setTestOutcome(nectarUtils.getTestOutcome(runResult.getResult()));
    testCase.setOrchestrationStatus(OrchestrationStatusEnum.EXECUTED.toString());
    testCase.setNotes(runResult.getMessage());
    testCase.setDuration(duration);
    testCase.setStartTime(nectarUtils.parseResultStartTimeToTimestamp(runResult.getStartTime()));
    return testCase;
  }
}
