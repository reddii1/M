package com.dwp.tamiddlewarejava.nectarconnector.service.client;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.nectarconnector.model.errors.QuickScheduleTestCaseError;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.QuickScheduleRequest;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ScheduledTestCase;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.TestCaseRunResult;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.TestCaseRunResultData;
import com.dwp.tamiddlewarejava.shared.model.errors.CustomApplicationError;
import com.dwp.tamiddlewarejava.shared.utils.EncryptionUtil;
import com.dwp.tamiddlewarejava.shared.utils.RestUtil;
import com.dwp.tamiddlewarejava.shared.utils.StringUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.NoArgsConstructor;

@Service
@NoArgsConstructor
public class ClientService {

  private final Logger logger = LoggerFactory.getLogger(ClientService.class);
  private String baseUrl;
  private String username;
  private String password;
  private HttpClient httpClient;
  private ObjectMapper objectMapper;
  private String hostsPasswordEncryptionKey;
  private Boolean shouldRetryRequest;

  public ClientService(String baseUrl, String username, String password) {
    this.baseUrl = baseUrl;
    this.username = username;
    this.password = password;
    this.httpClient = HttpClient.newHttpClient();
    objectMapper = new ObjectMapper();
  }

  /**
   * Sets the encryption key used for decrypting the host's password.
   *
   * @param hostsPasswordEncryptionKey The encryption key as a String.
   */
  public void setHostsPasswordEncryptionKey(String hostsPasswordEncryptionKey) {
    this.hostsPasswordEncryptionKey = hostsPasswordEncryptionKey;
  }

  /**
   * Sets whether requests to the Nectar quickScheduleTestCase API should be retried on failure.
   *
   * @param shouldRetryRequest A Boolean indicating if retry behavior is enabled.
   */
  public void setShouldRetryRequest(Boolean shouldRetryRequest) {
    this.shouldRetryRequest = shouldRetryRequest;
  }

  /**
   * Schedules a test case in Nectar based on provided details.
   *
   * @param testCaseId The ID of the test case to schedule.
   * @param cli The CLI number.
   * @param calledNumber The number to be called.
   * @return A ScheduledTestCase object representing the scheduled test case.
   * @throws CustomApplicationError If there's an error during the scheduling process.
   */
  public ScheduledTestCase quickScheduleTestCase(String testCaseId, String cli, String calledNumber)
      throws CustomApplicationError {

    if (StringUtil.isNullOrEmpty(testCaseId)) {
      throw new CustomApplicationError("TCID is null or empty");
    }

    try {
      logger.debug("Quick Scheduling Test Case");

      QuickScheduleRequest request = new QuickScheduleRequest();
      request.setTestCaseId(testCaseId);
      request.setCli(cli);
      request.setCalledNumber(calledNumber);
      request.setRetry(shouldRetryRequest);

      String requestBody = objectMapper.writeValueAsString(request);
      String path = "/testCases/quickScheduleTestCase";

      String jsonResponse = sendNectarRequest("POST", path, requestBody);

      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errors")) {
        QuickScheduleTestCaseError errors =
            objectMapper.treeToValue(rootNode, QuickScheduleTestCaseError.class);
        String errorMessage = String.join(", ", errors.getErrors());
        throw new CustomApplicationError(errorMessage);
      } else {
        return objectMapper.treeToValue(rootNode, ScheduledTestCase.class);
      }
    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when quick scheduling test case: " + testCaseId);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when quick scheduling test case: " + testCaseId);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when quick scheduling test case: " + testCaseId);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error quick scheduling test case: " + testCaseId + " - " + e.getMessage());
    }
  }

  /**
   * Retrieves the run result for a given execution ID from the Nectar Run Result API.
   *
   * @param executionId The ID of the test execution to retrieve results for.
   * @return TestCaseRunResultData object containing the run results.
   * @throws CustomApplicationError If there's an error fetching the run result.
   */
  public TestCaseRunResultData getRunResult(String executionId) throws CustomApplicationError {

    if (StringUtil.isNullOrEmpty(executionId)) {
      throw new CustomApplicationError("Execution ID is null or empty");
    }

    TestCaseRunResultData data = new TestCaseRunResultData();
    try {
      String path = "/test-suite-run-result/test-case-result/" + executionId;
      String jsonResponse = sendNectarRequest("GET", path, null);

      if (jsonResponse == null || jsonResponse.isEmpty()) {
        return null;
      }

      TestCaseRunResult result = objectMapper.readValue(jsonResponse, TestCaseRunResult.class);

      if (result.getData() != null && !result.getData().isEmpty()) {
        data = result.getData().get(0);
        logger.debug("Result retrieved for test case: {}", data.getResult());
        return data;
      }

      data.setResult("CONTINUE");

      return data;
    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when getting run result for ExecutionID: " + executionId);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when getting run result for ExecutionID: "
              + executionId);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when getting run result for ExecutionID: " + executionId);
    } catch (Exception e) {
      throw new CustomApplicationError("Error getting run result " + e.getMessage());
    }
  }

  /**
   * Sends a request to the provided Nectar API endpoint.
   *
   * @param method The HTTP method to use (e.g., "POST", "GET").
   * @param path The API endpoint path.
   * @param requestBody The request body for POST requests.
   * @return The response body as a String.
   * @throws IOException If there's an error in network communication.
   * @throws InterruptedException If the operation is interrupted.
   */
  public String sendNectarRequest(String method, String path, String requestBody)
      throws IOException, InterruptedException {

    if (hostsPasswordEncryptionKey == null) {
      throw new IllegalStateException("Failed to locate host password decryption key");
    }

    String decryptedPassword =
        EncryptionUtil.decryptPassword(this.password, hostsPasswordEncryptionKey);

    String url = this.baseUrl + path;

    HttpRequest.Builder requestBuilder;

    if (method.equals("POST")) {
      requestBuilder =
          HttpRequest.newBuilder()
              .uri(URI.create(url))
              .method(
                  method,
                  (requestBody != null)
                      ? HttpRequest.BodyPublishers.ofString(requestBody)
                      : HttpRequest.BodyPublishers.noBody())
              .header("Content-Type", "application/json")
              .header(
                  "Authorization",
                  RestUtil.createBasicAuthHeader(this.username, decryptedPassword));
    } else {
      requestBuilder =
          HttpRequest.newBuilder()
              .uri(URI.create(url))
              .GET()
              .header(
                  "Authorization",
                  RestUtil.createBasicAuthHeader(this.username, decryptedPassword));
    }

    HttpRequest request = requestBuilder.build();
    HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

    return response.body();
  }
}
