package com.dwp.tamiddlewarejava.nectarconnector.model.enums;

public enum TestRecordStateEnum {
  SCHEDULED("Scheduled");

  private final String testRecordState;

  TestRecordStateEnum(String testRecordState) {
    this.testRecordState = testRecordState;
  }

  @Override
  public String toString() {
    return testRecordState;
  }
}
