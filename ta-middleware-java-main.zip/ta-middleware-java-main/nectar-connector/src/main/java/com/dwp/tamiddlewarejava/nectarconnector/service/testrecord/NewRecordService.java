package com.dwp.tamiddlewarejava.nectarconnector.service.testrecord;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.nectarconnector.config.NectarClientConfig;
import com.dwp.tamiddlewarejava.nectarconnector.model.enums.TestRecordStateEnum;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ScheduledTestCase;
import com.dwp.tamiddlewarejava.nectarconnector.service.client.ClientService;
import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.host.Host;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class NewRecordService {

  private static final Logger logger = LoggerFactory.getLogger(NewRecordService.class);
  private final NectarClientConfig nectarClientConfig;
  private TestCaseOperationsService testCaseOperationsService;
  private HostOperationsService hostOperationsService;
  private @Value("${nectar.url}") String nectarBaseUrl;

  public NewRecordService(
      NectarClientConfig nectarClientConfig,
      HostOperationsService hostOperationsService,
      TestCaseOperationsService testCaseOperationsService) {
    this.hostOperationsService = hostOperationsService;
    this.testCaseOperationsService = testCaseOperationsService;
    this.nectarClientConfig = nectarClientConfig;
  }

  /**
   * Handles a new test case by checking for an available host and attempting to schedule the test
   * case. Updates the test case's start attempts and processes scheduling results.
   *
   * @param testCase The new test case to handle.
   * @param data The connector data associated with the test case.
   */
  public void handleNewRecord(TestCase testCase, ConnectorData data) {
    try {
      logger.debug("Handling New Record");

      String testProvider = "Nectar";
      Host host = hostOperationsService.selectHost(testCase.getAtidHost(), testProvider);
      if (host == null) {
        logger.error("Nectar Host {} does not exist", testCase.getAtidHost());
        testCaseOperationsService.updateStatusAndOutcome(
            testCase.getId(),
            OrchestrationStatusEnum.EXECUTED.toString(),
            TestOutcomeEnum.MW_HOST_DOES_NOT_EXIST.toString(),
            new Timestamp(new Date().getTime()));
        return;
      }

      String hostName = host.getHostName();
      String hostStatus = host.getHostStatus();

      if (!HostStateEnum.AVAILABLE.toString().equalsIgnoreCase(hostStatus)) {
        testCaseOperationsService.updateNotes(
            testCase.getId(), "Host not Available - Test Case is on hold.");
        return;
      }

      testCaseOperationsService.updateNotes(testCase.getId(), "");

      HostCredentials credentials = hostOperationsService.getHostCredentials(hostName);
      String urlTemplate = String.format(nectarBaseUrl, hostName);
      ClientService client =
          nectarClientConfig.createNectarClient(
              urlTemplate, credentials.getUsername(), credentials.getPassword());

      testCaseOperationsService.incrementStartAttempts(testCase.getId());
      testCase.setStartAttempts(testCase.getStartAttempts() + 1);

      ScheduledTestCase scheduledTestCase;

      try {
        scheduledTestCase =
            client.quickScheduleTestCase(
                testCase.getAtid(), testCase.getSpoofCli(), testCase.getTargetCli());
      } catch (Exception e) {
        hostOperationsService.failTestAndReleaseHost(testCase, hostName, e.getMessage());
        return;
      }

      updateRecordAndData(testCase, data, host, scheduledTestCase);
    } catch (Exception e) {
      logger.error("Error handling new Nectar record: {}", e.getMessage(), e);
    }
  }

  /**
   * Updates a test case and its connector data based on the outcome of scheduling the test case.
   * Sets the state to "Scheduled" and updates other fields based on the scheduling result.
   *
   * @param testCase The test case to update.
   * @param data The updated connector data for the test case.
   * @param host The host used for scheduling the test case.
   * @param scheduledTestCase The result of the scheduling operation.
   */
  private void updateRecordAndData(
      TestCase testCase, ConnectorData data, Host host, ScheduledTestCase scheduledTestCase)
      throws Exception {
    if (scheduledTestCase == null) {
      return;
    }
    data.setState(TestRecordStateEnum.SCHEDULED.toString());
    data.setExecutionId(scheduledTestCase.getExecutionId());
    data.setCalledNumber(testCase.getTargetCli());
    data.setCli(testCase.getSpoofCli());
    data.setHost(host.getHostName());

    String jsonData = new ObjectMapper().writeValueAsString(data);
    testCaseOperationsService.updateConnectorData(testCase.getId(), jsonData);
  }
}
