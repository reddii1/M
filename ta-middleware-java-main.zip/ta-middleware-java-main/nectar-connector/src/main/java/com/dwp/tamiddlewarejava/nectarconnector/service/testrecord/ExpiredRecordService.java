package com.dwp.tamiddlewarejava.nectarconnector.service.testrecord;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.nectarconnector.model.nectar.ConnectorData;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

@Service
public class ExpiredRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ExpiredRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;

  public ExpiredRecordService(TestCaseOperationsService testCaseOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
  }

  /**
   * Marks a test case as expired and updates its status and notes accordingly. Also sets the
   * associated host's state to "Available" for future use.
   *
   * @param testCase The test case that has expired.
   * @param data The connector data associated with the test case.
   * @param now The current timestamp marking the time of expiration.
   */
  public void handleExpiredRecord(TestCase testCase, ConnectorData data, Timestamp now) {
    logger.debug("Handling Expired Nectar record");

    testCaseOperationsService.updateStatusAndOutcome(
        testCase.getId(),
        OrchestrationStatusEnum.EXECUTED.toString(),
        TestOutcomeEnum.TIMED_OUT.toString(),
        now);
    testCaseOperationsService.updateNotes(testCase.getId(), "Request time is before expiry");
  }
}
