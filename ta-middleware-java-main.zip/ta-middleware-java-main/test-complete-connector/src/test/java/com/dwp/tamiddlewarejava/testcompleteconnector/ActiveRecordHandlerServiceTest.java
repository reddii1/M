package com.dwp.tamiddlewarejava.testcompleteconnector;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.util.ReflectionTestUtils;

import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.ActiveRecordHandlerService;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.CreatingRecordService;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.ExecutedRecordService;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.ExecutingRecordService;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.FinalizingRecordService;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.NewRecordService;

class ActiveRecordHandlerServiceTest {

  @Mock private NewRecordService newRecordService;
  @Mock private CreatingRecordService creatingRecordService;
  @Mock private ExecutedRecordService executedRecordService;
  @Mock private ExecutingRecordService executingRecordService;
  @Mock private FinalizingRecordService finalizingRecordService;
  @Mock private HostOperationsService hostOperationsService;
  @Mock private TestCaseOperationsService testCaseOperationsService;
  @Mock private Logger logger;

  @InjectMocks private ActiveRecordHandlerService activeRecordHandlerService;

  private TestCase testCase;
  private ConnectorData data;
  private Timestamp now;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    testCase = new TestCase();
    data = new ConnectorData();
    now = new Timestamp(System.currentTimeMillis());

    activeRecordHandlerService =
        new ActiveRecordHandlerService(
            testCaseOperationsService,
            newRecordService,
            creatingRecordService,
            executedRecordService,
            executingRecordService,
            finalizingRecordService,
            hostOperationsService);

    ReflectionTestUtils.setField(activeRecordHandlerService, "maxStartAttempts", 3);
  }

  @Test
  void whenStateIsEmpty_thenHandleNewRecordIsInvoked() {
    data.setState("");

    activeRecordHandlerService.handleActiveRecord(testCase, data, now);

    verify(newRecordService).handleNewRecord(testCase, data);
  }

  @Test
  void whenStateIsCreating_thenHandleCreatingIsInvoked() {
    data.setState("creating");

    activeRecordHandlerService.handleActiveRecord(testCase, data, now);

    verify(creatingRecordService).handleCreating(testCase, data);
  }

  @Test
  void whenStateIsExecuting_thenHandleExecutingIsInvoked() {
    data.setState("executing");

    activeRecordHandlerService.handleActiveRecord(testCase, data, now);

    verify(executingRecordService).handleExecuting(testCase, data, now);
  }

  @Test
  void whenStateIsExecuted_thenHandleExecutedIsInvoked() {
    data.setState("executed");

    activeRecordHandlerService.handleActiveRecord(testCase, data, now);

    verify(executedRecordService).handleExecuted(testCase, data);
  }

  @Test
  void whenStateIsFinalizing_thenHandleFinalizingIsInvoked() {
    data.setState("finalizing");

    activeRecordHandlerService.handleActiveRecord(testCase, data, now);

    verify(finalizingRecordService).handleFinalizing(testCase, data);
  }

  @Test
  void whenStartAttemptsExceedMax_thenFailTestAndReleaseHostIsInvoked() {
    testCase.setStartAttempts(4);
    data.setState("executing"); // State could be anything valid

    activeRecordHandlerService.handleActiveRecord(testCase, data, now);

    verify(hostOperationsService)
        .failTestAndReleaseHost(eq(testCase), eq(data.getHost()), anyString());
  }
}
