package com.dwp.tamiddlewarejava.testcompleteconnector;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.util.ReflectionTestUtils;

import com.dwp.tamiddlewarejava.shared.utils.EncryptionUtil;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.SummaryResult;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.client.ClientService;

class ClientServiceTest {

  @Mock private HttpClient mockHttpClient;

  @Mock private Logger logger;

  @Mock private HttpResponse<String> mockResponse;

  private ClientService client;
  private String encryptedPassword;

  @BeforeEach
  void setUp() throws Exception {
    MockitoAnnotations.openMocks(this);

    String secretKey = "fvrbwtbefgwefrv42342352";
    String passwordToEncrypt = "plainPassword";
    encryptedPassword = EncryptionUtil.encryptPassword(passwordToEncrypt, secretKey);

    client = new ClientService("http://baseUrl", "username", encryptedPassword);
    ReflectionTestUtils.setField(client, "hostsPasswordEncryptionKey", "fvrbwtbefgwefrv42342352");

    Field httpClientField = ClientService.class.getDeclaredField("httpClient");
    httpClientField.setAccessible(true);
    httpClientField.set(client, mockHttpClient);

    when(mockHttpClient.send(
            any(HttpRequest.class), any(HttpResponse.BodyHandlers.ofString().getClass())))
        .thenReturn(mockResponse);

    when(mockResponse.body()).thenReturn("expected jsonResponse");
    when(mockResponse.statusCode()).thenReturn(200);
  }

  @Test
  void shouldReturnProjectSuiteIdWhenRegisteringProjectSuite() throws Exception {
    String predefinedResponse = "{\"success\":true, \"result\":{\"suite\":123}}";

    when(mockResponse.body()).thenReturn(predefinedResponse);

    Integer result = client.registerProjectSuite("projectPath", "projectName");
    Integer expected = 123;

    verify(mockHttpClient).send(any(), any());
    assertNotNull(result);
    assertEquals(expected, result, "Result should match suite");
  }

  @Test
  void shouldReturnRunningStatusForGivenInstanceId() throws Exception {
    String jsonResponse = "{\"success\":true, \"result\":{\"state\":\"running\"}}";
    when(mockResponse.body()).thenReturn(jsonResponse);

    String result = client.getStatus(123);
    assertEquals("running", result);
  }

  @Test
  void shouldCreateInstanceAndReturnItsId() throws Exception {
    String jsonResponse = "{\"success\":true, \"result\":{\"instance\":456}}";
    when(mockResponse.body()).thenReturn(jsonResponse);

    Integer result = client.createInstance(123);
    assertEquals(Integer.valueOf(456), result);
  }

  @Test
  void shouldReturnCompletedStateWhenRunningTestItem() throws Exception {
    String jsonResponse = "{\"success\":true, \"result\":{\"state\":\"completed\"}}";
    when(mockResponse.body()).thenReturn(jsonResponse);

    String result = client.run(123, "MyProject", "MyItem");
    assertEquals("completed", result);
  }

  @Test
  void shouldNotThrowExceptionWhenClosingInstance() throws Exception {
    String jsonResponse = "{\"success\":true}";
    when(mockResponse.body()).thenReturn(jsonResponse);

    assertDoesNotThrow(() -> client.closeInstance(123));
  }

  @Test
  void shouldNotThrowExceptionWhenDeregisteringProjectSuite() throws Exception {
    String jsonResponse = "{\"success\":true}";
    when(mockResponse.body()).thenReturn(jsonResponse);

    assertDoesNotThrow(() -> client.deregisterProjectSuite(123));
  }

  @Test
  void shouldReturnNonNullSummaryResultForGivenInstanceId() throws Exception {
    String jsonResponse = "{\"success\":true, \"result\":{}}";
    when(mockResponse.body()).thenReturn(jsonResponse);

    SummaryResult result = client.getSummary(123);
    assertNotNull(result);
  }
}
