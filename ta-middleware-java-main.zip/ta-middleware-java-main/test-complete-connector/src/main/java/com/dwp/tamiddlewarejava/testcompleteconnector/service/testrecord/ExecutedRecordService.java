package com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.config.TestCompleteClientConfig;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.client.ClientService;

@Service
public class ExecutedRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ExecutedRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostOperationsService hostOperationsService;
  private final TestCompleteClientConfig testCompleteClientConfig;
  private @Value("${testcomplete.url}") String testCompleteBaseUrl;

  public ExecutedRecordService(
      TestCaseOperationsService testCaseOperationsService,
      TestCompleteClientConfig testCompleteClientConfig,
      HostOperationsService hostOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.testCompleteClientConfig = testCompleteClientConfig;
    this.hostOperationsService = hostOperationsService;
  }

  /**
   * Handles the post-execution finalization of a test case.
   *
   * @param testCase The executed test case record.
   * @param data Connector data associated with the test case.
   */
  public void handleExecuted(TestCase testCase, ConnectorData data) {
    HostCredentials credentials = hostOperationsService.getHostCredentials(data.getHost());
    String testCompleteUrlTemplate = String.format(testCompleteBaseUrl, data.getHost());
    ClientService tcClient =
        testCompleteClientConfig.createTestCompleteClient(
            testCompleteUrlTemplate, credentials.getUsername(), credentials.getPassword());

    try {
      logger.debug("Test executed, closing execution instance");
      tcClient.closeInstance(data.getInstance());
    } catch (Exception e) {
      hostOperationsService.failTestAndReleaseHost(testCase, data.getHost(), e.getMessage());
      return;
    }

    data.setState("finalizing");
    String jsonData = new JSONObject(data).toString();
    testCaseOperationsService.updateConnectorData(testCase.getId(), jsonData);
  }
}
