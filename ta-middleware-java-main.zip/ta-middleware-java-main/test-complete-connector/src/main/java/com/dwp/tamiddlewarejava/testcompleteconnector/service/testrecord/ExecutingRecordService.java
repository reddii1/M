package com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.config.TestCompleteClientConfig;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.enums.InstanceStatusEnum;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.enums.SummaryResultEnum;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.SummaryResult;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.client.ClientService;

@Service
public class ExecutingRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ExecutingRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostOperationsService hostOperationsService;
  private final TestCompleteClientConfig testCompleteClientConfig;
  private @Value("${testcomplete.url}") String testCompleteBaseUrl;

  public ExecutingRecordService(
      TestCaseOperationsService testCaseOperationsService,
      TestCompleteClientConfig testCompleteClientConfig,
      HostOperationsService hostOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.testCompleteClientConfig = testCompleteClientConfig;
    this.hostOperationsService = hostOperationsService;
  }

  /**
   * Manages the execution process of a test case. Updates the test case status to executing and
   * interacts with the TestComplete service to run the test. Post-execution, the method transitions
   * the state to executed and updates relevant test case information.
   *
   * @param testCase The test case record undergoing execution.
   * @param data Connector data containing execution details.
   * @param now The current timestamp, used for updating records.
   * @return A status message indicating if the test is ready for further action or null if it
   *     remains in the current state.
   */
  public String handleExecuting(TestCase testCase, ConnectorData data, Timestamp now) {
    testCaseOperationsService.updateStatusAndOutcome(
        testCase.getId(), OrchestrationStatusEnum.EXECUTING.toString(), "", now);

    HostCredentials credentials = hostOperationsService.getHostCredentials(data.getHost());
    String testCompleteUrlTemplate = String.format(testCompleteBaseUrl, data.getHost());
    ClientService tcClient =
        testCompleteClientConfig.createTestCompleteClient(
            testCompleteUrlTemplate, credentials.getUsername(), credentials.getPassword());

    String status;

    try {
      status = tcClient.getStatus(data.getInstance());
    } catch (Exception e) {
      hostOperationsService.failTestAndReleaseHost(testCase, data.getHost(), e.getMessage());
      return e.getMessage();
    }

    if (!InstanceStatusEnum.READY.toString().equals(status)) {
      return null;
    }

    SummaryResult summaryResult;
    try {
      summaryResult = tcClient.getSummary(data.getInstance());
    } catch (Exception e) {
      hostOperationsService.failTestAndReleaseHost(testCase, data.getHost(), e.getMessage());
      return null;
    }

    String summaryResultStatus = summaryResult.getStatus();
    String summaryResultMessage = summaryResult.getMessage();

    if (SummaryResultEnum.PASSED.toString().equals(summaryResultStatus)) {
      logger.debug("Test Outcome = Passed");
      testCase.setTestOutcome("Passed");
    } else {
      logger.debug("Test Outcome = Failed");
      testCase.setTestOutcome("Failed");
    }

    Duration duration =
        Duration.between(testCase.getStartTime().toLocalDateTime(), LocalDateTime.now());

    long durationInMillis = duration.toMillis();

    testCase.setDuration(durationInMillis);
    testCase.setNotes(summaryResultMessage);

    data.setState("executed");
    String jsonData = new JSONObject(data).toString();
    testCaseOperationsService.updateTestCompleteExecuted(
        testCase.getId(),
        jsonData,
        testCase.getTestOutcome(),
        testCase.getNotes(),
        testCase.getDuration());
    return null;
  }
}
