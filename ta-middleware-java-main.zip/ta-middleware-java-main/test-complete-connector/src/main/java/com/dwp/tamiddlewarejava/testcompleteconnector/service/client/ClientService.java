package com.dwp.tamiddlewarejava.testcompleteconnector.service.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.errors.CustomApplicationError;
import com.dwp.tamiddlewarejava.shared.utils.EncryptionUtil;
import com.dwp.tamiddlewarejava.shared.utils.RestUtil;
import com.dwp.tamiddlewarejava.shared.utils.StringUtil;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.errors.TestCompleteRequestError;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.CreateInstanceResponse;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.RegisterProjectSuiteResponse;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.StatusResponse;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.SummaryResponse;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.SummaryResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.NoArgsConstructor;

@Service
@NoArgsConstructor
public class ClientService {

  private static final Logger logger = LoggerFactory.getLogger(ClientService.class);
  private static final String nullInstanceIDMessage = "Instance ID is null";
  private String baseUrl;
  private String username;
  private String password;
  private HttpClient httpClient;
  private ObjectMapper objectMapper;
  private String hostsPasswordEncryptionKey;

  public ClientService(String baseUrl, String username, String password) {
    this.baseUrl = baseUrl;
    this.username = username;
    this.password = password;
    this.httpClient = HttpClient.newHttpClient();
    objectMapper = new ObjectMapper();
  }

  /**
   * Sets the encryption key used for decrypting the host's password.
   *
   * @param hostsPasswordEncryptionKey The encryption key as a String.
   */
  public void setHostsPasswordEncryptionKey(String hostsPasswordEncryptionKey) {
    this.hostsPasswordEncryptionKey = hostsPasswordEncryptionKey;
  }

  /**
   * Registers a project suite with the TestComplete server. Constructs the request URL from the
   * provided project path and name, sends a PUT request, and processes the response. If the
   * operation is successful, returns the suite ID; otherwise, throws a CustomApplicationError with
   * an appropriate message.
   *
   * @param projectPath The file system path to the project suite.
   * @param projectName The name of the project.
   * @return The ID of the registered project suite.
   * @throws CustomApplicationError if the operation fails due to network issues, interruption, or
   *     server errors.
   */
  public Integer registerProjectSuite(String projectPath, String projectName)
      throws CustomApplicationError {
    if (StringUtil.isNullOrEmpty(projectPath) || StringUtil.isNullOrEmpty(projectName)) {
      throw new CustomApplicationError("Project Path or Project Name is null or empty");
    }
    try {
      logger.debug("Registering project suite for {}{}.pjs ", projectPath, projectName);

      String encodedPath = URLEncoder.encode(projectPath, StandardCharsets.UTF_8.toString());
      String encodedProjectName = URLEncoder.encode(projectName, StandardCharsets.UTF_8.toString());

      String uri = encodedPath + "/" + encodedProjectName + "/" + encodedProjectName + ".pjs";
      String path = String.format("/1/suites?uri=file:///%s", uri);

      path = path.replace(" ", "%20");
      String jsonResponse = sendTestCompleteRequest("PUT", path, null);

      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errorMessage")) {
        TestCompleteRequestError errors =
            objectMapper.treeToValue(rootNode, TestCompleteRequestError.class);
        String errorMessage = errors.getErrorMessage();
        throw new CustomApplicationError(errorMessage);
      } else {
        RegisterProjectSuiteResponse response =
            objectMapper.treeToValue(rootNode, RegisterProjectSuiteResponse.class);
        if (response.isSuccess()) {
          return response.getResult().getSuite();
        } else {
          throw new CustomApplicationError(
              "Failed to register project suite " + projectPath + projectName + ".pjs");
        }
      }
    } catch (UnsupportedEncodingException e) {
      throw new CustomApplicationError(
          "Error encoding URL parameters when registering project suite for "
              + projectPath
              + " and "
              + projectName);
    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when registering project suite for "
              + projectPath
              + " and "
              + projectName);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when registering project suite for "
              + projectPath
              + " and "
              + projectName);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when registering project suite for "
              + projectPath
              + " and "
              + projectName);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error registering project suite for "
              + projectPath
              + " and "
              + projectName
              + " - "
              + e.getMessage());
    }
  }

  /**
   * Retrieves the current status of a specified instance on the TestComplete server. Sends a GET
   * request and returns the instance's state as reported by the server.
   *
   * @param instance The ID of the instance to query.
   * @return The current state of the instance.
   * @throws CustomApplicationError if there are issues parsing the response or communicating with
   *     the server.
   */
  public String getStatus(Integer instance) throws CustomApplicationError {
    if (instance == null) {
      throw new CustomApplicationError(nullInstanceIDMessage);
    }

    try {
      String path = String.format("/1/instances/%d", instance);
      String jsonResponse = sendTestCompleteRequest("GET", path, null);

      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errorMessage")) {
        TestCompleteRequestError errors =
            objectMapper.treeToValue(rootNode, TestCompleteRequestError.class);
        String errorMessage = errors.getErrorMessage();
        throw new CustomApplicationError(errorMessage);
      } else {
        StatusResponse response = objectMapper.treeToValue(rootNode, StatusResponse.class);
        if (response.isSuccess()) {
          return response.getResult().getState();
        } else if ("error".equals(response.getResult().getState())) {
          String errorMessage = "Error status returned from TestComplete for instance " + instance;
          throw new CustomApplicationError(errorMessage);
        } else {
          throw new CustomApplicationError("Failed to get status for instance " + instance);
        }
      }

    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response getting status for instance: " + instance);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred getting status for instance: " + instance);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted getting status for instance: " + instance);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error getting status for instance " + instance + " - " + e.getMessage());
    }
  }

  /**
   * Creates an instance of a specified project suite on the TestComplete server. Sends a POST
   * request to the server and returns the ID of the newly created instance.
   *
   * @param suite The ID of the project suite for which an instance is to be created.
   * @return The ID of the created instance.
   * @throws CustomApplicationError for network, interruption, or server-related errors.
   */
  public Integer createInstance(Integer suite) throws CustomApplicationError {
    if (suite == null) {
      throw new CustomApplicationError("Suite ID is null");
    }

    try {
      logger.debug("Creating execution instance for suite {}", suite);

      String path = String.format("/1/suites/%d/create_instance", suite);

      String jsonResponse = sendTestCompleteRequest("POST", path, null);
      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errorMessage")) {
        TestCompleteRequestError errors =
            objectMapper.treeToValue(rootNode, TestCompleteRequestError.class);
        String errorMessage = errors.getErrorMessage();
        throw new CustomApplicationError(errorMessage);
      } else {
        CreateInstanceResponse response =
            objectMapper.treeToValue(rootNode, CreateInstanceResponse.class);
        if (response.isSuccess()) {
          return response.getResult().getInstance();
        } else {
          throw new CustomApplicationError("Failed to get create instance for suite " + suite);
        }
      }

    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when creating instance for suite: " + suite);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when creating instance for suite: " + suite);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when creating instance for suite: " + suite);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error creating instance for suite " + suite + " - " + e.getMessage());
    }
  }

  /**
   * Executes a specified test item within a project on a given instance. Constructs and sends a
   * POST request to start the test execution and returns the execution state.
   *
   * @param instance The ID of the instance where the test is to be run.
   * @param project The name of the project containing the test item.
   * @param item The name of the test item to run.
   * @return The state of the test execution.
   * @throws CustomApplicationError for errors related to request construction, network issues, or
   *     server responses.
   */
  public String run(Integer instance, String project, String item) throws CustomApplicationError {
    if (instance == null || StringUtil.isNullOrEmpty(item) || StringUtil.isNullOrEmpty(project)) {
      throw new CustomApplicationError("Instance ID, Test Item or Project is null");
    }

    try {
      logger.debug("Running Test Execution in project {} with instance {}", project, instance);

      String encodedItem = URLEncoder.encode(item, StandardCharsets.UTF_8.toString());
      String path =
          String.format(
              "/1/instances/%d/run?project=%s&run_item=%s", instance, project, encodedItem);

      String jsonResponse = sendTestCompleteRequest("POST", path, null);
      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errorMessage")) {
        TestCompleteRequestError errors =
            objectMapper.treeToValue(rootNode, TestCompleteRequestError.class);
        String errorMessage = errors.getErrorMessage();
        throw new CustomApplicationError(errorMessage);
      } else {
        StatusResponse response = objectMapper.treeToValue(rootNode, StatusResponse.class);
        if (response.isSuccess()) {
          return response.getResult().getState();
        } else {
          throw new CustomApplicationError(
              "Failed to run test " + item + " in project " + project + " on instance " + instance);
        }
      }
    } catch (UnsupportedEncodingException e) {
      throw new CustomApplicationError("Error encoding URL parameters for test item: " + item);
    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when running test for test item: " + item);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when running test for test item: " + item);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when running test for test item: " + item);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error running test for item " + item + " - " + e.getMessage());
    }
  }

  /**
   * Fetches a summary of test execution for a specified instance. Sends a GET request and processes
   * the response to return a summary of results.
   *
   * @param instance The ID of the instance for which a summary is requested.
   * @return A summary of test results.
   * @throws CustomApplicationError for issues with parsing the response, network communication, or
   *     server errors.
   */
  public SummaryResult getSummary(Integer instance) throws CustomApplicationError {
    if (instance == null) {
      throw new CustomApplicationError(nullInstanceIDMessage);
    }

    try {
      logger.debug("Retrieving execution summary for instance {}", instance);

      String path = String.format("/1/instances/%d/summary", instance);

      String jsonResponse = sendTestCompleteRequest("GET", path, null);
      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errorMessage")) {
        TestCompleteRequestError errors =
            objectMapper.treeToValue(rootNode, TestCompleteRequestError.class);
        String errorMessage = errors.getErrorMessage();
        throw new CustomApplicationError(errorMessage);
      } else {
        SummaryResponse response = objectMapper.treeToValue(rootNode, SummaryResponse.class);
        if (response.isSuccess()) {
          return response.getResult();
        } else {
          throw new CustomApplicationError("Failed to get summary for instance " + instance);
        }
      }
    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when getting summary for instance: " + instance);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when getting summary for instance: " + instance);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when getting summary for instance: " + instance);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error getting summary for instance " + instance + " - " + e.getMessage());
    }
  }

  /**
   * Closes a specified instance on the TestComplete server. Sends a DELETE request to the server to
   * terminate the instance and logs the operation's outcome.
   *
   * @param instance The ID of the instance to be closed.
   * @throws CustomApplicationError for network issues, interruptions, or failure responses from the
   *     server.
   */
  public void closeInstance(Integer instance) throws CustomApplicationError {
    if (instance == null) {
      throw new CustomApplicationError(nullInstanceIDMessage);
    }

    try {
      logger.debug("Closing instance {}", instance);

      String path = String.format("/1/instances/%d", instance);

      String jsonResponse = sendTestCompleteRequest("DELETE", path, null);
      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errorMessage")) {
        TestCompleteRequestError errors =
            objectMapper.treeToValue(rootNode, TestCompleteRequestError.class);
        String errorMessage = errors.getErrorMessage();
        throw new CustomApplicationError(errorMessage);
      } else {
        StatusResponse response = objectMapper.treeToValue(rootNode, StatusResponse.class);
        if (response.isSuccess()) {
          return;
        } else {
          throw new CustomApplicationError("Failed to close project suite instance " + instance);
        }
      }
    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when closing instance: " + instance);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when closing instance: " + instance);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when closing instance: " + instance);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error closing instance " + instance + " - " + e.getMessage());
    }
  }

  /**
   * Deregisters a project suite from the TestComplete server. Sends a DELETE request and logs the
   * outcome of the operation.
   *
   * @param suite The ID of the project suite to deregister.
   * @throws CustomApplicationError for problems encountered during the request, including network
   *     or server errors.
   */
  public void deregisterProjectSuite(Integer suite) throws CustomApplicationError {
    if (suite == null) {
      throw new CustomApplicationError("Project Suite ID is null");
    }

    try {
      logger.debug("Deregistering project suite {}", suite);

      String path = String.format("/1/suites/%d", suite);

      String jsonResponse = sendTestCompleteRequest("DELETE", path, null);
      JsonNode rootNode = objectMapper.readTree(jsonResponse);
      if (rootNode.has("errorMessage")) {
        TestCompleteRequestError errors =
            objectMapper.treeToValue(rootNode, TestCompleteRequestError.class);
        String errorMessage = errors.getErrorMessage();
        throw new CustomApplicationError(errorMessage);
      } else {
        StatusResponse response = objectMapper.treeToValue(rootNode, StatusResponse.class);
        if (response.isSuccess()) {
          return;
        } else {
          throw new CustomApplicationError("Failed to de-register project suite" + suite);
        }
      }
    } catch (JsonProcessingException e) {
      throw new CustomApplicationError(
          "Error parsing JSON response when deregistering suite: " + suite);
    } catch (IOException e) {
      throw new CustomApplicationError(
          "Network communication error occurred when deregistering suite: " + suite);
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      throw new CustomApplicationError(
          "Operation was interrupted when deregistering suite: " + suite);
    } catch (Exception e) {
      throw new CustomApplicationError(
          "Error deregistering suite " + suite + " - " + e.getMessage());
    }
  }

  /**
   * Sends a request to the TestComplete API. Handles the construction and sending of HTTP requests
   * based on the specified method, path, and request body. Ensures proper authorization and handles
   * HTTP responses, logging the status of each request.
   *
   * @param method The HTTP method to use for the request.
   * @param path The path of the API endpoint.
   * @param requestBody The body of the request for POST, PUT, or DELETE operations.
   * @return The body of the HTTP response as a string.
   * @throws IOException, InterruptedException for communication issues or operation interruptions.
   */
  public String sendTestCompleteRequest(String method, String path, String requestBody)
      throws IOException, InterruptedException {

    if (hostsPasswordEncryptionKey == null) {
      throw new IllegalStateException("Failed to locate host password decryption key");
    }

    String decryptedPassword =
        EncryptionUtil.decryptPassword(this.password, hostsPasswordEncryptionKey);

    String url = this.baseUrl + path;

    HttpRequest.Builder requestBuilder;

    if (method.equals("POST") || method.equals("PUT") || method.equals("DELETE")) {
      HttpRequest.BodyPublisher bodyPublisher =
          (requestBody != null)
              ? HttpRequest.BodyPublishers.ofString(requestBody)
              : HttpRequest.BodyPublishers.noBody();

      requestBuilder =
          HttpRequest.newBuilder()
              .uri(URI.create(url))
              .method(method, bodyPublisher)
              .header("Content-Type", "application/json")
              .header(
                  "Authorization",
                  RestUtil.createBasicAuthHeader(this.username, decryptedPassword));
    } else {
      requestBuilder =
          HttpRequest.newBuilder()
              .uri(URI.create(url))
              .GET()
              .header(
                  "Authorization",
                  RestUtil.createBasicAuthHeader(this.username, decryptedPassword));
    }

    HttpRequest request = requestBuilder.build();
    HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

    return response.body();
  }
}
