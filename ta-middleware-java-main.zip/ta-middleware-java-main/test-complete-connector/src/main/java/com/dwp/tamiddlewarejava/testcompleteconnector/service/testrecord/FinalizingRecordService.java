package com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.host.HostStateService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.config.TestCompleteClientConfig;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.enums.InstanceStatusEnum;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.client.ClientService;

@Service
public class FinalizingRecordService {

  private static final Logger logger = LoggerFactory.getLogger(FinalizingRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostOperationsService hostOperationsService;
  private HostStateService hostStateService;
  private final TestCompleteClientConfig testCompleteClientConfig;
  private @Value("${testcomplete.url}") String testCompleteBaseUrl;

  public FinalizingRecordService(
      TestCaseOperationsService testCaseOperationsService,
      TestCompleteClientConfig testCompleteClientConfig,
      HostOperationsService hostOperationsService,
      HostStateService hostStateService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.testCompleteClientConfig = testCompleteClientConfig;
    this.hostOperationsService = hostOperationsService;
    this.hostStateService = hostStateService;
  }

  /**
   * Manages the finalization phase for a test case. Checks the test case status with the
   * TestComplete Client service and performs necessary cleanup, including deregistering the project
   * suite. Updates the orchestration status and ensures resources are released.
   *
   * @param testCase The test case record in the finalizing state.
   * @param data Connector data associated with the test case.
   * @return A status message indicating the outcome of the finalization process.
   */
  public String handleFinalizing(TestCase testCase, ConnectorData data) {
    HostCredentials credentials = hostOperationsService.getHostCredentials(data.getHost());
    String testCompleteUrlTemplate = String.format(testCompleteBaseUrl, data.getHost());
    ClientService tcClient =
        testCompleteClientConfig.createTestCompleteClient(
            testCompleteUrlTemplate, credentials.getUsername(), credentials.getPassword());

    String status;
    try {
      status = tcClient.getStatus(data.getInstance());
    } catch (Exception e) {
      hostOperationsService.failTestAndReleaseHost(testCase, data.getHost(), e.getMessage());
      return e.getMessage();
    }

    if (!InstanceStatusEnum.CLOSED.toString().equals(status)) {
      return null;
    }

    try {
      logger.debug("Deregistering project suite and finalizing test execution");
      tcClient.deregisterProjectSuite(data.getSuite());
    } catch (Exception e) {
      hostOperationsService.failTestAndReleaseHost(testCase, data.getHost(), e.getMessage());
      return null;
    }

    testCase.setOrchestrationStatus(OrchestrationStatusEnum.EXECUTED.toString());

    logger.debug("Setting test status to Executed and releasing Host");
    testCaseOperationsService.updateStatus(testCase.getId(), testCase.getOrchestrationStatus());
    hostStateService.updateHostState(data.getHost(), HostStateEnum.AVAILABLE.toString());
    return null;
  }
}
