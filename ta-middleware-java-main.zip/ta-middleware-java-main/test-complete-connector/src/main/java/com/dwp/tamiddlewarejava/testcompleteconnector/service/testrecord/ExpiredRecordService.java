package com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostStateService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;

@Service
public class ExpiredRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ExpiredRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostStateService hostStateService;

  public ExpiredRecordService(
      TestCaseOperationsService testCaseOperationsService, HostStateService hostStateService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.hostStateService = hostStateService;
  }

  /**
   * Updates the test case status and notes when identified as expired. Marks the test case as
   * executed due to timeout, ensuring timely cleanup and state transition.
   *
   * @param testCase The expired test case.
   * @param data Connector data associated with the test case.
   * @param now The timestamp indicating when the test case was identified as expired.
   */
  public void handleExpiredRecord(TestCase testCase, ConnectorData data, Timestamp now) {
    logger.debug("Handling Expired TestComplete record");

    testCaseOperationsService.updateStatusAndOutcome(
        testCase.getId(),
        OrchestrationStatusEnum.EXECUTED.toString(),
        TestOutcomeEnum.TIMED_OUT.toString(),
        now);
    testCaseOperationsService.updateNotes(testCase.getId(), "Request time is before expiry");
    hostStateService.updateHostState(data.getHost(), HostStateEnum.AVAILABLE.toString());
  }
}
