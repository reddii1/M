package com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConnectorData {
  private String state = "";
  private String host = "";
  private Integer suite;
  private Integer instance;
  private String projectName = "";
  private String projectLocation = "";
}
