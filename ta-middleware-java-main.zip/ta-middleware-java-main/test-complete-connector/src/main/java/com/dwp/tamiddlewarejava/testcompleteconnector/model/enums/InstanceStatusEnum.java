package com.dwp.tamiddlewarejava.testcompleteconnector.model.enums;

public enum InstanceStatusEnum {
  READY("ready"),
  CLOSED("closed");

  private final String instanceStatus;

  InstanceStatusEnum(String instanceStatus) {
    this.instanceStatus = instanceStatus;
  }

  @Override
  public String toString() {
    return instanceStatus;
  }
}
