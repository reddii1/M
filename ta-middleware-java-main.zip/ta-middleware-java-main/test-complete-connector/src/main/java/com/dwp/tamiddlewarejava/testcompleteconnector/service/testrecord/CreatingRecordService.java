package com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord;

import java.sql.Timestamp;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.config.TestCompleteClientConfig;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.enums.InstanceStatusEnum;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.client.ClientService;

@Service
public class CreatingRecordService {

  private static final Logger logger = LoggerFactory.getLogger(CreatingRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostOperationsService hostOperationsService;
  private final TestCompleteClientConfig testCompleteClientConfig;
  private @Value("${testcomplete.url}") String testCompleteBaseUrl;

  public CreatingRecordService(
      TestCaseOperationsService testCaseOperationsService,
      TestCompleteClientConfig testCompleteClientConfig,
      HostOperationsService hostOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.testCompleteClientConfig = testCompleteClientConfig;
    this.hostOperationsService = hostOperationsService;
  }

  /**
   * Initiates the creation of an execution instance for a test case.
   *
   * @param testCase The test case record undergoing the creating process.
   * @param data Connector data associated with the test case, including host and project details.
   * @return A status message indicating success, failure, or null if the process is not yet
   *     complete.
   */
  public String handleCreating(TestCase testCase, ConnectorData data) {
    HostCredentials credentials = hostOperationsService.getHostCredentials(data.getHost());
    String testCompleteUrlTemplate = String.format(testCompleteBaseUrl, data.getHost());
    ClientService tcClient =
        testCompleteClientConfig.createTestCompleteClient(
            testCompleteUrlTemplate, credentials.getUsername(), credentials.getPassword());

    String status;

    try {
      status = tcClient.getStatus(data.getInstance());
    } catch (Exception e) {
      hostOperationsService.failTestAndReleaseHost(testCase, data.getHost(), e.getMessage());
      return e.getMessage();
    }

    if (!InstanceStatusEnum.READY.toString().equals(status)) {
      return null;
    }

    Timestamp now = new Timestamp(System.currentTimeMillis());

    try {
      tcClient.run(data.getInstance(), data.getProjectName(), data.getProjectLocation());
    } catch (Exception e) {
      hostOperationsService.failTestAndReleaseHost(testCase, data.getHost(), e.getMessage());
      return e.getMessage();
    }

    logger.debug("Executing test record");

    data.setState("executing");
    String jsonData = new JSONObject(data).toString();
    testCaseOperationsService.updateRunning(testCase.getId(), jsonData, now);
    return null;
  }
}
