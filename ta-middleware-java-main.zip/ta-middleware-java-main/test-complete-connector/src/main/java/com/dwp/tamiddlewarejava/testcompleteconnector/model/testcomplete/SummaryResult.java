package com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SummaryResult {
  private String message;
  private String status;
  private List<TestResult> tests;
}
