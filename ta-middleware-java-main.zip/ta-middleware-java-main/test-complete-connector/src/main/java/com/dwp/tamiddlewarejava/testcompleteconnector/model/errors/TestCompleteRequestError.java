package com.dwp.tamiddlewarejava.testcompleteconnector.model.errors;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TestCompleteRequestError {
  private boolean success;
  private String errorMessage;
}
