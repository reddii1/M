package com.dwp.tamiddlewarejava.testcompleteconnector.service.testcaseprocessor;

import java.sql.Timestamp;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.ActiveRecordHandlerService;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord.ExpiredRecordService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class TestCaseProcessorService {

  private static final Logger logger = LoggerFactory.getLogger(TestCaseProcessorService.class);
  private ActiveRecordHandlerService activeRecordService;
  private ExpiredRecordService expiredRecordService;
  private ObjectMapper objectMapper;
  private @Value("${TIMEOUT_HOURS:24}") Integer timeoutHours;
  private @Value("${MAX_START_ATTEMPTS:3}") Integer maxStartAttempts;

  public TestCaseProcessorService(
      ActiveRecordHandlerService activeRecordService, ExpiredRecordService expiredRecordService) {
    this.activeRecordService = activeRecordService;
    this.expiredRecordService = expiredRecordService;
    objectMapper = new ObjectMapper();
  }

  /**
   * Processes a given test case based on its expiry time and current state. Attempts to parse
   * connector data from the test case, determine if the test case is expired, and delegate handling
   * to the appropriate service based on its state (expired or active).
   *
   * @param testCase The test case to process.
   * @param expiry The expiry time to compare against the test case's request time.
   */
  public void processTestCase(TestCase testCase, Instant expiry) {
    try {
      ConnectorData data = new ConnectorData();
      String connectorDataJson = testCase.getConnectorData();

      if (connectorDataJson != null) {
        data = objectMapper.readValue(connectorDataJson, ConnectorData.class);
      }

      Timestamp now = new Timestamp(System.currentTimeMillis());
      if (testCase.getRequestTime().toInstant().isBefore(expiry)) {
        expiredRecordService.handleExpiredRecord(testCase, data, now);
      } else {
        activeRecordService.handleActiveRecord(testCase, data, now);
      }
    } catch (Exception e) {
      logger.error("Error processing record: {}", e.getMessage());
    }
  }
}
