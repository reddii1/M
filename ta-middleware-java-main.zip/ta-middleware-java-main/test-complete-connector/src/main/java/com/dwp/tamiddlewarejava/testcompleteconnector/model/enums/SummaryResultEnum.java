package com.dwp.tamiddlewarejava.testcompleteconnector.model.enums;

public enum SummaryResultEnum {
  PASSED("passed");

  private final String summaryResult;

  SummaryResultEnum(String summaryResult) {
    this.summaryResult = summaryResult;
  }

  @Override
  public String toString() {
    return summaryResult;
  }
}
