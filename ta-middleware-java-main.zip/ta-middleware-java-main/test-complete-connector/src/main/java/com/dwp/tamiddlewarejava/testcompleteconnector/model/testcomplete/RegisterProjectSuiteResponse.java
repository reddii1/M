package com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegisterProjectSuiteResponse {
  private RegisterProjectSuiteResult result;
  private boolean success;
}
