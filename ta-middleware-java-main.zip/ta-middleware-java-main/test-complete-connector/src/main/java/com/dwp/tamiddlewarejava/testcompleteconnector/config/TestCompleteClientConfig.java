package com.dwp.tamiddlewarejava.testcompleteconnector.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.dwp.tamiddlewarejava.testcompleteconnector.service.client.ClientService;

import lombok.NoArgsConstructor;

@Configuration
@NoArgsConstructor
public class TestCompleteClientConfig {

  @Value("${host.encryptionkey}")
  private String hostsPasswordEncryptionKey;

  public ClientService createTestCompleteClient(String baseUrl, String username, String password) {
    ClientService client = new ClientService(baseUrl, username, password);
    client.setHostsPasswordEncryptionKey(this.hostsPasswordEncryptionKey);
    return client;
  }
}
