package com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusResult {
  private String state;
}
