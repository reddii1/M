package com.dwp.tamiddlewarejava.testcompleteconnector.utils;

import java.util.Arrays;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

@Component
public class TestCompleteUtils {
  /**
   * Splits the ATID string into the project name and project location.
   *
   * @param atid The ATID string that encapsulates both the project name and its location, separated
   *     by "|".
   * @return A Pair object containing the project name as the first element (key) and the project
   *     location as the second element (value). If the ATID contains additional segments beyond the
   *     project name, these are concatenated back into a single string, representing the full path
   *     or location of the project.
   */
  public Pair<String, String> getAtidParts(String atid) {
    String[] parts = atid.split("\\|");
    String projectName = parts[0];
    String projectLocation = String.join("|", Arrays.copyOfRange(parts, 1, parts.length));

    return Pair.of(projectName, projectLocation);
  }
}
