package com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;

@Service
public class ActiveRecordHandlerService {

  private static final Logger logger = LoggerFactory.getLogger(ActiveRecordHandlerService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostOperationsService hostOperationsService;
  private NewRecordService newRecordService;
  private CreatingRecordService creatingRecordService;
  private ExecutedRecordService executedRecordService;
  private ExecutingRecordService executingRecordService;
  private FinalizingRecordService finalizingRecordService;
  private @Value("${MAX_START_ATTEMPTS:3}") Integer maxStartAttempts;

  public ActiveRecordHandlerService(
      TestCaseOperationsService testCaseOperationsService,
      NewRecordService newRecordService,
      CreatingRecordService creatingRecordService,
      ExecutedRecordService executedRecordService,
      ExecutingRecordService executingRecordService,
      FinalizingRecordService finalizingRecordService,
      HostOperationsService hostOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.newRecordService = newRecordService;
    this.creatingRecordService = creatingRecordService;
    this.executedRecordService = executedRecordService;
    this.executingRecordService = executingRecordService;
    this.finalizingRecordService = finalizingRecordService;
    this.hostOperationsService = hostOperationsService;
  }

  /**
   * Processes an active test case based on its current state. This method delegates to specific
   * service methods depending on the state of the `ConnectorData`. If the test case exceeds the
   * maximum start attempts, it triggers a failure process.
   *
   * @param testCase The test case being processed.
   * @param data The associated connector data detailing the state of the test case.
   * @param now The current timestamp for logging and updating records.
   */
  public void handleActiveRecord(TestCase testCase, ConnectorData data, Timestamp now) {
    try {
      switch (data.getState().toLowerCase()) {
        case "":
          newRecordService.handleNewRecord(testCase, data);
          break;
        case "creating":
          creatingRecordService.handleCreating(testCase, data);
          break;
        case "executing":
          executingRecordService.handleExecuting(testCase, data, now);
          break;
        case "executed":
          executedRecordService.handleExecuted(testCase, data);
          break;
        case "finalizing":
          finalizingRecordService.handleFinalizing(testCase, data);
          break;
        default:
          logger.warn("Unhandled state: {}", data.getState());
      }

      if (testCase.getStartAttempts() > maxStartAttempts) {
        logger.debug("Test failed to execute - max start attempts reached");
        hostOperationsService.failTestAndReleaseHost(
            testCase, data.getHost(), "Test failed to execute - max start attempts reached");
      }
    } catch (Exception e) {
      testCaseOperationsService.incrementStartAttempts(testCase.getId());
      logger.error("Error processing record in state {}: {}", data.getState(), e.getMessage());
    }
  }
}
