package com.dwp.tamiddlewarejava.testcompleteconnector.service.testrecord;

import java.sql.Timestamp;

import org.apache.commons.lang3.tuple.Pair;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.host.Host;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.host.HostStateService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.testcompleteconnector.config.TestCompleteClientConfig;
import com.dwp.tamiddlewarejava.testcompleteconnector.model.testcomplete.ConnectorData;
import com.dwp.tamiddlewarejava.testcompleteconnector.service.client.ClientService;
import com.dwp.tamiddlewarejava.testcompleteconnector.utils.TestCompleteUtils;

@Service
public class NewRecordService {

  private final Logger logger = LoggerFactory.getLogger(NewRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostOperationsService hostOperationsService;
  private HostStateService hostStateService;
  private final TestCompleteClientConfig testCompleteClientConfig;
  private TestCompleteUtils testCompleteUtils;
  private @Value("${testcomplete.url}") String testCompleteBaseUrl;

  public NewRecordService(
      TestCaseOperationsService testCaseOperationsService,
      TestCompleteClientConfig testCompleteClientConfig,
      TestCompleteUtils testCompleteUtils,
      HostOperationsService hostOperationsService,
      HostStateService hostStateService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.testCompleteClientConfig = testCompleteClientConfig;
    this.testCompleteUtils = testCompleteUtils;
    this.hostOperationsService = hostOperationsService;
    this.hostStateService = hostStateService;
  }

  /**
   * Prepares a new test case for execution. Selects a host, registers the project suite, creates an
   * instance, and updates the connector data. Handles initial setup for test execution, including
   * environment configuration and state initialization.
   *
   * @param testCase The new test case record to be prepared for execution.
   * @param data Initial connector data for setting up the test case environment.
   */
  public void handleNewRecord(TestCase testCase, ConnectorData data) {
    try {
      String testProvider = "TestComplete";
      Host host = hostOperationsService.selectHost(testCase.getAtidHost(), testProvider);
      Timestamp now = new Timestamp(System.currentTimeMillis());

      if (host == null) {
        logger.error("TestComplete Host {} does not exist", testCase.getAtidHost());
        testCaseOperationsService.updateStatusAndOutcome(
            testCase.getId(),
            OrchestrationStatusEnum.EXECUTED.toString(),
            TestOutcomeEnum.MW_HOST_DOES_NOT_EXIST.toString(),
            now);
        return;
      }

      String hostName = host.getHostName();
      String hostStatus = host.getHostStatus();
      String projectRoot = host.getProjectsRoot();

      if (!HostStateEnum.AVAILABLE.toString().equalsIgnoreCase(hostStatus)) {
        testCaseOperationsService.updateNotes(
            testCase.getId(), "Host not Available - Test Case is on hold.");
        return;
      }

      logger.debug("Handling New record");

      testCaseOperationsService.updateNotes(testCase.getId(), "");

      hostStateService.updateHostState(hostName, HostStateEnum.EXECUTING.toString());

      HostCredentials credentials = hostOperationsService.getHostCredentials(hostName);
      String testCompleteUrlTemplate = String.format(testCompleteBaseUrl, hostName);
      ClientService tcClient =
          testCompleteClientConfig.createTestCompleteClient(
              testCompleteUrlTemplate, credentials.getUsername(), credentials.getPassword());

      Pair<String, String> atidParts = testCompleteUtils.getAtidParts(testCase.getAtid());
      String projectName = atidParts.getLeft();
      String projectLocation = atidParts.getRight();

      Integer suite;
      try {
        suite = tcClient.registerProjectSuite(projectRoot, projectName);
      } catch (Exception e) {
        hostOperationsService.failTestAndReleaseHost(testCase, hostName, e.getMessage());
        return;
      }

      Integer instance;

      try {
        instance = tcClient.createInstance(suite);
      } catch (Exception e) {
        hostOperationsService.failTestAndReleaseHost(testCase, hostName, e.getMessage());
        return;
      }

      data.setHost(hostName);
      data.setState("creating");
      data.setSuite(suite);
      data.setInstance(instance);
      data.setProjectName(projectName);
      data.setProjectLocation(projectLocation);

      String jsonData = new JSONObject(data).toString();
      testCaseOperationsService.updateConnectorData(testCase.getId(), jsonData);
      testCaseOperationsService.incrementStartAttempts(testCase.getId());
    } catch (Exception e) {
      logger.error(e.getMessage(), e);
    }
  }
}
