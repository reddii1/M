package com.dwp.tamiddlewarejava.zephyrconnector;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.time.Instant;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.zephyrconnector.service.testcaseprocessor.TestCaseProcessorService;
import com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord.ActiveRecordService;
import com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord.ExpiredRecordService;

class TestCaseProcessorServiceTest {

  @Mock private ActiveRecordService activeRecordService;

  @Mock private ExpiredRecordService expiredRecordService;

  @Mock private Logger logger;

  @InjectMocks private TestCaseProcessorService testCaseProcessorService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    testCaseProcessorService =
        new TestCaseProcessorService(activeRecordService, expiredRecordService);
  }

  @Test
  void whenTestCaseIsExpired_thenHandleExpiredRecord() {
    TestCase testCase = new TestCase();
    testCase.setRequestTime(Timestamp.from(Instant.now().minusSeconds(3600)));
    testCase.setOrchestrationStatus(OrchestrationStatusEnum.NEW.toString());
    Instant expiry = Instant.now().minusSeconds(1800);

    testCaseProcessorService.processTestCase(testCase, expiry);

    verify(expiredRecordService).handleExpiredRecord(eq(testCase), any(Timestamp.class));
  }

  @Test
  void whenTestCaseIsNotExpired_thenHandleActiveRecord() {
    TestCase testCase = new TestCase();
    testCase.setRequestTime(Timestamp.from(Instant.now().minusSeconds(1800)));
    testCase.setOrchestrationStatus(OrchestrationStatusEnum.NEW.toString());
    Instant expiry = Instant.now().minusSeconds(3600);

    testCaseProcessorService.processTestCase(testCase, expiry);

    verify(activeRecordService).handleActiveRecord(eq(testCase));
  }
}
