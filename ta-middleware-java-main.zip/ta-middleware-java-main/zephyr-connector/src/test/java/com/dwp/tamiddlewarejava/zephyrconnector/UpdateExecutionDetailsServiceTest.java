package com.dwp.tamiddlewarejava.zephyrconnector;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.util.ReflectionTestUtils;

import com.dwp.tamiddlewarejava.zephyrconnector.service.executiondetails.UpdateExecutionDetailsService;
import com.dwp.tamiddlewarejava.zephyrconnector.utils.ZephyrUtils;

class UpdateExecutionDetailsServiceTest {

  @Mock private HttpClient mockHttpClient;

  @Mock private HttpResponse<String> mockResponse;

  @Mock private ZephyrUtils zephyrUtils;

  @Mock private Logger logger;

  private UpdateExecutionDetailsService service;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    zephyrUtils = mock(ZephyrUtils.class);
    try {
      when(zephyrUtils.createHttpClientWithCustomCert()).thenReturn(mockHttpClient);
    } catch (Exception e) {
      logger.error("Error creating zephyr utils mock");
    }

    service = new UpdateExecutionDetailsService(zephyrUtils);
  }

  @Test
  void shouldSendUpdateRequestWithCorrectParametersWhenUpdatingExecutionDetails() throws Exception {
    ReflectionTestUtils.setField(service, "zephyrUrl", "http://mock.zephyr.url");
    int executionId = 1, status = 1, testerId = 1;
    long duration = System.currentTimeMillis();
    String notes = "Execution Details updated";

    when(mockResponse.statusCode()).thenReturn(200);

    service.updateExecutionDetails(executionId, status, testerId, duration, notes);

    verify(mockHttpClient).send(any(HttpRequest.class), eq(HttpResponse.BodyHandlers.ofString()));
  }
}
