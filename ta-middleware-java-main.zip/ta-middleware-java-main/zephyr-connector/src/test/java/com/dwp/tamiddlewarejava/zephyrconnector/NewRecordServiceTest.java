package com.dwp.tamiddlewarejava.zephyrconnector;

import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.zephyrconnector.model.zephyr.OutcomeMapper;
import com.dwp.tamiddlewarejava.zephyrconnector.service.executiondetails.UpdateExecutionDetailsService;
import com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord.ActiveRecordService;
import com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord.NewRecordService;
import com.dwp.tamiddlewarejava.zephyrconnector.utils.ZephyrUtils;

class NewRecordServiceTest {

  @Mock private UpdateExecutionDetailsService updateExecutionDetailsService;

  @Mock private ZephyrUtils zephyrUtils;

  @Mock private Logger logger;

  @Mock private NewRecordService newRecordService;

  @InjectMocks private ActiveRecordService activeRecordService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    activeRecordService =
        new ActiveRecordService(updateExecutionDetailsService, zephyrUtils, newRecordService);
  }

  @Test
  void whenHandlingActiveNewRecord_thenHandleNewRecordIsInvoked() {
    TestCase testCase = new TestCase();
    testCase.setId(UUID.randomUUID());
    testCase.setOrchestrationStatus(OrchestrationStatusEnum.NEW.toString());

    activeRecordService.handleActiveRecord(testCase);

    verify(newRecordService).handleNewRecord(testCase);
  }

  @Test
  void whenHandlingActiveRecordNotCancelled_thenUpdateExecutionDetailsIsCalled() {
    TestCase testCase = new TestCase();
    testCase.setId(UUID.randomUUID());
    testCase.setEid(1234);
    testCase.setTesterId(1);
    testCase.setOrchestrationStatus(OrchestrationStatusEnum.COMPLETED.toString());
    testCase.setTestOutcome(TestOutcomeEnum.PASSED.toString());
    testCase.setNotes("");
    testCase.setStartTime(Timestamp.valueOf(LocalDateTime.now().minusHours(1)));

    Integer outcome = OutcomeMapper.mapOutcome(testCase.getTestOutcome());
    Duration duration =
        Duration.between(testCase.getStartTime().toLocalDateTime(), LocalDateTime.now());

    long durationInMillis = duration.toMillis();

    activeRecordService.handleActiveRecord(testCase);

    try {
      verify(updateExecutionDetailsService)
          .updateExecutionDetails(
              testCase.getEid(),
              outcome,
              testCase.getTesterId(),
              durationInMillis,
              testCase.getNotes());
      verify(zephyrUtils).handleStatusBasedActions(testCase);
    } catch (Exception e) {
      logger.error("Error running update execution details test");
    }
  }
}
