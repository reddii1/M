package com.dwp.tamiddlewarejava.zephyrconnector;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.util.ReflectionTestUtils;

import com.dwp.tamiddlewarejava.shared.model.testexecution.ExecutionDetails;
import com.dwp.tamiddlewarejava.zephyrconnector.service.executiondetails.GetExecutionDetailsService;
import com.dwp.tamiddlewarejava.zephyrconnector.utils.ZephyrUtils;

class GetExecutionDetailsServiceTest {

  @Mock private HttpClient mockHttpClient;
  @Mock private HttpResponse<String> mockResponse;

  @Mock private ZephyrUtils zephyrUtils;

  @Mock private Logger logger;

  private GetExecutionDetailsService service;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    zephyrUtils = mock(ZephyrUtils.class);
    try {
      when(zephyrUtils.createHttpClientWithCustomCert()).thenReturn(mockHttpClient);
    } catch (Exception e) {
      logger.error("Error creating zephyr utils mock");
    }

    service = new GetExecutionDetailsService(zephyrUtils);
  }

  @Test
  void shouldReturnPopulatedExecutionDetailsWhenGivenValidIdsAndRecordId() throws Exception {
    ReflectionTestUtils.setField(service, "zephyrUrl", "http://mock.zephyr.url");
    int tcid = 1, rid = 1, cpid = 1;
    UUID recordId = UUID.randomUUID();

    String testFilePath = "src/test/resources/testGetExecutionDetailsData.json";

    String responseBody = new String(Files.readAllBytes(Paths.get(testFilePath)));

    when(mockResponse.body()).thenReturn(responseBody);
    when(mockResponse.statusCode()).thenReturn(200);
    when(mockHttpClient.send(
            any(HttpRequest.class), any(HttpResponse.BodyHandlers.ofString().getClass())))
        .thenReturn(mockResponse);

    ExecutionDetails details = service.getExecutionDetails(tcid, rid, cpid, recordId);

    assertNotNull(details, "ExecutionDetails should not be null");
    assertEquals(1, details.getId(), "ID should match the mock response");
    assertEquals(1, details.getTesterId(), "Tester ID should match the mock response");
    assertEquals(
        "1111", details.getAtid(), "ATID should match that found in the CustomFieldValues");
    assertEquals(
        "2", details.getAtidHost(), "ATID Host should match that found in the CustomFieldValues");
  }
}
