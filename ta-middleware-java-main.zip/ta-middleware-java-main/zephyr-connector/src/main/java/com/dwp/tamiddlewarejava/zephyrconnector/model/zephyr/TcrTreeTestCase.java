package com.dwp.tamiddlewarejava.zephyrconnector.model.zephyr;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TcrTreeTestCase {
  private ZephyrTestCase zephyrTestCase;
}
