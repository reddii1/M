package com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.utils.TimeUtil;
import com.dwp.tamiddlewarejava.zephyrconnector.model.zephyr.OutcomeMapper;
import com.dwp.tamiddlewarejava.zephyrconnector.service.executiondetails.UpdateExecutionDetailsService;
import com.dwp.tamiddlewarejava.zephyrconnector.utils.ZephyrUtils;

@Service
public class ActiveRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ActiveRecordService.class);
  private UpdateExecutionDetailsService updateExecutionDetailsService;
  private ZephyrUtils zephyrUtils;
  private NewRecordService newRecordService;

  public ActiveRecordService(
      UpdateExecutionDetailsService updateExecutionDetailsService,
      ZephyrUtils zephyrUtils,
      NewRecordService newRecordService) {
    this.updateExecutionDetailsService = updateExecutionDetailsService;
    this.zephyrUtils = zephyrUtils;
    this.newRecordService = newRecordService;
  }

  /**
   * Processes an active test case record based on its current status.
   *
   * @param testCase The test case to be processed.
   */
  public void handleActiveRecord(TestCase testCase) {
    try {
      if (OrchestrationStatusEnum.NEW.toString().equals(testCase.getOrchestrationStatus())) {
        newRecordService.handleNewRecord(testCase);
      } else {
        long durationInMillis =
            TimeUtil.calculateDurationInMillis(testCase.getStartTime(), LocalDateTime.now());
        testCase.setDuration(durationInMillis);

        Integer outcome = OutcomeMapper.mapOutcome(testCase.getTestOutcome());
        updateExecutionDetailsService.updateExecutionDetails(
            testCase.getEid(),
            outcome,
            testCase.getTesterId(),
            testCase.getDuration(),
            testCase.getNotes());

        zephyrUtils.handleStatusBasedActions(testCase);
      }
    } catch (Exception e) {
      logger.error("Error processing record {}", testCase.getId(), e);
    }
  }
}
