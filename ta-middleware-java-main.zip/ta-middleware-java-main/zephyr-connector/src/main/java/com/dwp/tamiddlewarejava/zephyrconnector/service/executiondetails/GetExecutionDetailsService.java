package com.dwp.tamiddlewarejava.zephyrconnector.service.executiondetails;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.testexecution.ExecutionDetails;
import com.dwp.tamiddlewarejava.shared.utils.RestUtil;
import com.dwp.tamiddlewarejava.zephyrconnector.utils.ZephyrUtils;

@Service
public class GetExecutionDetailsService {

  private static final Logger logger = LoggerFactory.getLogger(GetExecutionDetailsService.class);
  private @Value("${zephyr.url}") String zephyrUrl;
  private @Value("${zephyr.username}") String zephyrUsername;
  private @Value("${zephyr.password}") String zephyrPassword;
  private ZephyrUtils zephyrUtils;

  public GetExecutionDetailsService(ZephyrUtils zephyrUtils) {
    this.zephyrUtils = zephyrUtils;
  }

  /**
   * Retrieves execution details for a given set of identifiers.
   *
   * @param tcid Test case identifier.
   * @param rid Release identifier.
   * @param cpid Cycle Phase identifier.
   * @param recordId Unique identifier for the record.
   * @return ExecutionDetails object containing the fetched execution details.
   */
  public ExecutionDetails getExecutionDetails(int tcid, int rid, int cpid, UUID recordId) {

    logger.debug("Retrieving execution details");
    // Building the URL and request object for the HTTP call.
    String url = buildUrl(rid, cpid);
    HttpRequest request = buildRequest(url);

    // Attempt to create a custom HTTP client for the request.
    HttpClient client = null;
    try {
      client = zephyrUtils.createHttpClientWithCustomCert();
    } catch (Exception e) {
      logger.error("Error creating HTTP client: {}", e.getMessage(), e);
      return new ExecutionDetails();
    }

    // Sending the HTTP GET request and handling the response.
    try {
      HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

      // If response is successful, parse and return the execution details.
      if (response.statusCode() == 200) {
        return parseResponse(response.body(), tcid);
      } else {
        logger.error("HTTP request failed: {}", response.statusCode());
      }
    } catch (Exception e) {
      logger.error("Error while sending request: {}", e.getMessage(), e);
    }
    return new ExecutionDetails();
  }

  /**
   * Constructs a URL for fetching execution details from the Zephyr API.
   *
   * @param rid The release ID associated with the execution details to fetch.
   * @param cpid The cycle phase ID associated with the execution details.
   * @return A string representing the fully constructed URL.
   */
  private String buildUrl(int rid, int cpid) {
    return zephyrUrl
        + "/flex/services/rest/latest/execution?releaseid="
        + rid
        + "&cyclephaseid="
        + cpid
        + "&pagesize=10000";
  }

  /**
   * Creates an HTTP GET request to interact with the Zephyr API.
   *
   * @param url The URL to which the request will be sent.
   * @return An HttpRequest object ready for execution.
   */
  private HttpRequest buildRequest(String url) {
    return HttpRequest.newBuilder()
        .uri(URI.create(url))
        .GET()
        .header("Authorization", RestUtil.createBasicAuthHeader(zephyrUsername, zephyrPassword))
        .build();
  }

  /**
   * Parses the JSON response body to extract execution details relevant to a specific test case ID.
   *
   * @param responseBody The JSON response body as a string.
   * @param tcid The test case ID for which execution details are being sought.
   * @return An ExecutionDetails object populated with information from the matching test case, or a
   *     new, empty ExecutionDetails object if no match is found.
   */
  private ExecutionDetails parseResponse(String responseBody, int tcid) {
    JSONObject responseJson = new JSONObject(responseBody);
    JSONArray results = responseJson.getJSONArray("results");

    for (int i = 0; i < results.length(); i++) {
      try {
        JSONObject result = results.getJSONObject(i);
        JSONObject testcase = result.getJSONObject("tcrTreeTestcase").getJSONObject("testcase");
        if (testcase.getInt("testcaseId") == tcid) {
          return extractExecutionDetails(result, testcase);
        }
      } catch (Exception e) {
        logger.error("Error parsing response: {}", e.getMessage(), e);
      }
    }

    return new ExecutionDetails();
  }

  /**
   * Extracts execution details from a JSON object representing a test case result.
   *
   * @param result The JSON object containing the execution result.
   * @param testcase The nested JSON object within the result that contains the test case specifics.
   * @return An ExecutionDetails object containing the extracted data.
   */
  private ExecutionDetails extractExecutionDetails(JSONObject result, JSONObject testcase) {
    String atid = "";
    String atidHost = "";
    String targetCLI = "";
    String spoofCLI = "";
    int executionId = result.getInt("id");
    int testerId = result.getInt("testerId");

    // Extracting custom field values
    JSONArray customFields = testcase.getJSONArray("customFieldValues");
    for (int j = 0; j < customFields.length(); j++) {
      JSONObject customField = customFields.getJSONObject(j);
      String displayName = customField.getString("displayName");
      String value = customField.optString("value");

      // Zephyr "Custom Fields"
      switch (displayName) {
        case "ATID":
          atid = value;
          break;
        case "ATID Host":
          atidHost = value;
          break;
        case "Target CLI Override":
          targetCLI = value;
          break;
        case "Spoof CLI":
          spoofCLI = value;
          break;
      }
    }

    return new ExecutionDetails(executionId, testerId, atid, atidHost, targetCLI, spoofCLI);
  }
}
