package com.dwp.tamiddlewarejava.zephyrconnector.model.zephyr;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomFieldValue {
  private String displayName;
  private String value;
}
