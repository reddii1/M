package com.dwp.tamiddlewarejava.zephyrconnector.model.zephyr;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestScheduleResponse {
  private List<TestSchedule> results;
  private String type;
}
