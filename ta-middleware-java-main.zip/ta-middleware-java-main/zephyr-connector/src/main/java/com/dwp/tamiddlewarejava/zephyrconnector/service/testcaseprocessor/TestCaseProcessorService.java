package com.dwp.tamiddlewarejava.zephyrconnector.service.testcaseprocessor;

import java.sql.Timestamp;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord.ActiveRecordService;
import com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord.ExpiredRecordService;

@Service
public class TestCaseProcessorService {

  private static final Logger logger = LoggerFactory.getLogger(TestCaseProcessorService.class);
  private ActiveRecordService activeRecordService;
  private ExpiredRecordService expiredRecordService;

  public TestCaseProcessorService(
      ActiveRecordService activeRecordService, ExpiredRecordService expiredRecordService) {
    this.activeRecordService = activeRecordService;
    this.expiredRecordService = expiredRecordService;
  }

  /**
   * Processes a given test case by evaluating its status against an expiry timestamp.
   *
   * @param testCase The test case to process.
   * @param expiry The expiry timestamp against which the test case's request time is compared.
   */
  public void processTestCase(TestCase testCase, Instant expiry) {
    Timestamp now = Timestamp.from(Instant.now());
    if (testCase.getRequestTime().toInstant().isBefore(expiry)
        && !testCase
            .getOrchestrationStatus()
            .equals(OrchestrationStatusEnum.CANCELLED.toString())) {
      expiredRecordService.handleExpiredRecord(testCase, now);
    } else if (!OrchestrationStatusEnum.CANCELLED.toString().equals(testCase.getNotes())) {
      activeRecordService.handleActiveRecord(testCase);
    }
  }
}
