package com.dwp.tamiddlewarejava.zephyrconnector.utils;

import java.io.FileInputStream;
import java.net.http.HttpClient;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

@Component
public class ZephyrUtils {

  private static final Logger logger = LoggerFactory.getLogger(ZephyrUtils.class);
  private TestCaseOperationsService testCaseOperationsService;

  public ZephyrUtils(TestCaseOperationsService testCaseOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
  }

  /**
   * Performs actions based on the current orchestration status of a test case.
   *
   * @param testCase The test case for which status-based actions are to be handled.
   * @throws Exception If any operation within the method fails, throwing an exception to indicate
   *     failure.
   */
  public void handleStatusBasedActions(TestCase testCase) throws Exception {
    switch (testCase.getOrchestrationStatus()) {
      case "Executed":
        logger.debug("Test executed, updating to Completed.");
        testCaseOperationsService.updateStatus(
            testCase.getId(), OrchestrationStatusEnum.COMPLETED.toString());
        break;
      case "Cancelled":
        logger.debug("Test cancelled");
        testCaseOperationsService.updateNotes(testCase.getId(), "Cancelled");
        break;
      default:
        logger.info(
            "No additional action required for status {} in testCase {}",
            testCase.getOrchestrationStatus(),
            testCase.getId());
    }
  }

  /**
   * Creates an instance of HttpClient that trusts a custom SSL certificate.
   *
   * @return A configured HttpClient instance that trusts the specified certificate.
   * @throws Exception If any step in the process fails, such as loading the certificate file,
   *     initializing the SSL context, or creating the HttpClient.
   */
  public HttpClient createHttpClientWithCustomCert() throws Exception {
    String certFilePath = "/app/certs/zephyr_cert.pem";
    FileInputStream fis = new FileInputStream(certFilePath);
    CertificateFactory cf = CertificateFactory.getInstance("X.509");
    X509Certificate caCert = (X509Certificate) cf.generateCertificate(fis);
    fis.close();

    KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
    keyStore.load(null, null);
    keyStore.setCertificateEntry("caCert", caCert);

    TrustManagerFactory tmf =
        TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
    tmf.init(keyStore);

    SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
    sslContext.init(null, tmf.getTrustManagers(), null);

    return HttpClient.newBuilder().sslContext(sslContext).build();
  }
}
