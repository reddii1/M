package com.dwp.tamiddlewarejava.zephyrconnector.service.executiondetails;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.utils.RestUtil;
import com.dwp.tamiddlewarejava.zephyrconnector.utils.ZephyrUtils;

@Service
public class UpdateExecutionDetailsService {

  private static final Logger logger = LoggerFactory.getLogger(UpdateExecutionDetailsService.class);
  private @Value("${zephyr.url}") String zephyrUrl;
  private @Value("${zephyr.username}") String zephyrUsername;
  private @Value("${zephyr.password}") String zephyrPassword;

  private ZephyrUtils zephyrUtils;

  public UpdateExecutionDetailsService(ZephyrUtils zephyrUtils) {
    this.zephyrUtils = zephyrUtils;
  }

  /**
   * order Updates execution details for a given execution ID in Zephyr.
   *
   * @param executionId Unique identifier for the execution to be updated.
   * @param status New status code for the execution.
   * @param testerId Identifier for the tester updating the execution.
   * @param duration Execution duration to be updated.
   * @param notes Additional notes to include with the execution update.
   */
  public void updateExecutionDetails(
      int executionId, int status, int testerId, long duration, String notes) {

    logger.debug("Updating execution details");

    // Build the URL and HTTP request for updating execution details.
    String url = buildUrl(executionId, status, testerId, duration);
    HttpRequest request = buildHttpRequest(url, notes);

    // Send the HTTP request to Zephyr.
    sendRequest(request);
  }

  private String buildUrl(int executionId, int status, int testerId, long duration) {
    return zephyrUrl
        + "/flex/services/rest/latest/execution/"
        + executionId
        + "?status="
        + status
        + "&testerid="
        + testerId
        + "&allExecutions=true&includeanyoneuser=true&time="
        + duration;
  }

  /**
   * Creates an HTTP PUT request to interact with the Zephyr Update Execution Details API.
   *
   * @param url The URL to which the request will be sent.
   * @param notes Notes relating to the test case.
   * @return An HttpRequest object ready for execution.
   */
  private HttpRequest buildHttpRequest(String url, String notes) {
    String json = String.format("{\"notes\":\"%s\"}", notes);
    return HttpRequest.newBuilder()
        .uri(URI.create(url))
        .PUT(HttpRequest.BodyPublishers.ofString(json))
        .header("Authorization", RestUtil.createBasicAuthHeader(zephyrUsername, zephyrPassword))
        .header("Content-Type", "application/json")
        .build();
  }

  /**
   * Sends an HTTP PUT request to the Zephyr Update Execution Details API using a custom-configured
   * HttpClient.
   *
   * @param request The HttpRequest object representing the request to be sent.
   */
  private void sendRequest(HttpRequest request) {
    HttpClient client = null;
    try {
      // Create an HttpClient with custom SSL certification if required.
      client = zephyrUtils.createHttpClientWithCustomCert();
    } catch (Exception e) {
      logger.error("Error creating HTTP client: {}", e.getMessage(), e);
      return;
    }
    try {
      // Send the request and handle the response.
      HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

      // Log success or failure based on the HTTP response status code.
      if (response.statusCode() != 200) {
        logger.error("Failed to update execution details. HTTP status: {}", response.statusCode());
      }
    } catch (Exception e) {
      logger.error("Error while sending request: {}", e.getMessage(), e);
    }
  }
}
