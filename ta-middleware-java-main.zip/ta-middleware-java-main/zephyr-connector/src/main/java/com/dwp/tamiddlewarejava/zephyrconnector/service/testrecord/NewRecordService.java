package com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.model.testexecution.ExecutionDetails;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;
import com.dwp.tamiddlewarejava.shared.utils.StringUtil;
import com.dwp.tamiddlewarejava.zephyrconnector.service.executiondetails.GetExecutionDetailsService;

@Service
public class NewRecordService {

  private static final Logger logger = LoggerFactory.getLogger(NewRecordService.class);
  private GetExecutionDetailsService getExecutionDetailsService;
  private TestCaseOperationsService testCaseOperationsService;
  private @Value("${TIMEOUT_HOURS:24}") Integer timeoutHours;

  public NewRecordService(
      GetExecutionDetailsService getExecutionDetailsService,
      TestCaseOperationsService testCaseOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
    this.getExecutionDetailsService = getExecutionDetailsService;
  }

  /**
   * Processes a new test case record by determining the test provider and attempting to fetch
   * execution details for the test case.
   *
   * @param testCase The new test case to be processed.
   */
  public void handleNewRecord(TestCase testCase) {
    Timestamp now = Timestamp.valueOf(LocalDateTime.now());

    ExecutionDetails executionDetails = null;
    String executionDetailsAtid = null;
    try {
      executionDetails =
          getExecutionDetailsService.getExecutionDetails(
              testCase.getTcid(), testCase.getRid(), testCase.getCpid(), testCase.getId());
      if (executionDetails != null) {
        executionDetailsAtid = executionDetails.getAtid();
      }
    } catch (Exception e) {
      logger.error("Error getting execution details: {}", e.getMessage(), e);
    }

    String provider = "Nectar";

    if (!StringUtil.isValidUUID(executionDetailsAtid)) {
      provider = "TestComplete";
    }

    try {
      testCaseOperationsService.updateTestCase(testCase, executionDetails, provider);

      if (executionDetails.getAtid() == null || executionDetails.getAtid().isEmpty()) {
        logger.error("ATID not defined");
        testCaseOperationsService.updateStatusAndOutcome(
            testCase.getId(),
            OrchestrationStatusEnum.EXECUTED.toString(),
            TestOutcomeEnum.ATID_NOT_DEFINED.toString(),
            now);
      } else if (executionDetails.getAtidHost() == null
          || executionDetails.getAtidHost().isEmpty()) {
        logger.error("ATID Host not defined");
        testCaseOperationsService.updateStatusAndOutcome(
            testCase.getId(),
            OrchestrationStatusEnum.EXECUTED.toString(),
            TestOutcomeEnum.MW_HOST_NOT_DEFINED.toString(),
            now);
      }
    } catch (Exception e) {
      logger.error("Error updating test case for new record: {}", e.getMessage(), e);
    }
  }
}
