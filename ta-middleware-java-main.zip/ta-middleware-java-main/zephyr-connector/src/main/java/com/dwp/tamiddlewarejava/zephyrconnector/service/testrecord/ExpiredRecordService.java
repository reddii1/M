package com.dwp.tamiddlewarejava.zephyrconnector.service.testrecord;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

@Service
public class ExpiredRecordService {

  private static final Logger logger = LoggerFactory.getLogger(ExpiredRecordService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private @Value("${TIMEOUT_HOURS:24}") Integer timeoutHours;

  public ExpiredRecordService(TestCaseOperationsService testCaseOperationsService) {
    this.testCaseOperationsService = testCaseOperationsService;
  }

  /**
   * Handles the expiration of a test case record by updating its status and notes.
   *
   * @param testCase The expired test case to be processed.
   * @param now The current timestamp marking the expiration time.
   */
  public void handleExpiredRecord(TestCase testCase, Timestamp now) {
    try {
      testCaseOperationsService.updateStatusAndOutcome(
          testCase.getId(),
          OrchestrationStatusEnum.EXECUTED.toString(),
          TestOutcomeEnum.TIMED_OUT.toString(),
          now);
      logger.error(
          "Record {} expired, max hours allowed from request time is {}",
          testCase.getId(),
          timeoutHours);
      testCaseOperationsService.updateNotes(testCase.getId(), "Request time is before expiry");
    } catch (Exception e) {
      logger.error("Error updating record status", e);
    }
  }
}
