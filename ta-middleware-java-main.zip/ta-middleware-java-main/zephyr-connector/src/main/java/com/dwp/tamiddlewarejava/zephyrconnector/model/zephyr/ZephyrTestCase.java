package com.dwp.tamiddlewarejava.zephyrconnector.model.zephyr;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ZephyrTestCase {
  private List<CustomFieldValue> customFieldValues;
  private int testcaseId;
}
