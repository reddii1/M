package com.dwp.tamiddlewarejava.zephyrconnector.model.zephyr;

import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;

public class OutcomeMapper {

  public static int mapOutcome(String outcome) {
    if (outcome.equals(TestOutcomeEnum.NOT_EXECUTED.toString())) {
      return 10;
    } else if (outcome.equals(TestOutcomeEnum.PASSED.toString())) {
      return 1;
    } else if (outcome.equals(TestOutcomeEnum.FAILED.toString())) {
      return 2;
    } else if (outcome.equals(TestOutcomeEnum.IN_PROGRESS.toString())) {
      return 3;
    } else if (outcome.equals(TestOutcomeEnum.FAILED_TO_EXECUTE.toString())) {
      return 12;
    } else if (outcome.equals(TestOutcomeEnum.TIMED_OUT.toString())) {
      return 13;
    } else if (outcome.equals(TestOutcomeEnum.STOPPED_IN_MIDDLEWARE.toString())) {
      return 14;
    } else if (outcome.equals(TestOutcomeEnum.MW_HOST_DOES_NOT_EXIST.toString())) {
      return 15;
    } else if (outcome.equals(TestOutcomeEnum.ATID_NOT_DEFINED.toString())) {
      return 17;
    } else if (outcome.equals(TestOutcomeEnum.MW_HOST_NOT_DEFINED.toString())) {
      return 18;
    } else {
      return -1;
    }
  }
}
