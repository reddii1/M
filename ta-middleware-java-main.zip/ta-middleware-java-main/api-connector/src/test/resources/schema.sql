drop table if exists testcases;
drop table if exists hosts;
drop table if exists users;
drop table if exists auditlog;
drop type if exists testproviders;
drop type if exists roles;
drop type if exists useraction;


CREATE TABLE testcases (
	id uuid PRIMARY KEY,
	tcid int NOT NULL,
	rid int NOT NULL,
	cid int NOT NULL,
	cpid int NOT NULL,
	eid int,
	testerid int,
	atid varchar,
	requesttime timestamp,
	testprovider varchar,
	orchestrationstatus varchar NOT NULL,
	startattempts int,
	connectordata json,
	testoutcome varchar,
	starttime timestamp,
	duration int,
	notes varchar,
	targetcli character varying,
    spoofcli character varying,
	atidhost varchar
);

CREATE TYPE testproviders AS ENUM (
    'TestComplete',
    'Nectar'
);

CREATE TABLE hosts (
	id SERIAL,
	zephyrhostid varchar NOT NULL,
	hostname varchar PRIMARY KEY,
	hoststatus varchar NOT NULL,
	projectsroot varchar NOT NULL,
	teamname varchar NOT NULL,
	testprovider testproviders,
	username varchar NOT NULL,
	password varchar NOT NULL
);

CREATE TYPE roles AS ENUM (
    'test_admin',
    'test_viewer',
    'test_runner'
);

CREATE TABLE users (
	id SERIAL,
    username character varying NOT NULL PRIMARY KEY,
	firstname character varying,
    lastname character varying,
    role roles,
	team character varying DEFAULT NULL,

    passwordexpiresutc timestamp,
    password BINARY,
    oldpasswords BINARY,
    salt BINARY NOT NULL,

    suspendeduser boolean DEFAULT false NOT NULL,
	deleteduser boolean DEFAULT false NOT NULL
);

CREATE TYPE useraction AS ENUM (
	'login',
	'logout',
    'suspend_account',
	'unsuspend_account',
	'delete_account',
	'undelete_account',
	'change_password',
	'start_test',
	'create_user',
	'delete_user',
	'role_change',
	'team_change',
	'create_host',
	'delete_host',
	'change_host_name',
	'change_host_status',
	'change_host_project_root',
	'change_host_team',
	'change_host_test_provider',
	'change_host_username',
	'change_host_password'
);

CREATE TABLE auditlog (
	id SERIAL,
	username character varying NOT NULL,
    action useraction NOT NULL,
	details character varying,
	date timestamp NOT NULL
);