package com.dwp.tamiddlewarejava.apiconnector;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.dwp.tamiddlewarejava.apiconnector.model.user.CreateUser;
import com.dwp.tamiddlewarejava.apiconnector.model.user.RoleEnum;
import com.dwp.tamiddlewarejava.apiconnector.model.user.User;
import com.dwp.tamiddlewarejava.apiconnector.service.authentication.PasswordService;
import com.dwp.tamiddlewarejava.apiconnector.service.host.HostService;
import com.dwp.tamiddlewarejava.apiconnector.service.user.UserService;
import com.dwp.tamiddlewarejava.shared.utils.PasswordUtils;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class UserControllerTest {

  @Autowired private MockMvc mockMvc;

  @MockBean private UserService userService;

  @MockBean private PasswordService passwordService;

  @MockBean private PasswordUtils passwordValidator;

  @MockBean private HostService hostService;

  @Test
  void findAllUsers_ReturnsOk() throws Exception {
    when(userService.getAllUsers()).thenReturn(Arrays.asList(new User(), new User()));

    this.mockMvc
        .perform(get("/api/users/getAll"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").isArray())
        .andExpect(jsonPath("$").isNotEmpty());
  }

  @Test
  void findUserById_UserExists_ReturnsOk() throws Exception {
    when(userService.findById(1)).thenReturn(Optional.of(new User()));

    this.mockMvc
        .perform(get("/api/users/1"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").exists());
  }

  @Test
  void findUserById_UserDoesNotExist() throws Exception {
    when(userService.findById(1)).thenReturn(Optional.empty());

    this.mockMvc
        .perform(get("/api/users/1"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").doesNotExist());
  }

  @Test
  void createUser_ValidInput_ReturnsCreated() throws Exception {
    CreateUser newUser = new CreateUser();

    when(userService.createUser(any(CreateUser.class)))
        .thenReturn(Map.of("message", "User created"));

    this.mockMvc
        .perform(
            post("/api/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"property1\": \"value1\", \"property2\": \"value2\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.message").value("User created"));
  }

  @Test
  void getRole_UserExists_ReturnsOk() throws Exception {
    when(userService.findUserRole("username")).thenReturn(RoleEnum.test_admin);

    this.mockMvc
        .perform(get("/api/users/username/roles"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").value("test_admin"));
  }

  @Test
  void loginUser_ValidCredentials_ReturnsOk() throws Exception {
    when(userService.findUserByUsername("username")).thenReturn(new User());
    when(passwordService.checkPassword("username", "password"))
        .thenReturn(
            ResponseEntity.status(HttpStatus.OK).body(Map.of("message", "Login successful")));

    this.mockMvc
        .perform(
            post("/api/users/username/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content("password"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.message").value("Login successful"));
  }

  @Test
  @WithMockUser(
      username = "username",
      authorities = {"ROLE_USER"})
  void updateUserPassword_ValidInput_ReturnsOk() throws Exception {
    when(passwordService.sanitizeCandidatePassword("newPassword"))
        .thenReturn("newPassword3245324!!£");
    when(passwordService.updatePassword(anyString(), anyString())).thenReturn(true);

    this.mockMvc
        .perform(
            post("/api/users/username/password")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"loggedInUser\": \"username\", \"password\": \"newPassword\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.message").value("Successfully updated password"));
  }

  @Test
  @WithMockUser(
      username = "regularUser",
      authorities = {"ROLE_USER"})
  void updateUserPassword_NotOwnPasswordAndNotAdmin_ReturnsForbidden() throws Exception {

    // Act & Assert: Perform the request and expect a 403 Forbidden response
    mockMvc
        .perform(
            post("/api/users/otherUser/password")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"loggedInUser\": \"username\", \"password\": \"newPassword\"}"))
        .andExpect(status().isForbidden());
  }

  @Test
  @WithMockUser(
      username = "regularUser",
      authorities = {"ROLE_test_admin"})
  void updateUserPassword_NotOwnPasswordAndAdmin_ReturnsOk() throws Exception {
    when(passwordService.sanitizeCandidatePassword("newPassword"))
        .thenReturn("newPassword3245324!!£");
    when(passwordService.updatePassword(anyString(), anyString())).thenReturn(true);

    // Act & Assert: Perform the request and expect a 403 Forbidden response
    mockMvc
        .perform(
            post("/api/users/otherUser/password")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"loggedInUser\": \"username\", \"password\": \"newPassword\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.message").value("Successfully updated password"));
  }

  @Test
  void updateUser_ValidInput_ReturnsOk() throws Exception {

    this.mockMvc
        .perform(
            put("/api/users/1/field")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"value\": \"newValue\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.message").value("Successfully updated user"));
  }
}
