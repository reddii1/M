package com.dwp.tamiddlewarejava.apiconnector;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.dwp.tamiddlewarejava.apiconnector.model.audit.AuditEntry;
import com.dwp.tamiddlewarejava.apiconnector.service.audit.AuditService;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class AuditLogControllerTest {

  @Autowired private MockMvc mockMvc;

  @MockBean private AuditService auditService;

  @Test
  void getAuditLog_ValidInput_ReturnsOk() throws Exception {
    when(auditService.getPaginatedAuditLog(0, 10))
        .thenReturn(Arrays.asList(new AuditEntry(), new AuditEntry()));

    this.mockMvc
        .perform(get("/api/auditlog?startIndex=0&rowCount=10"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").isArray())
        .andExpect(jsonPath("$").isNotEmpty());
  }

  @Test
  void getAuditLog_ServiceThrowsException_ReturnsInternalServerError() throws Exception {
    when(auditService.getPaginatedAuditLog(0, 10)).thenThrow(new RuntimeException());

    this.mockMvc
        .perform(get("/api/auditlog?startIndex=0&rowCount=10"))
        .andExpect(status().isInternalServerError());
  }
}
