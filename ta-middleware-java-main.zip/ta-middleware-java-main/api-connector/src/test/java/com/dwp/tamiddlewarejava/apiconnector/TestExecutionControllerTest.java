package com.dwp.tamiddlewarejava.apiconnector;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.dwp.tamiddlewarejava.apiconnector.model.testexecution.ExecuteRequest;
import com.dwp.tamiddlewarejava.apiconnector.service.testexecution.TestExecutionService;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class TestExecutionControllerTest {

  @Autowired private MockMvc mockMvc;

  @MockBean private TestExecutionService executeTestService;

  @Test
  void execute_NoTestCasesProvided_ReturnsBadRequest() throws Exception {
    ExecuteRequest request = new ExecuteRequest();

    this.mockMvc
        .perform(
            post("/api/execute")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"testcaseIds\": [], \"rid\": \"1\", \"cid\": \"1\", \"cpid\": \"1\"}"))
        .andExpect(status().isBadRequest())
        .andExpect(content().string(containsString("No test cases provided.")));
  }

  @Test
  void execute_TestCasesProvided_ReturnsOk() throws Exception {
    ExecuteRequest request = new ExecuteRequest();
    request.setTestCaseIds(Arrays.asList(1, 2));

    this.mockMvc
        .perform(
            post("/api/execute")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    "{\"testcaseIds\": [\"1\", \"2\"], \"rid\": \"1\", \"cid\": \"1\", \"cpid\": \"1\"}"))
        .andExpect(status().isOk());
  }
}
