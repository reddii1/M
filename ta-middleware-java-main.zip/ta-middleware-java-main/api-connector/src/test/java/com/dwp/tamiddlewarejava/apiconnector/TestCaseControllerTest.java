package com.dwp.tamiddlewarejava.apiconnector;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.dwp.tamiddlewarejava.apiconnector.service.host.HostService;
import com.dwp.tamiddlewarejava.apiconnector.service.testcase.TestCaseService;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class TestCaseControllerTest {

  @Autowired private MockMvc mockMvc;

  @MockBean private TestCaseService testCaseService;

  @MockBean private HostService hostService;

  @Test
  void getTestCases_ValidInput_ReturnsOk() throws Exception {
    when(testCaseService.findPaginatedTestCases(0, 10))
        .thenReturn(Arrays.asList(new TestCase(), new TestCase()));

    this.mockMvc
        .perform(get("/api/testcases/find?startIndex=0&rowCount=10&filter="))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").isArray())
        .andExpect(jsonPath("$").isNotEmpty());
  }

  @Test
  void getTestCases_ServiceThrowsException_ReturnsInternalServerError() throws Exception {
    when(testCaseService.findPaginatedTestCases(0, 10)).thenThrow(new RuntimeException());

    this.mockMvc
        .perform(get("/api/testcases/find?startIndex=0&rowCount=10&filter="))
        .andExpect(status().isInternalServerError());
  }
}
