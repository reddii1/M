package com.dwp.tamiddlewarejava.apiconnector;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.Optional;

import com.dwp.tamiddlewarejava.apiconnector.repository.HostRepository;
import com.dwp.tamiddlewarejava.apiconnector.service.servicestatus.ServiceStatusService;
import com.dwp.tamiddlewarejava.shared.model.enums.TestProviderEnum;
import com.dwp.tamiddlewarejava.shared.model.servicestatus.ServiceStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.dwp.tamiddlewarejava.apiconnector.service.host.HostService;
import com.dwp.tamiddlewarejava.shared.model.host.Host;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class HostControllerTest {

  @Autowired private MockMvc mockMvc;

  @MockBean private HostService hostService;
  @MockBean private ServiceStatusService serviceStatusService;

  @Test
  void getAllHosts_ReturnsOk() throws Exception {
    when(hostService.getAllHosts()).thenReturn(Arrays.asList(new Host(), new Host()));

    this.mockMvc
        .perform(get("/api/hosts/getAll"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").isArray())
        .andExpect(jsonPath("$").isNotEmpty());
  }

  @Test
  void findById_HostExists_ReturnsOk() throws Exception {
    when(hostService.findById(1)).thenReturn(Optional.of(new Host()));

    this.mockMvc
        .perform(get("/api/hosts/1"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").exists());
  }

  @Test
  void findById_HostDoesNotExist_ReturnsOk() throws Exception {
    when(hostService.findById(1)).thenReturn(Optional.empty());

    this.mockMvc
        .perform(get("/api/hosts/1"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").doesNotExist());
  }

  @Test
  void createHost_ValidInput_ReturnsOK() throws Exception {

    // need to make sure that right mock stuff happening with my service status service
//    expect(serviceStatusService.createServiceStatus(any(ServiceStatus.class)));

    Host host = new Host();
    host.setHostName("value2");
    host.setTestProvider(TestProviderEnum.Nectar);
    this.mockMvc
        .perform(
            post("/api/hosts/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    "{\"value\": \"value1\", \"host\": \"value2\", \"loggedInUser\": \"value3\", \"testProvider\": \"Nectar\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").exists());
  }

  @Test
  void updateHost_HostExists_ReturnsOk() throws Exception {

    this.mockMvc
        .perform(
            put("/api/hosts/1/property1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    "{\"value\": \"value1\", \"host\": \"value2\", \"loggedInUser\": \"value3\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$").exists());
  }

  @Test
  void updateHost_HostDoesNotExist_ReturnsInteralError() throws Exception {
    doThrow(new RuntimeException())
        .when(hostService)
        .updateHost(anyInt(), anyString(), any(Object.class), anyString(), anyString());

    this.mockMvc
        .perform(
            put("/api/hosts/1/property1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    "{\"value\": \"value1\", \"host\": \"value2\", \"loggedInUser\": \"value3\"}"))
        .andExpect(status().isInternalServerError());
  }

  @Test
  void deleteHost_HostExists_ReturnsOK() throws Exception {

    this.mockMvc
        .perform(
            delete("/api/hosts/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"host\": \"value2\", \"loggedInUser\": \"value3\"}"))
        .andExpect(status().isOk());
  }

  @Test
  void deleteHost_HostDoesNotExist_InternalError() throws Exception {
    doThrow(new RuntimeException())
        .when(hostService)
        .deleteHost(anyInt(), anyString(), anyString());

    this.mockMvc
        .perform(
            delete("/api/hosts/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"host\": \"value2\", \"loggedInUser\": \"value3\"}"))
        .andExpect(status().isInternalServerError());
  }
}
