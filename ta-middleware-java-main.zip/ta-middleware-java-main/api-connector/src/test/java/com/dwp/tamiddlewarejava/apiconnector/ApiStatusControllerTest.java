package com.dwp.tamiddlewarejava.apiconnector;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.dwp.tamiddlewarejava.apiconnector.service.api.ApiStatusService;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class ApiStatusControllerTest {

  @Autowired private MockMvc mockMvc;

  @MockBean private ApiStatusService apiStatusService;

  @Test
  void getStatus_DbConnected_ReturnsOk() throws Exception {
    when(apiStatusService.isDatabaseConnected()).thenReturn(true);

    this.mockMvc
        .perform(get("/api/status"))
        .andExpect(status().isOk())
        .andExpect(content().string(containsString("Ok")));
  }

  @Test
  void getStatus_DbNotConnected_ReturnsServiceUnavailable() throws Exception {
    when(apiStatusService.isDatabaseConnected()).thenReturn(false);

    this.mockMvc
        .perform(get("/api/status"))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().string(containsString("DB is not reachable")));
  }
}
