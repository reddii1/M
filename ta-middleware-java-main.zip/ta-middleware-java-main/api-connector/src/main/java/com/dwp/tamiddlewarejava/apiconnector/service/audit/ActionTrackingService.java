package com.dwp.tamiddlewarejava.apiconnector.service.audit;

import java.lang.reflect.Field;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.apiconnector.model.audit.AuditActions;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Service
public class ActionTrackingService {

  private final Logger logger = LoggerFactory.getLogger(ActionTrackingService.class);
  private final EntityManager entityManager;

  public ActionTrackingService(EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  /**
   * Logs a user action into the audit log table in the database.
   *
   * @param username The username of the user who performed the action.
   * @param action The key representing the action performed.
   * @param details A descriptive text providing more context about the action.
   */
  @Transactional
  public void logUserAction(String username, String action, String details) {
    try {
      MDC.put("loggedInUser", username);
      String actionValue = getActionValue(action);
      if (actionValue == null) {
        logger.error("Action key not found: {}", action);
        return;
      }

      entityManager
          .createNativeQuery(
              "INSERT INTO auditlog (USERNAME, ACTION, DETAILS, DATE) VALUES (?, ?, ?, now())")
          .setParameter(1, username)
          .setParameter(2, actionValue)
          .setParameter(3, details)
          .executeUpdate();

      logger.debug(details);
    } catch (Exception e) {
      logger.error("Error logging user action", e);
    } finally {
      MDC.clear();
    }
  }

  /**
   * Retrieves the string representation of an action based on its key.
   *
   * @param actionKey The key corresponding to the action whose value is to be retrieved.
   * @return The string value of the action if found; null otherwise.
   */
  private String getActionValue(String actionKey) {
    try {
      Field field = AuditActions.class.getField(actionKey);
      return (String) field.get(null);
    } catch (NoSuchFieldException | IllegalAccessException e) {
      logger.error("Error retrieving action value", e);
      return null;
    }
  }
}
