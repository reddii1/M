package com.dwp.tamiddlewarejava.apiconnector.model.testexecution;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ExecuteRequest {
  @JsonProperty("testcaseIds")
  private List<Integer> testCaseIds;
  private List<String> testcaseNames;

  private int rid;
  private int cid;
  private int cpid;

  private int projectId;
  private String projectName;
  private String releaseName;
  private String cname;
  private String cyclePhaseName;
  private String username;

  @Override
  public String toString() {
    return "ExecuteRequest{" +
            "testCaseIds=" + testCaseIds +
            ", rid=" + rid +
            ", cid=" + cid +
            ", cpid=" + cpid +
            ", projectId=" + projectId +
            ", projectName='" + projectName + '\'' +
            ", releaseName='" + releaseName + '\'' +
            ", cname='" + cname + '\'' +
            ", cyclePhaseName='" + cyclePhaseName + '\'' +
            ", username='" + username + '\'' +
            ", testcaseNames=" + testcaseNames +
            '}';
  }
}
