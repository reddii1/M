package com.dwp.tamiddlewarejava.apiconnector.service.authentication;

import java.security.PrivateKey;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.dwp.tamiddlewarejava.apiconnector.model.user.RoleEnum;

import io.jsonwebtoken.Jwts;

@Component
public class JWTService {

  private final PrivateKey privateKey;

  public JWTService(PrivateKey privateKey) {
    this.privateKey = privateKey;
  }

  /**
   * Generates a JSON Web Token (JWT) for the specified user and role.
   *
   * @param userId The unique identifier for the user.
   * @param role The user's role, which determines access levels within the system.
   * @return A signed JWT string.
   */
  public String mintJWTToken(String userId, RoleEnum role) {
    // Creating JWT claims
    Map<String, Object> claims = getJWTClaims(userId, role);

    // Building the JWT token
    return Jwts.builder()
        .setClaims(claims)
        .signWith(privateKey, io.jsonwebtoken.SignatureAlgorithm.RS256)
        .compact();
  }

  /**
   * Prepares the claims for the JWT based on user information and role.
   *
   * @param userId The unique identifier of the user.
   * @param role The role of the user in the system.
   * @return A map of claims to be included in the JWT.
   */
  private static Map<String, Object> getJWTClaims(String userId, RoleEnum role) {
    Map<String, Object> claims = new HashMap<>();

    claims.put("sub", userId);
    claims.put("iss", "Test Orchestration Middleware/ Java");
    claims.put("aud", "Test Orchestration UI");
    claims.put("role", role.toString());

    ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Europe/London"));
    claims.put("iat", now.toEpochSecond());
    claims.put("nbf", now.minusMinutes(2).toEpochSecond());

    // Set JWT expiry time to 23:59:59 today
    ZonedDateTime endOfDay = now.withHour(23).withMinute(59).withSecond(59).withNano(0);
    claims.put("exp", endOfDay.toEpochSecond());
    return claims;
  }
}
