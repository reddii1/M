package com.dwp.tamiddlewarejava.apiconnector.model.user;

import java.time.LocalDateTime;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreateUser {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private String username;

  private String firstName;
  private String lastName;
  private String role;
  private String team;
  private LocalDateTime passwordExpiresUtc;
  private Boolean suspendedUser;
  private Boolean deletedUser;
  private String loggedInUser;
}
