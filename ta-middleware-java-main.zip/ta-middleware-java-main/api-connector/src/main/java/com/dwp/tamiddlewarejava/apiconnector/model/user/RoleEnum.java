package com.dwp.tamiddlewarejava.apiconnector.model.user;

public enum RoleEnum {
  test_admin("test_admin"),
  test_runner("test_runner"),
  test_viewer("test_viewer");

  private final String role;

  RoleEnum(String role) {
    this.role = role;
  }

  @Override
  public String toString() {
    return role;
  }
}
