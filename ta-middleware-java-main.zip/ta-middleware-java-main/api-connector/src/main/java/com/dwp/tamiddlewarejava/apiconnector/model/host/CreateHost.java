package com.dwp.tamiddlewarejava.apiconnector.model.host;

import com.dwp.tamiddlewarejava.shared.model.host.Host;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CreateHost extends Host {
  private String loggedInUser;
}
