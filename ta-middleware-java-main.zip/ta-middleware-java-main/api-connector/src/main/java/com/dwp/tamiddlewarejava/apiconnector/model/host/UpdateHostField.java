package com.dwp.tamiddlewarejava.apiconnector.model.host;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class UpdateHostField {
  private Object value; // Use Object type to allow any type of value
  private String host;
  private String loggedInUser;
}
