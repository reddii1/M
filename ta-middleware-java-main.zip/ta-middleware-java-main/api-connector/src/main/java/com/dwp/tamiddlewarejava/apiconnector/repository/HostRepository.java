package com.dwp.tamiddlewarejava.apiconnector.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.dwp.tamiddlewarejava.shared.model.host.Host;

public interface HostRepository extends JpaRepository<Host, Integer> {

  @Query("SELECT h FROM Host h")
  List<Host> getAllHosts();

  @Query("SELECT h FROM Host h WHERE h.id = ?1")
  List<Host> getHost(String hostId);



  @Transactional
  @Modifying
  @Query(
      value =
          "INSERT INTO hosts (zephyrhostid, hostname, hoststatus, projectsroot, teamname, testprovider, username, password) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
      nativeQuery = true)
  void createHost(
      String zephyrHostId,
      String hostName,
      String hostStatus,
      String projectsRoot,
      String teamName,
      String testProvider,
      String username,
      String password);

  @Transactional
  @Modifying
  @Query("DELETE FROM Host h WHERE h.id=?1")
  void deleteHost(Integer hostId);
}
