package com.dwp.tamiddlewarejava.apiconnector.model.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class UpdateUserField {
  private Object value; // Use Object type to allow any type of value
  private String user;
  private String loggedInUser;
}
