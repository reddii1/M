package com.dwp.tamiddlewarejava.apiconnector.model.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class UpdatePassword {
  private String password;
  private String loggedInUser;
}
