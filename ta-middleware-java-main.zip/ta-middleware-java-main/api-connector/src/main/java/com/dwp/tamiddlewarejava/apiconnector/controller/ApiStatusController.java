package com.dwp.tamiddlewarejava.apiconnector.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dwp.tamiddlewarejava.apiconnector.model.api.ApiStatus;
import com.dwp.tamiddlewarejava.apiconnector.service.api.ApiStatusService;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api")
public class ApiStatusController {

  private ApiStatusService apiStatusService;

  public ApiStatusController(ApiStatusService apiStatusService) {
    this.apiStatusService = apiStatusService;
  }

  @GetMapping("/status")
  public ResponseEntity<ApiStatus> getStatus() {
    boolean isDbConnected = apiStatusService.isDatabaseConnected();
    if (isDbConnected) {
      return ResponseEntity.ok(new ApiStatus("Ok"));
    } else {
      return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
          .body(new ApiStatus("DB is not reachable"));
    }
  }
}
