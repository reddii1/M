package com.dwp.tamiddlewarejava.apiconnector.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.dwp.tamiddlewarejava.apiconnector.model.user.RoleEnum;
import com.dwp.tamiddlewarejava.apiconnector.model.user.User;

public interface UserRepository extends JpaRepository<User, Integer> {

  @Query("SELECT u FROM User u WHERE u.deletedUser=false ORDER BY u.username ASC")
  List<User> getAllUsers();

  @Query(
      "SELECT u.role FROM User u WHERE u.username=?1 AND u.suspendedUser=false AND u.deletedUser=false")
  RoleEnum findUserRole(String username);

  @Query(
      "SELECT u FROM User u WHERE u.username=?1 AND u.suspendedUser=false AND u.deletedUser=false")
  User findUserByUsername(String username);

  @Query(
      "SELECT u.password FROM User u WHERE u.username=?1 AND u.suspendedUser=false AND u.deletedUser=false")
  byte[] getActualPasswordHash(String username);

  @Query(
      value =
          "SELECT unnest(oldpasswords[1\\:\\5]) AS oldpasswords FROM users WHERE username=:username",
      nativeQuery = true)
  List<byte[]> getOldPasswordHashes(@Param("username") String username);

  @Query(
      "SELECT u.salt FROM User u WHERE u.username=?1 AND u.suspendedUser=false AND u.deletedUser=false")
  byte[] getUserSalt(String username);

  @Query(
      "SELECT u.passwordExpiresUtc FROM User u WHERE u.username=?1 AND u.suspendedUser=false AND u.deletedUser=false")
  LocalDateTime getPasswordExpiry(String username);

  @Transactional
  @Modifying
  @Query(value = "CALL set_new_password(?1, ?2)", nativeQuery = true)
  void setNewPassword(byte[] passwordHash, String username);

  @Transactional
  @Modifying
  @Query("UPDATE User u SET u.deletedUser=true WHERE id=?1")
  void deleteUser(Integer userId);
}
