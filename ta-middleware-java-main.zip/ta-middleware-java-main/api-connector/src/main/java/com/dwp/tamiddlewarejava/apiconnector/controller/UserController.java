package com.dwp.tamiddlewarejava.apiconnector.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dwp.tamiddlewarejava.apiconnector.model.user.CreateUser;
import com.dwp.tamiddlewarejava.apiconnector.model.user.DeleteUser;
import com.dwp.tamiddlewarejava.apiconnector.model.user.RoleEnum;
import com.dwp.tamiddlewarejava.apiconnector.model.user.UpdatePassword;
import com.dwp.tamiddlewarejava.apiconnector.model.user.UpdateUserField;
import com.dwp.tamiddlewarejava.apiconnector.model.user.User;
import com.dwp.tamiddlewarejava.apiconnector.service.audit.ActionTrackingService;
import com.dwp.tamiddlewarejava.apiconnector.service.authentication.PasswordService;
import com.dwp.tamiddlewarejava.apiconnector.service.user.UserService;
import com.dwp.tamiddlewarejava.shared.utils.PasswordUtils;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api/users")
public class UserController {

  private final Logger logger = LoggerFactory.getLogger(UserController.class);
  private UserService userService;
  private PasswordUtils passwordValidator;
  private PasswordService passwordService;
  private ActionTrackingService actionTracking;

  public UserController(
      UserService userService,
      PasswordUtils passwordValidator,
      PasswordService passwordService,
      ActionTrackingService actionTracking) {
    this.userService = userService;
    this.passwordValidator = passwordValidator;
    this.passwordService = passwordService;
    this.actionTracking = actionTracking;
  }

  @GetMapping("/getAll")
  public List<User> getAllUsers() {
    return userService.getAllUsers();
  }

  @GetMapping("/{id}")
  public Optional<User> findById(@PathVariable Integer id) {
    return userService.findById(id);
  }

  @PostMapping
  public ResponseEntity<Map<String, Object>> createUser(@RequestBody CreateUser user) {
    try {
      Map<String, Object> createUserResponse = userService.createUser(user);
      return ResponseEntity.status(HttpStatus.OK).body(createUserResponse);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Error creating user: " + e.getMessage()));
    }
  }

  @GetMapping("/{username}/roles")
  public RoleEnum getRole(@PathVariable String username) {
    return userService.findUserRole(username);
  }

  @PostMapping("/{username}/login")
  public ResponseEntity<Map<String, Object>> login(
      @PathVariable String username, @RequestBody String password) {
    try {
      // Retrieve user details from the service
      User user = userService.findUserByUsername(username);

      if (user == null) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
            .body(Map.of("message", "User not found"));
      }

      return passwordService.checkPassword(username, password);
    } catch (Exception e) {
      // Log the exception using a logging framework (e.g., log4j, SLF4J)
      e.printStackTrace();
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  }

  @PostMapping("/{username}/password")
  public ResponseEntity<Map<String, Object>> updatePassword(
      @PathVariable String username,
      @AuthenticationPrincipal UserDetails currentUser,
      @RequestBody UpdatePassword updatePasswordRequest) {
    try {
      boolean isUpdatingOwnPassword = currentUser.getUsername().equalsIgnoreCase(username);
      boolean isAdmin =
          currentUser.getAuthorities().stream()
              .anyMatch(
                  grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_test_admin"));

      // If user is not updating their own password or they are not an admin, deny the
      // request
      if (!isUpdatingOwnPassword && !isAdmin) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
            .body(Map.of("message", "Users can only update their own password."));
      }
      String candidatePassword =
          passwordService.sanitizeCandidatePassword(updatePasswordRequest.getPassword());

      if (!passwordValidator.passwordDWPRequirementsMet(candidatePassword)) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(Map.of("message", "Password requirements not met"));
      }

      if (passwordService.updatePassword(candidatePassword, username)) {
        actionTracking.logUserAction(
            updatePasswordRequest.getLoggedInUser(),
            "CHANGE_PASSWORD",
            String.format("Successfully updated password for user %s", username));

        return ResponseEntity.status(HttpStatus.OK)
            .body(Map.of("message", "Successfully updated password"));
      } else {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(Map.of("message", "Password failed to update"));
      }
    } catch (Exception e) {
      logger.error("Error updating password for user {}", username, e);
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Error updating password: " + e.getMessage()));
    }
  }

  @PutMapping("/{userId}/{field}")
  public ResponseEntity<Map<String, Object>> updateUser(
      @PathVariable Integer userId,
      @PathVariable String field,
      @RequestBody UpdateUserField updateObject) {
    try {
      userService.updateUser(userId, field, updateObject.getValue());
      return ResponseEntity.status(HttpStatus.OK)
          .body(Map.of("message", "Successfully updated user"));
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Error updating user" + e.getMessage()));
    }
  }

  @DeleteMapping("/{userId}")
  public ResponseEntity<Map<String, Object>> deleteUser(
      @PathVariable Integer userId, @RequestBody DeleteUser userDeleteBody) {
    try {
      String userToBeDeleted = userDeleteBody.getUser();
      String loggedInUser = userDeleteBody.getLoggedInUser();

      userService.deleteUser(userId, loggedInUser, userToBeDeleted);
      return ResponseEntity.status(HttpStatus.OK)
          .body(Map.of("message", "Successfully deleted user"));
    } catch (Exception e) {
      logger.error("Failed to delete user: {}", userDeleteBody.getUser());
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Error deleting user" + e.getMessage()));
    }
  }
}
