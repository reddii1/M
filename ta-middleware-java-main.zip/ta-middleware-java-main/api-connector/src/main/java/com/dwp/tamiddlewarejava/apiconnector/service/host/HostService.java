package com.dwp.tamiddlewarejava.apiconnector.service.host;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.apiconnector.model.host.CreateHost;
import com.dwp.tamiddlewarejava.apiconnector.repository.HostRepository;
import com.dwp.tamiddlewarejava.apiconnector.service.audit.ActionTrackingService;
import com.dwp.tamiddlewarejava.shared.model.errors.DuplicateRecordException;
import com.dwp.tamiddlewarejava.shared.model.host.Host;
import com.dwp.tamiddlewarejava.shared.utils.EncryptionUtil;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Service
public class HostService {

  private static final Logger logger = LoggerFactory.getLogger(HostService.class);
  private HostRepository hostRepository;
  private EntityManager entityManager;
  private ActionTrackingService actionTrackingService;

  private @Value("${host.encryptionkey}") String hostsPasswordEncryptionKey;

  private static final Set<String> VALID_FIELDS =
      Set.of(
          "zephyrhostid",
          "hostname",
          "hoststatus",
          "projectsroot",
          "teamname",
          "testprovider",
          "username",
          "password");

  public HostService(
      HostRepository hostRepository,
      EntityManager entityManager,
      ActionTrackingService actionTrackingService) {
    this.hostRepository = hostRepository;
    this.entityManager = entityManager;
    this.actionTrackingService = actionTrackingService;
  }

  /**
   * Updates a specific field of a host record in the database, identified by hostId. For the
   * password field, it encrypts the new value before updating. After updating, it logs the action
   * performed for audit purposes.
   *
   * @param hostId The ID of the host record to update.
   * @param field The name of the field to update.
   * @param updateValue The new value to set for the field.
   * @param hostName The current name of the host for logging purposes.
   * @param loggedInUser The username of the user performing the update for logging purposes.
   */
  @Transactional
  public void updateHost(
      Integer hostId, String field, Object updateValue, String hostName, String loggedInUser) {
    // Validate the field name to ensure it's safe and expected
    if (!VALID_FIELDS.contains(field)) {
      throw new IllegalArgumentException("Invalid field name");
    }

    Object fieldValue = handleUpdateHostField(field, updateValue);

    // Construct SQL query
    String sql = "UPDATE hosts SET " + field + " = :updateValue WHERE id = :hostId";

    // Execute the update
    entityManager
        .createNativeQuery(sql)
        .setParameter("updateValue", fieldValue)
        .setParameter("hostId", hostId)
        .executeUpdate();

    switch (field) {
      case "hostname":
        actionTrackingService.logUserAction(
            loggedInUser,
            "UPDATE_HOST_NAME",
            String.format("Successful name change for host %s to %s", hostName, updateValue));
        break;
      case "hoststatus":
        actionTrackingService.logUserAction(
            loggedInUser,
            "UPDATE_HOST_STATUS",
            String.format("Successful status change for host %s to %s", hostName, updateValue));
        break;
      case "projectsroot":
        actionTrackingService.logUserAction(
            loggedInUser,
            "UPDATE_HOST_PROJECT_ROOT",
            String.format(
                "Successful projects root change for host %s to %s", hostName, updateValue));
        break;
      case "teamname":
        actionTrackingService.logUserAction(
            loggedInUser,
            "UPDATE_HOST_TEAM",
            String.format("Successful team name change for host %s to %s", hostName, updateValue));
        break;
      case "testprovider":
        actionTrackingService.logUserAction(
            loggedInUser,
            "UPDATE_HOST_TEST_PROVIDER",
            String.format(
                "Successful test provider change for host %s to %s", hostName, updateValue));
        break;
      case "username":
        actionTrackingService.logUserAction(
            loggedInUser,
            "UPDATE_HOST_USERNAME",
            String.format("Successful username change for host %s to %s", hostName, updateValue));
        break;
      case "password":
        actionTrackingService.logUserAction(
            loggedInUser,
            "UPDATE_HOST_PASSWORD",
            String.format("Successful password change for host %s", hostName));
        break;
      default:
        logger.warn("Unhandled user field: {}", field);
    }
  }

  /**
   * Creates a new host record in the database based on provided host details.
   *
   * @param host The details of the host to create, encapsulated in a CreateHost object.
   */
  @Transactional
  public void createHost(CreateHost host) {

    if (hostsPasswordEncryptionKey == null) {
      throw new RuntimeException("Failed to locate password decryption key");
    }

    String encryptedPassword =
        EncryptionUtil.encryptPassword(host.getPassword(), hostsPasswordEncryptionKey);

    try {
      hostRepository.createHost(
          host.getZephyrHostId(),
          host.getHostName(),
          host.getHostStatus(),
          host.getProjectsRoot(),
          host.getTeamName(),
          host.getTestProvider().toString(),
          host.getUsername(),
          encryptedPassword);

      actionTrackingService.logUserAction(
          host.getLoggedInUser(),
          "CREATE_HOST",
          String.format("Host %s successfully created", host.getHostName()));
    } catch (DataIntegrityViolationException e) {
      logger.error("Attempted to create a host that already exists: {}", host.getHostName());
      throw new DuplicateRecordException("Host with the given host name already exists.");
    }
  }

  /**
   * Retrieves all hosts from the database, decrypting their passwords before returning them.
   *
   * @return A list of Host objects with decrypted passwords.
   */
  public List<Host> getAllHosts() {
    return hostRepository.getAllHosts().stream()
        .map(
            host -> {
              host.setPassword(transformPassword(host.getPassword()));
              return host;
            })
        .collect(Collectors.toList());
  }

  /**
   * Finds a host record in the database by its unique ID.
   *
   * @param id The unique identifier of the host to find.
   * @return An Optional containing the found Host or an empty Optional if the host does not exist.
   */
  public Optional<Host> findById(Integer id) {
    return hostRepository.findById(id);
  }

  /**
   * Deletes a host record from the database identified by the provided host ID.
   *
   * @param hostId The ID of the host to delete.
   * @param loggedInUser The username of the user performing the deletion for logging purposes.
   * @param hostName The name of the host being deleted for logging purposes.
   */
  public void deleteHost(Integer hostId, String loggedInUser, String hostName) {
    hostRepository.deleteHost(hostId);
    actionTrackingService.logUserAction(
        loggedInUser, "DELETE_HOST", String.format("Host %s successfully deleted", hostName));
  }

  /**
   * Processes the value of a field before updating a host record.
   *
   * @param fieldName The name of the field being updated.
   * @param value The new value for the field.
   * @return The processed value, which may involve encryption for sensitive fields like passwords.
   */
  private Object handleUpdateHostField(String fieldName, Object value) {
    if ("password".equals(fieldName)) {
      if (hostsPasswordEncryptionKey == null) {
        logger.error("Cannot determine password encryption key");
        return null;
      } else {
        try {
          return EncryptionUtil.encryptPassword(value.toString(), hostsPasswordEncryptionKey);
        } catch (Exception e) {
          logger.error("Error encrypting password: {}", e.getMessage());
          return null;
        }
      }
    } else {
      return value;
    }
  }

  /**
   * Decrypts a host's password using a configured encryption key.
   *
   * @param password The encrypted password retrieved from the database.
   * @return The decrypted, plaintext password.
   */
  private String transformPassword(String password) {
    return EncryptionUtil.decryptPassword(password, hostsPasswordEncryptionKey);
  }
}
