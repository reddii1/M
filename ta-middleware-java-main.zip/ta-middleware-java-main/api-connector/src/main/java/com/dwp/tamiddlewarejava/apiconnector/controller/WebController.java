package com.dwp.tamiddlewarejava.apiconnector.controller;

import java.io.IOException;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class WebController {

  private final RequestMappingHandlerMapping handlerMapping;

  public WebController(RequestMappingHandlerMapping handlerMapping) {
    this.handlerMapping = handlerMapping;
  }

  @PostConstruct
  public void init() {
    handlerMapping.setOrder(-1);
  }

  @GetMapping(value = {"/hosts", "/user-management", "/view-audit-log", "/change-password"})
  public void redirect(HttpServletRequest request, HttpServletResponse response)
      throws IOException {
    ClassPathResource index = new ClassPathResource("public/index.html");
    response.setContentType("text/html");
    index.getInputStream().transferTo(response.getOutputStream());
  }
}
