package com.dwp.tamiddlewarejava.apiconnector.model.audit;

public class AuditActions {
  public static final String LOGIN = "login";
  public static final String LOGOUT = "logout";
  public static final String SUSPEND_ACCOUNT = "suspend_account";
  public static final String UNSUSPEND_ACCOUNT = "unsuspend_account";
  public static final String DELETE_ACCOUNT = "delete_account";
  public static final String UNDELETE_ACCOUNT = "undelete_account";
  public static final String CHANGE_PASSWORD = "change_password";
  public static final String START_TEST = "start_test";
  public static final String CREATE_USER = "create_user";
  public static final String DELETE_USER = "delete_user";
  public static final String ROLE_CHANGE = "role_change";
  public static final String TEAM_CHANGE = "team_change";
  public static final String CREATE_HOST = "create_host";
  public static final String DELETE_HOST = "delete_host";
  public static final String UPDATE_HOST_NAME = "change_host_name";
  public static final String UPDATE_HOST_STATUS = "change_host_status";
  public static final String UPDATE_HOST_PROJECT_ROOT = "change_host_project_root";
  public static final String UPDATE_HOST_TEAM = "change_host_team";
  public static final String UPDATE_HOST_TEST_PROVIDER = "change_host_test_provider";
  public static final String UPDATE_HOST_USERNAME = "change_host_username";
  public static final String UPDATE_HOST_PASSWORD = "change_host_password";
}
