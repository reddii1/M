package com.dwp.tamiddlewarejava.apiconnector.service.servicestatus;

import com.dwp.tamiddlewarejava.apiconnector.model.host.CreateHost;
import com.dwp.tamiddlewarejava.shared.model.errors.DuplicateRecordException;
import com.dwp.tamiddlewarejava.shared.model.servicestatus.ServiceStatus;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.repository.ServiceStatusRepository;
import com.dwp.tamiddlewarejava.shared.utils.EncryptionUtil;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class ServiceStatusService {
    private static final Logger logger = LoggerFactory.getLogger(ServiceStatusService.class);
    private ServiceStatusRepository serviceStatusRepository;

    public ServiceStatusService(ServiceStatusRepository serviceStatusRepository) {
        this.serviceStatusRepository = serviceStatusRepository;
    }


    public List<ServiceStatus> GetAllServiceStatuses() {
        try {
            return serviceStatusRepository.getAllServiceStatuses();
        } catch (Exception e) {
            logger.error("Error fetching records", e);
            return Collections.emptyList();
        }
    }

    // crud (actually maybe just cru)

    @Transactional
    public void createServiceStatus(ServiceStatus status) {
        try {
            List<ServiceStatus> results = serviceStatusRepository.getServiceStatus(status.getService());

            if (results.isEmpty()) {
                logger.debug("No service status found. Creating new service status record.");
                serviceStatusRepository.createServiceStatus(
                        status.getService(),
                        status.getStatus()
                );
            }
            else {
                if (!results.get(0).getStatus().equals(status.getStatus())) {
                    logger.debug("Statuses do not match, updating status");
                    serviceStatusRepository.updateServiceStatus(status.getStatus(), status.getService());
                } else {
                    logger.debug("Statuses match, taking no action");
                }
            }

        } catch (DataIntegrityViolationException e) {
            logger.error("Attempted to create a service status that already exists: {}", status.getService());
            throw new DuplicateRecordException("Service status with the given service name already exists.");
        }
    }
}
