package com.dwp.tamiddlewarejava.apiconnector.service.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Service
public class ApiStatusService {

  private final Logger logger = LoggerFactory.getLogger(ApiStatusService.class);

  @PersistenceContext private EntityManager entityManager;

  /**
   * Checks if the application can establish a connection with the database.
   *
   * @return A boolean value indicating whether the database is connected (true) or not (false).
   */
  @Transactional(readOnly = true)
  public boolean isDatabaseConnected() {
    try {
      Query query = entityManager.createNativeQuery("SELECT 1");
      query.getSingleResult();
      return true;
    } catch (Exception e) {
      logger.error("Database is not connected");
      return false;
    }
  }
}
