package com.dwp.tamiddlewarejava.apiconnector.model.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ApiVersion {
    private String version;
    private String timeStamp;
}
