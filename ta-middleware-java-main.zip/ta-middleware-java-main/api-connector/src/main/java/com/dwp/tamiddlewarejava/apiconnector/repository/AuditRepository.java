package com.dwp.tamiddlewarejava.apiconnector.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dwp.tamiddlewarejava.apiconnector.model.audit.AuditEntry;

public interface AuditRepository extends JpaRepository<AuditEntry, Integer> {

  @Query(value = "SELECT * FROM auditlog order by date desc LIMIT ?2 OFFSET ?1", nativeQuery = true)
  List<AuditEntry> getPaginatedAuditLog(Integer startIndex, Integer rowCount);
}
