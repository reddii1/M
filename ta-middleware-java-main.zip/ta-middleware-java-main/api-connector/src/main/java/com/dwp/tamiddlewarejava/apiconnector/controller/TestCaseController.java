package com.dwp.tamiddlewarejava.apiconnector.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.dwp.tamiddlewarejava.shared.model.host.Host;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dwp.tamiddlewarejava.apiconnector.service.testcase.TestCaseService;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;

@RestController
@RequestMapping("/api/testcases")
public class TestCaseController {


  private final Logger logger = LoggerFactory.getLogger(TestCaseController.class);
  private TestCaseService testCaseService;

  @Autowired
  private HostController hostController;

  public TestCaseController(TestCaseService testCaseService) {
    this.testCaseService = testCaseService;
  }

  @GetMapping("/find")
  public ResponseEntity<List<TestCase>> getTestCases(
      @RequestParam Integer startIndex, @RequestParam Integer rowCount) {
    try {
      List<TestCase> testCases = testCaseService.findPaginatedTestCases(startIndex, rowCount);

      substituteTeamForTestProvider(testCases);

      return ResponseEntity.ok(testCases);

    } catch (Exception e) {
      logger.error("Error fetching test case entries");
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  }

  @GetMapping("/filter")
  public ResponseEntity<List<TestCase>> getFilteredTestCases(
          @RequestParam Integer startIndex, @RequestParam Integer rowCount,
          @RequestParam String tcidFilter, @RequestParam String cidFilter, @RequestParam String ridFilter,
//          @RequestParam String pidFilter,
          @RequestParam String zephyrFilter, @RequestParam String testerIdFilter,
          @RequestParam String atidFilter, @RequestParam String atidHostFilter, @RequestParam String requestTimeFilter,
          @RequestParam String testProviderFilter, @RequestParam String statusFilter,
          @RequestParam String targetExIdFilter, @RequestParam String testOutcomeFilter,
          @RequestParam String durationFilter, @RequestParam String notesFilter, @RequestParam String spoofedCliFilter,
          @RequestParam String targetCliFilter) {
    try {
      logger.info("Received Request with Parameters: " + tcidFilter+ ", " +cidFilter+ ", " +ridFilter+ "," +
//                      " " +pidFilter,
              zephyrFilter+ ", " +testerIdFilter+ ", " +atidFilter+ ", " +atidHostFilter+ ", " +requestTimeFilter,
              testProviderFilter+ ", " +statusFilter+ ", " +targetExIdFilter+ ", " +testOutcomeFilter+ ", " +durationFilter,
              notesFilter+ ", " +spoofedCliFilter+ ", " +targetCliFilter);
//      List<TestCase> testCases = testCaseService.findFilteredPaginatedTestCases(startIndex, rowCount, tcidFilter);
      List<TestCase> testCases = testCaseService.findFilteredTestCases(startIndex, rowCount,
              tcidFilter,cidFilter, ridFilter,
//              pidFilter,
              zephyrFilter,
              testerIdFilter,
              atidFilter,
              atidHostFilter,
              requestTimeFilter,
//              testProviderFilter,
              statusFilter,
              targetExIdFilter,
              testOutcomeFilter,
              durationFilter,
              notesFilter,
              spoofedCliFilter, targetCliFilter
              );

      substituteTeamForTestProvider(testCases);

      // because we've swapped out the test provider list, we need to manually perform this filtering exercise at this point
      if (testProviderFilter != null && !testProviderFilter.isEmpty()) {
        testCases = testCases.stream().filter(testCase -> testCase.getTestProvider().contains(testProviderFilter)).collect(Collectors.toList());
      }

      return ResponseEntity.ok(testCases);

    } catch (Exception e) {
      logger.error("Error fetching test case entries: " + e.getMessage());

      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  }

  private void substituteTeamForTestProvider(List<TestCase> testCases) {
    List<Host> hosts = hostController.getAllHosts();

    testCases.stream().forEach(testCase -> {
      String zephyrHost = testCase.getAtidHost();
      String teamName = getTeamNameForID(hosts, zephyrHost, testCase.getTestProvider());
      testCase.setTestProvider(teamName);
    });
  }

  private String getTeamNameForID(List<Host> hosts, String zephyrHost, String testProvider) {
    Optional<Host> optionalHost = hosts.stream().filter(host -> host.getZephyrHostId().equals(zephyrHost)).findFirst();

    if (optionalHost.isPresent()) {
      return optionalHost.get().getTeamName();
    } else {
      return testProvider;
    }
  }
}
