package com.dwp.tamiddlewarejava.apiconnector.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.dwp.tamiddlewarejava.apiconnector.service.servicestatus.ServiceStatusService;
import com.dwp.tamiddlewarejava.shared.model.servicestatus.ServiceStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.dwp.tamiddlewarejava.apiconnector.model.host.CreateHost;
import com.dwp.tamiddlewarejava.apiconnector.model.host.DeleteHost;
import com.dwp.tamiddlewarejava.apiconnector.model.host.UpdateHostField;
import com.dwp.tamiddlewarejava.apiconnector.service.host.HostService;
import com.dwp.tamiddlewarejava.shared.model.host.Host;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api/hosts")
public class HostController {

  private final Logger logger = LoggerFactory.getLogger(HostController.class);
  private HostService hostService;

  private ServiceStatusService serviceStatusService;

  public HostController(HostService hostService, ServiceStatusService serviceStatusService) {
    this.hostService = hostService;
    this.serviceStatusService = serviceStatusService;
  }

  @GetMapping("/getAll")
  public List<Host> getAllHosts() {
    return hostService.getAllHosts();
  }

  @GetMapping("/{id}")
  public Optional<Host> findById(@PathVariable Integer id) {
    return hostService.findById(id);
  }

  @PutMapping("/{hostId}/{field}")
  public ResponseEntity<Map<String, Object>> updateHost(
      @PathVariable Integer hostId,
      @PathVariable String field,
      @RequestBody UpdateHostField updateObject) {
    try {
      Object updateValue = updateObject.getValue();
      String hostName = updateObject.getHost();
      String loggedInUser = updateObject.getLoggedInUser();



      logger.debug("Attempting to update host.");



      hostService.updateHost(hostId, field, updateValue, hostName, loggedInUser);


      // if field is host status
      // use that instead

      logger.debug("Attempting to get host for service status, hostID: " + hostId);

      Host host = hostService.findById(hostId).orElse(null);

      if (host != null) {
        logger.debug("Attempting to update service status.");
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setService(host.getTestProvider().toString());
        serviceStatus.setStatus(host.getHostStatus());
        serviceStatusService.createServiceStatus(serviceStatus);
        logger.debug("Updated service status.");
      }

      return ResponseEntity.status(HttpStatus.OK)
          .body(Map.of("message", "Successfully updated host"));
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Error updating host " + e.getMessage()));
    }
  }

  @DeleteMapping("/{hostId}")
  public ResponseEntity<Map<String, Object>> deleteHost(
      @PathVariable Integer hostId, @RequestBody DeleteHost hostDeleteBody) {
    try {
      String hostToBeDeleted = hostDeleteBody.getHost();
      String loggedInUser = hostDeleteBody.getLoggedInUser();

      hostService.deleteHost(hostId, loggedInUser, hostToBeDeleted);
      return ResponseEntity.status(HttpStatus.OK)
          .body(Map.of("message", "Successfully deleted host"));
    } catch (Exception e) {
      logger.error("Failed to delete host: {}", hostDeleteBody.getHost());
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Error deleting host" + e.getMessage()));
    }
  }

  @ResponseStatus(HttpStatus.OK) // 200
  @PostMapping("/{id}")
  public ResponseEntity<Map<String, Object>> createHost(@RequestBody CreateHost host) {
    try {
      hostService.createHost(host);
      ServiceStatus serviceStatus = new ServiceStatus();
      serviceStatus.setService(host.getTestProvider().toString());
      serviceStatus.setStatus(host.getHostStatus());
      serviceStatusService.createServiceStatus(serviceStatus);
//      host.getS
      return ResponseEntity.status(HttpStatus.OK)
          .body(Map.of("message", "Successfully created host: " + host.getZephyrHostId()));
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Error creating host: " + e.getMessage()));
    }
  }




  @GetMapping("/getAllServiceStatus")
  public List<ServiceStatus> getAllServiceStatus() {
    return serviceStatusService.GetAllServiceStatuses();
  }
}
