package com.dwp.tamiddlewarejava.apiconnector.model.testexecution;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StopExecution {
  private String tcid;
  private String rid;
  private String cid;
  private String cpid;
}
