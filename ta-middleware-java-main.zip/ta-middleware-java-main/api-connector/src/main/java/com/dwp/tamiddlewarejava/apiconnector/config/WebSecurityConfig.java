package com.dwp.tamiddlewarejava.apiconnector.config;

import java.security.PublicKey;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

  private final PublicKey publicKey;

  public WebSecurityConfig(PublicKey publicKey) {
    this.publicKey = publicKey;
  }

  private String adminRole = "ROLE_test_admin";
  private String runnerRole = "ROLE_test_runner";

  /**
   * Configures the HTTP security chain for the application. Sets CORS configuration, and specifies
   * authorization rules for various endpoints. Integrates the JwtAuthenticationFilter to
   * authenticate requests using JWT.
   *
   * @param http HttpSecurity to configure.
   * @return Configured SecurityFilterChain.
   * @throws Exception if an error occurs during configuration.
   */
  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    JwtAuthenticationFilter jwtAuthenticationFilter = new JwtAuthenticationFilter(publicKey);
    http.csrf(csrf -> csrf.disable())
        .cors(cors -> {})
        .authorizeHttpRequests(
            authorize ->
                authorize
                    .requestMatchers(
                        "/",
                        "/login",
                        "/logout",
                        "/hosts",
                        "/user-management",
                        "/view-audit-log",
                        "/change-password",
                        "/static/css/**",
                        "/static/js/**",
                        "/*.png",
                        "/*.html",
                        "/*.ico",
                        "/api/status",
                        "/api/execute",
                        "/api/users/*/login",
                        "/api/testcases/find",
                        "/api/testcases/filter",
                        "/api/hosts/getAll",
                        "/api/hosts/getAllServiceStatus",
                        "/api/about/version")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/api/users/getAll", "/api/auditlog")
                    .hasAnyAuthority(adminRole)
                    .requestMatchers(HttpMethod.POST, "/api/users/*/password")
                    .permitAll()
                    .requestMatchers(HttpMethod.POST, "/api/stopExecution")
                    .hasAnyAuthority(adminRole, runnerRole)
                    .requestMatchers(HttpMethod.DELETE, "/api/hosts/*", "/api/users/*")
                    .hasAnyAuthority(adminRole)
                    .requestMatchers(HttpMethod.PUT, "/api/hosts/*")
                    .hasAnyAuthority(adminRole)
                    .requestMatchers(HttpMethod.POST, "/api/hosts/*", "/api/users")
                    .hasAnyAuthority(adminRole)
                    .anyRequest()
                    .authenticated())
        .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

    return http.build();
  }

  /**
   * Defines the CORS configuration for the application.
   *
   * @return CorsConfigurationSource with the defined CORS policy.
   */
  @Bean
  CorsConfigurationSource corsConfigurationSource() {
    UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
    var corsConfiguration = new CorsConfiguration().applyPermitDefaultValues();
    corsConfiguration.setAllowedMethods(List.of("GET", "POST", "PUT", "OPTIONS", "DELETE"));
    corsConfiguration.setAllowedOrigins(List.of("*"));
    source.registerCorsConfiguration("/**", corsConfiguration);
    return source;
  }
}
