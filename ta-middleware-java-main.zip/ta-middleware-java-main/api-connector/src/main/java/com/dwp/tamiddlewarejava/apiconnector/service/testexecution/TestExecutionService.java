package com.dwp.tamiddlewarejava.apiconnector.service.testexecution;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dwp.tamiddlewarejava.apiconnector.model.testexecution.StopExecution;
import com.dwp.tamiddlewarejava.apiconnector.service.audit.ActionTrackingService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Service
public class TestExecutionService {

  private final Logger logger = LoggerFactory.getLogger(TestExecutionService.class);
  private ActionTrackingService actionTrackingService;

  @PersistenceContext private EntityManager entityManager;

  public TestExecutionService(ActionTrackingService actionTrackingService) {
    this.actionTrackingService = actionTrackingService;
  }

  private static final String INSERT_TEST_CASES_SQL =
      "INSERT INTO testcases (id, tcid, rid, cid, cpid, requesttime, orchestrationstatus, startattempts," +
              " cidname, ridname, projectname, pid, startedby, cpname, tcidname) VALUES (:id, :tcid, :rid, :cid," +
              " :cpid, :requestTime, :status, :attempts," +
              " :cidname, :ridname, :projectname, :pid, :startedby, :cpname, :tcidname)";

  /**
   * Initiates the execution of a list of test cases identified by their IDs, release IDs, cycle
   * IDs, and cycle phase IDs.
   *
   * @param testcaseIds The list of test case IDs to execute.
   * @param releaseId The release ID associated with these test cases.
   * @param cycleId The cycle ID associated with these test cases.
   * @param cyclePhaseId The cycle phase ID associated with these test cases.
   */
  @Transactional
  public void executeTestCases(
      List<Integer> testcaseIds,
      int releaseId,
      int cycleId,
      int cyclePhaseId,
      int projectId,
      String projectName,
      String releaseName,
      String cname,
      String cyclePhaseName,
      String username,
      List<String> testcaseNames
  ) {
    Timestamp requestTime = new Timestamp(new Date().getTime());
    for (int i = 0; i < testcaseIds.size(); i++) {
      Integer testcaseId = testcaseIds.get(i);
      String testcaseName = testcaseNames.get(i);

      // Powershell is prone to adding a leading square bracket
      // Trim it out if present.
      if (testcaseName.charAt(0) == '[') {
        testcaseName = testcaseName.substring(1);
      }

      String id = UUID.randomUUID().toString();

      entityManager
              .createNativeQuery(INSERT_TEST_CASES_SQL)
              .setParameter("id", id)
              .setParameter("tcid", testcaseId)
              .setParameter("rid", releaseId)
              .setParameter("cid", cycleId)
              .setParameter("cpid", cyclePhaseId)
              .setParameter("requestTime", requestTime)
              .setParameter("status", "New")
              .setParameter("attempts", 0)
              .setParameter("cidname", cname)
              .setParameter("ridname", releaseName)
              .setParameter("projectname", projectName)
              .setParameter("pid", projectId)
              .setParameter("startedby", username)
              .setParameter("cpname", cyclePhaseName)
              .setParameter("tcidname", testcaseName)
              .executeUpdate();
    }

    String concatendatedTcidMessage = formatTcidList(testcaseIds);
    actionTrackingService.logUserAction("Zephyr", "START_TEST", concatendatedTcidMessage);
  }

  /**
   * Formats a list of test case IDs into a single string representation, mainly for logging or
   * display purposes.
   *
   * @param testCaseIds The list of test case IDs to format.
   * @return A string representation of the test case IDs.
   */
  private String formatTcidList(List<Integer> testCaseIds) {
    String idsString = testCaseIds.stream().map(String::valueOf).collect(Collectors.joining(", "));

    return String.format("Successfully added execution for test case IDs: %s", idsString);
  }

  /**
   * Stops the execution of test cases based on specified criteria. It updates the test cases'
   * statuses to 'Cancelled' and outcomes to 'Stopped in Middleware'.
   *
   * @param stopExecution The StopExecution object containing the criteria for stopping test case
   *     execution.
   * @return The number of test cases whose execution was stopped.
   * @throws IllegalAccessException if the dynamic WHERE clause is empty, indicating no valid fields
   *     were provided.
   */
  @Transactional
  @Modifying
  public int stopExecutionForTestCases(StopExecution stopExecution) throws IllegalAccessException {
    StringBuilder sqlBuilder =
        new StringBuilder(
            "UPDATE testcases SET orchestrationstatus='Cancelled', testoutcome='Stopped in Middleware', starttime=? WHERE orchestrationstatus = 'Ready' AND ");
    List<Object> params = new ArrayList<>();
    params.add(LocalDateTime.now()); // Assuming start_time is a datetime column

    /*
     * Any combination of fields in StopExecution Class can be used for Stopping
     * Execution.
     * This means we need to build a dynamic WHERE clause based on values passed.
     */
    List<String> dynamicWhereClause = new ArrayList<>();
    if (!stopExecution.getTcid().isEmpty()) {
      dynamicWhereClause.add("tcid=?");
      params.add(stopExecution.getTcid());
    }
    if (!stopExecution.getRid().isEmpty()) {
      dynamicWhereClause.add("rid=?");
      params.add(stopExecution.getRid());
    }
    if (!stopExecution.getCid().isEmpty()) {
      dynamicWhereClause.add("cid=?");
      params.add(stopExecution.getCid());
    }
    if (!stopExecution.getCpid().isEmpty()) {
      dynamicWhereClause.add("cpid=?");
      params.add(stopExecution.getCpid());
    }

    if (dynamicWhereClause.isEmpty()) {
      logger.error("No valid test execution fields provided");
    }

    sqlBuilder.append(String.join(" AND ", dynamicWhereClause));

    Query query = entityManager.createNativeQuery(sqlBuilder.toString());
    for (int i = 0; i < params.size(); i++) {
      query.setParameter(i + 1, params.get(i));
    }

    return query.executeUpdate();
  }
}
