package com.dwp.tamiddlewarejava.apiconnector.service.authentication;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.apiconnector.model.user.RoleEnum;
import com.dwp.tamiddlewarejava.apiconnector.repository.UserRepository;

@Service
public class PasswordService {

  private static final Logger logger = LoggerFactory.getLogger(PasswordService.class);
  private UserRepository userRepository;
  private JWTService jwtService;

  public PasswordService(UserRepository userRepository, JWTService jwtService) {
    this.userRepository = userRepository;
    this.jwtService = jwtService;
  }

  /**
   * Validates the given password against the stored hash for the specified username.
   *
   * @param username The username of the account to authenticate.
   * @param password The password provided for authentication.
   * @return A ResponseEntity containing a JWT token if authentication is successful, or an error
   *     message if authentication fails or the password is expired.
   * @throws SQLException If a database access error occurs.
   */
  public ResponseEntity<Map<String, Object>> checkPassword(String username, String password)
      throws SQLException {
    String givenPassword = password.replaceAll("\\P{Print}", ""); // Remove non-printable characters

    byte[] userSalt;
    try {
      userSalt = userRepository.getUserSalt(username);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Cannot get user salt"));
    }

    byte[] givenPasswordHash;
    try {
      givenPasswordHash =
          HashPassword(givenPassword, userSalt); // Assuming HashPassword is a method you've
      // defined
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Cannot hash password"));
    }

    byte[] actualPasswordHash;
    try {
      actualPasswordHash = userRepository.getActualPasswordHash(username);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(Map.of("message", "Cannot get password for user"));
    }

    LocalDateTime passwordExpires = userRepository.getPasswordExpiry(username);
    RoleEnum userRole = userRepository.findUserRole(username);

    if (MessageDigest.isEqual(givenPasswordHash, actualPasswordHash)) {
      if (LocalDateTime.now().isAfter(passwordExpires)) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
            .body(Map.of("message", "Password expired for user"));
      } else {
        String jwtToken = jwtService.mintJWTToken(username, userRole);
        // // Response
        Map<String, Object> response =
            Map.of(
                "JWT", jwtToken,
                "passwordExpiry", passwordExpires);

        return ResponseEntity.status(HttpStatus.OK).body(response);
      }
    } else {
      return ResponseEntity.status(HttpStatus.FORBIDDEN)
          .body(Map.of("message", "Incorrect password attempted"));
    }
  }

  /**
   * Generates a hash of the specified password using PBKDF2 with HMAC SHA-384. This method applies
   * a salt and performs multiple iterations to securely hash the password.
   *
   * @param password The password to hash.
   * @param salt The salt to apply to the password before hashing.
   * @return The hashed password.
   * @throws NoSuchAlgorithmException If the specified algorithm (PBKDF2WithHmacSHA384) is not
   *     available.
   * @throws InvalidKeySpecException If the key specification is not valid.
   */
  private static byte[] HashPassword(String password, byte[] salt)
      throws NoSuchAlgorithmException, InvalidKeySpecException {
    try {
      PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 30000, 48 * 8);
      SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA384");
      return skf.generateSecret(spec).getEncoded();
    } catch (NoSuchAlgorithmException e) {
      // This exception can be thrown if the specified algorithm is not available.
      // Handle the exception - log it, and/or rethrow as a RuntimeException or custom
      // exception.
      throw new NoSuchAlgorithmException("Failed to hash password: Algorithm not available.", e);
    } catch (InvalidKeySpecException e) {
      // This exception is thrown if the key specification is invalid.
      // Handle the exception - log it, and/or rethrow as a RuntimeException or custom
      // exception.
      throw new InvalidKeySpecException("Failed to hash password: Invalid Key Spec.", e);
    }
  }

  /**
   * Sanitizes the given password by removing any non-printable characters.
   *
   * @param password The candidate password to sanitize.
   * @return The sanitized password.
   */
  public String sanitizeCandidatePassword(String password) {
    return password.replaceAll("\\P{Print}", "");
  }

  /**
   * Updates the user's password to a new, securely hashed password.
   *
   * @param candidatePassword The new password for the user.
   * @param username The username of the account for which to update the password.
   * @return True if the password update was successful, false otherwise.
   * @throws SQLException If there is an issue accessing the database or hashing the password.
   */
  public boolean updatePassword(String candidatePassword, String username) throws SQLException {
    byte[] userSalt = userRepository.getUserSalt(username);
    if (userSalt == null) {
      throw new SQLException("User not found or suspended");
    }

    byte[] passwordHash;

    try {
      passwordHash = HashPassword(candidatePassword, userSalt);
    } catch (NoSuchAlgorithmException e) {
      // Handle the exception, possibly log it, and throw a SQLException or custom
      // exception
      throw new SQLException("Failed to hash password due to algorithm issue", e);
    } catch (InvalidKeySpecException e) {
      // Handle the exception, possibly log it, and throw a SQLException or custom
      // exception
      throw new SQLException("Failed to hash password due to algorithm issue", e);
    }

    List<byte[]> oldPasswordHashes = userRepository.getOldPasswordHashes(username);
    for (byte[] oldHashRecord : oldPasswordHashes) {
      if (Arrays.equals(passwordHash, oldHashRecord)) {
        throw new SQLException("Password reuse detected");
      }
    }

    userRepository.setNewPassword(passwordHash, username);
    return true;
  }
}
