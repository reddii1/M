package com.dwp.tamiddlewarejava.apiconnector.controller;

import com.dwp.tamiddlewarejava.apiconnector.model.api.ApiVersion;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api/about")
public class AboutController {
    private static String buildTime = "06/11/2024";

    @GetMapping("/version")
    public ResponseEntity<ApiVersion> index() {
        return ResponseEntity.ok(
                new ApiVersion(getClass().getPackage().getImplementationVersion().toString(),
                buildTime));
    }
}
