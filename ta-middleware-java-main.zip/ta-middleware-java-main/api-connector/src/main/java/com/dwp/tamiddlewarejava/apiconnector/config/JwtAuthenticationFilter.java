package com.dwp.tamiddlewarejava.apiconnector.config;

import java.io.IOException;
import java.security.PublicKey;
import java.util.Collections;
import java.util.List;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.dwp.tamiddlewarejava.apiconnector.model.user.CustomUserPrincipal;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

  private final PublicKey publicKey;

  public JwtAuthenticationFilter(PublicKey publicKey) {
    this.publicKey = publicKey;
  }

  /**
   * Extracts the JWT token from the request's Authorization header, validates it, and sets the user
   * authentication in the security context.
   *
   * @param request The incoming HTTP request.
   * @param response The HTTP response.
   * @param filterChain The filter chain for passing the request to the next filter or resource.
   * @throws ServletException If a servlet-specific error occurs.
   * @throws IOException If an I/O error occurs during request processing.
   */
  @Override
  protected void doFilterInternal(
      HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {
    String jwt = getJwtFromRequest(request);

    if (jwt != null && validateToken(jwt)) {
      Jws<Claims> claimsJws = Jwts.parser().verifyWith(publicKey).build().parseSignedClaims(jwt);

      Claims claims = claimsJws.getBody();
      String username = claims.getSubject();
      String role = claims.get("role", String.class);

      List<SimpleGrantedAuthority> authorities =
          Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role));

      CustomUserPrincipal userPrincipal = new CustomUserPrincipal(username, authorities);
      UsernamePasswordAuthenticationToken authentication =
          new UsernamePasswordAuthenticationToken(userPrincipal, null, authorities);

      authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

      SecurityContextHolder.getContext().setAuthentication(authentication);
    }

    filterChain.doFilter(request, response);
  }

  /**
   * Extracts the JWT token from the Authorization header of the incoming request.
   *
   * @param request The HttpServletRequest from which to extract the JWT token.
   * @return The JWT token without the "Bearer " prefix, or null if the token is not present or
   *     doesn't start with "Bearer ".
   */
  private String getJwtFromRequest(HttpServletRequest request) {
    String bearerToken = request.getHeader("Authorization");
    if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
      return bearerToken.substring(7);
    }
    return null;
  }

  /**
   * Validates the JWT token's signature and claims using the configured public key.
   *
   * @param jwt The JWT token to validate.
   * @return true if the token is valid; false otherwise.
   */
  private boolean validateToken(String jwt) {
    try {
      // Attempt to parse the JWT. This will also validate the signature.
      Jwts.parser().verifyWith(publicKey).build().parseSignedClaims(jwt);
      return true;
    } catch (Exception e) {
      // Log or handle JWT validation exceptions (signature, expiration, etc.)
    }
    return false;
  }
}
