package com.dwp.tamiddlewarejava.apiconnector.service.user;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.apiconnector.model.user.CreateUser;
import com.dwp.tamiddlewarejava.apiconnector.model.user.RoleEnum;
import com.dwp.tamiddlewarejava.apiconnector.model.user.User;
import com.dwp.tamiddlewarejava.apiconnector.repository.UserRepository;
import com.dwp.tamiddlewarejava.apiconnector.service.audit.ActionTrackingService;
import com.dwp.tamiddlewarejava.apiconnector.service.authentication.PasswordService;
import com.dwp.tamiddlewarejava.shared.model.errors.DuplicateRecordException;
import com.dwp.tamiddlewarejava.shared.utils.PasswordUtils;

import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

@Service
public class UserService {

  private UserRepository userRepository;
  private PasswordUtils passwordUtils;
  private PasswordService passwordService;
  private EntityManager entityManager;
  private ActionTrackingService actionTrackingService;

  public UserService(
      UserRepository userRepository,
      PasswordUtils passwordUtils,
      PasswordService passwordService,
      EntityManager entityManager,
      ActionTrackingService actionTrackingService) {
    this.userRepository = userRepository;
    this.passwordUtils = passwordUtils;
    this.passwordService = passwordService;
    this.entityManager = entityManager;
    this.actionTrackingService = actionTrackingService;
  }

  private static final Set<String> VALID_FIELDS =
      Set.of(
          "username",
          "firstname",
          "lastname",
          "team",
          "role",
          "passwordexpiresutc",
          "suspendeduser",
          "deleteduser");

  /**
   * Updates a specific attribute of a user in the database. Only fields specified in VALID_FIELDS
   * are allowed to be updated to ensure safety.
   *
   * @param userId The unique identifier of the user to be updated.
   * @param field The name of the field to update.
   * @param updateValue The new value for the specified field.
   * @throws IllegalArgumentException If the field name is not valid.
   */
  @Transactional
  public void updateUser(Integer userId, String field, Object updateValue) {
    // Validate the field name to ensure it's safe and expected
    if (!VALID_FIELDS.contains(field)) {
      throw new IllegalArgumentException("Invalid field name");
    }

    // Construct SQL query
    String sql = "UPDATE users SET " + field + " = :updateValue WHERE id = :userId";

    // Execute the update
    entityManager
        .createNativeQuery(sql)
        .setParameter("updateValue", updateValue)
        .setParameter("userId", userId)
        .executeUpdate();
  }

  /**
   * Creates a new user in the database with the provided user details. A new random salt is
   * generated for password encryption. It also generates a default password for the user.
   *
   * @param user The CreateUser object containing the user details.
   * @return A map containing the username and newly generated password.
   * @throws DuplicateRecordException If a user with the same username already exists.
   */
  @Transactional(dontRollbackOn = {ConstraintViolationException.class})
  public Map<String, Object> createUser(CreateUser user) {

    try {
      String sql =
          "INSERT INTO users (username, firstname, lastname, "
              + "suspendeduser, role, team, salt) "
              + "VALUES (:username, :firstName, :lastName, :suspendedUser, "
              + ":role, :team, :salt)";

      byte[] userSalt = passwordUtils.generateRandomSalt();

      entityManager
          .createNativeQuery(sql)
          .setParameter("username", user.getUsername())
          .setParameter("firstName", user.getFirstName())
          .setParameter("lastName", user.getLastName())
          .setParameter("suspendedUser", user.getSuspendedUser())
          .setParameter("role", user.getRole().toString())
          .setParameter("team", user.getTeam())
          .setParameter("salt", userSalt)
          .executeUpdate();

      String newPassword = passwordUtils.generatePassword(16, 1, 1);
      passwordService.updatePassword(newPassword, user.getUsername());

      actionTrackingService.logUserAction(
          user.getLoggedInUser(),
          "CREATE_USER",
          String.format("User %s successfully created", user.getUsername()));

      return Map.of("username", user.getUsername(), "password", newPassword);
    } catch (ConstraintViolationException e) {
      throw new DuplicateRecordException("User already exists.");
    } catch (Exception e) {
      return Map.of("message", e.getMessage());
    }
  }

  /**
   * Retrieves all non-deleted users from the database.
   *
   * @return A list of User entities.
   */
  public List<User> getAllUsers() {
    return userRepository.getAllUsers();
  }

  /**
   * Finds a user by their ID.
   *
   * @param id The ID of the user to find.
   * @return An Optional containing the found user or an empty Optional if no user is found.
   */
  public Optional<User> findById(Integer id) {
    return userRepository.findById(id);
  }

  /**
   * Finds a user by their username.
   *
   * @param username The username of the user to find.
   * @return The User entity if found.
   */
  public User findUserByUsername(String username) {
    return userRepository.findUserByUsername(username);
  }

  /**
   * Saves a User entity to the database. If the user already exists, it updates the existing
   * record; otherwise, it inserts a new record.
   *
   * @param user The User entity to save or update.
   */
  public void save(User user) {
    userRepository.save(user);
  }

  /**
   * Sets a user as deleted using their ID.
   *
   * @param userId The unique identifier of the user to delete.
   * @param loggedInUser The username of the user performing the deletion operation.
   * @param user The username of the user being deleted.
   */
  public void deleteUser(Integer userId, String loggedInUser, String user) {
    userRepository.deleteUser(userId);
    actionTrackingService.logUserAction(
        loggedInUser, "DELETE_USER", String.format("User %s successfully deleted", user));
  }

  /**
   * Retrieves the role of a user by their username.
   *
   * @param username The username of the user whose role is to be found.
   * @return The role of the user as a RoleEnum.
   */
  public RoleEnum findUserRole(String username) {
    return userRepository.findUserRole(username);
  }
}
