package com.dwp.tamiddlewarejava.apiconnector.service.audit;

import java.util.List;

import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.apiconnector.model.audit.AuditEntry;
import com.dwp.tamiddlewarejava.apiconnector.repository.AuditRepository;

@Service
public class AuditService {

  private AuditRepository auditRepository;

  public AuditService(AuditRepository auditRepository) {
    this.auditRepository = auditRepository;
  }

  /**
   * Fetches a subset of audit log entries based on the specified start index and row count.
   *
   * @param startIndex The zero-based index at which to start retrieving audit log entries.
   * @param rowCount The number of audit log entries to retrieve.
   * @return A list of AuditEntry objects representing the requested segment of the audit log.
   */
  public List<AuditEntry> getPaginatedAuditLog(Integer startIndex, Integer rowCount) {
    return auditRepository.getPaginatedAuditLog(startIndex, rowCount);
  }
}
