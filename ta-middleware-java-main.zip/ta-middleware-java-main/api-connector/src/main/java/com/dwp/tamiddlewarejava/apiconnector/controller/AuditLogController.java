package com.dwp.tamiddlewarejava.apiconnector.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dwp.tamiddlewarejava.apiconnector.model.audit.AuditEntry;
import com.dwp.tamiddlewarejava.apiconnector.service.audit.AuditService;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api/auditlog")
public class AuditLogController {

  private final Logger logger = LoggerFactory.getLogger(AuditLogController.class);
  private AuditService auditService;

  public AuditLogController(AuditService auditService) {
    this.auditService = auditService;
  }

  @GetMapping
  public ResponseEntity<List<AuditEntry>> getAuditLog(
      @RequestParam Integer startIndex, @RequestParam Integer rowCount) {
    try {
      List<AuditEntry> auditLog = auditService.getPaginatedAuditLog(startIndex, rowCount);

      return ResponseEntity.ok(auditLog);

    } catch (Exception e) {
      logger.error("Error fetching audit log entries");
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  }
}
