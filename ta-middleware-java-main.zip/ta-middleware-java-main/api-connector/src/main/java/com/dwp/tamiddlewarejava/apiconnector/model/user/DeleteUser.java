package com.dwp.tamiddlewarejava.apiconnector.model.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class DeleteUser {
  private String user;
  private String loggedInUser;
}
