package com.dwp.tamiddlewarejava.apiconnector.config;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;

@Configuration
public class KeyConfig {

  private PublicKey publicKey;
  private PrivateKey privateKey;

  /** Initializes RSA public and private keys upon bean instantiation. */
  @PostConstruct
  public void initKeys() {
    try {
      KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
      keyPairGenerator.initialize(2048, new SecureRandom());
      KeyPair generatedKeyPair = keyPairGenerator.generateKeyPair();
      this.privateKey = generatedKeyPair.getPrivate();
      this.publicKey = generatedKeyPair.getPublic();
    } catch (NoSuchAlgorithmException e) {
      System.out.println("Error: " + e.getMessage());
      System.exit(1);
    }
  }

  /**
   * Provides the RSA public key as a Spring-managed bean. The public key is used to verify JWT
   * tokens' signatures.
   *
   * @return The RSA public key generated during bean initialization.
   */
  @Bean
  public PublicKey publicKey() {
    return publicKey;
  }

  /**
   * Provides the RSA private key as a Spring-managed bean. The private key is used for securely
   * signing JWT tokens, ensuring that tokens can be verified as authentic by this application.
   *
   * @return The RSA private key generated during bean initialization.
   */
  @Bean
  public PrivateKey privateKey() {
    return privateKey;
  }
}
