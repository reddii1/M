package com.dwp.tamiddlewarejava.apiconnector.controller;

import java.util.List;
import java.util.Map;

import com.dwp.tamiddlewarejava.apiconnector.service.host.HostService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dwp.tamiddlewarejava.apiconnector.model.testexecution.ExecuteRequest;
import com.dwp.tamiddlewarejava.apiconnector.model.testexecution.StopExecution;
import com.dwp.tamiddlewarejava.apiconnector.service.testexecution.TestExecutionService;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/api")
public class TestExecutionController {

  private static final Logger logger = LoggerFactory.getLogger(TestExecutionController.class);
  private TestExecutionService testExecutionService;

  public TestExecutionController(TestExecutionService testExecutionService) {
    this.testExecutionService = testExecutionService;
  }

  @PostMapping("/execute")
  public ResponseEntity<?> execute(@RequestBody ExecuteRequest requestBody) {
    try {
      if (requestBody.getTestCaseIds() == null || requestBody.getTestCaseIds().isEmpty()) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No test cases provided.");
      }

      logger.debug("Received request with params " + requestBody.toString());

      testExecutionService.executeTestCases(
          requestBody.getTestCaseIds(),
          requestBody.getRid(),
          requestBody.getCid(),
          requestBody.getCpid(),
          requestBody.getProjectId(),
          requestBody.getProjectName(),
          requestBody.getReleaseName(),
          requestBody.getCname(),
          requestBody.getCyclePhaseName(),
          requestBody.getUsername(),
          requestBody.getTestcaseNames());
      return ResponseEntity.ok().build();
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body("Error executing test cases");
    }
  }

  @PostMapping("/stopExecution")
  public ResponseEntity<?> stopExecution(@RequestBody StopExecution stopExecutionRequestBody) {
    try {
      int rowsAffected = testExecutionService.stopExecutionForTestCases(stopExecutionRequestBody);
      if (rowsAffected == 0) {
        return ResponseEntity.status(500)
            .body(Map.of("message", "No New or Ready test cases found matching specified values"));
      }
      return ResponseEntity.status(200).body(Map.of("message", "Execution stopped successfully"));
    } catch (Exception e) {
      return ResponseEntity.status(500).body(Map.of("message", "Failed to stop execution"));
    }
  }
}
