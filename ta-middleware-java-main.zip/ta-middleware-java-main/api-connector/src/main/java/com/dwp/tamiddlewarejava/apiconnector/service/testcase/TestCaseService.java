package com.dwp.tamiddlewarejava.apiconnector.service.testcase;

import java.util.*;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.repository.TestCaseRepository;

@Service
public class TestCaseService {

  private TestCaseRepository testCaseRepository;


  @PersistenceContext
  private EntityManager entityManager;

  public TestCaseService(TestCaseRepository testCaseRepository) {
    this.testCaseRepository = testCaseRepository;
  }

  /**
   * Retrieves a TestCase by its unique identifier (UUID).
   *
   * @param id The UUID of the TestCase to find.
   * @return An Optional containing the found TestCase or an empty Optional if no TestCase is found
   *     with the given ID.
   */
  public Optional<TestCase> findById(UUID id) {
    return testCaseRepository.findById(id);
  }

  /**
   * Saves a TestCase entity to the database. If the TestCase already exists, it updates the
   * existing record; otherwise, it inserts a new record.
   *
   * @param testCase The TestCase entity to save or update.
   * @return The saved TestCase entity with any auto-generated fields populated (e.g., generated
   *     ID).
   */
  public TestCase save(TestCase testCase) {
    return testCaseRepository.save(testCase);
  }

  /**
   * Deletes a Test Case from the database using its unique identifier (UUID).
   *
   * @param id The UUID of the TestCase to delete.
   */
  public void deleteById(UUID id) {
    testCaseRepository.deleteById(id);
  }

  /**
   * Retrieves a paginated list of Test Cases.
   *
   * @param startIndex The starting index from where to begin the retrieval.
   * @param rowCount The number of TestCase entities to retrieve.
   * @return A list of TestCase entities starting from the specified index with the specified number
   *     of rows.
   */
  public List<TestCase> findPaginatedTestCases(Integer startIndex, Integer rowCount) {
    return testCaseRepository.findPaginatedTestCases(startIndex, rowCount);
  }

  /**
   * Retrieves a paginated list of Test Cases.
   *
   * @param startIndex The starting index from where to begin the retrieval.
   * @param rowCount The number of TestCase entities to retrieve.
   * @return A list of TestCase entities starting from the specified index with the specified number
   *     of rows.
   */
  public List<TestCase> findFilteredPaginatedTestCases(Integer startIndex, Integer rowCount, String filter) {
    return testCaseRepository.findFilteredPaginatedTestCases(startIndex, rowCount, "%" + filter + "%");
  }

  public List<TestCase> findFilteredTestCases(Integer startIndex, Integer rowCount, String
              tcidFilter, String cidFilter, String ridFilter, String
//                                              pidFilter, String
                                              zephyrFilter, String
                                              testerIdFilter, String
                                              atidFilter, String
                                              atidHostFilter, String
                                              requestTimeFilter,
//                                              String testProviderFilter,
                                              String statusFilter, String
                                              targetExIdFilter, String
                                              testOutcomeFilter, String
                                              durationFilter, String
                                              notesFilter, String
                                              spoofedCliFilter, String targetCliFilter) {


    StringBuilder sqlBuilder =
            new StringBuilder(
                    "SELECT * FROM testcases ");

    if (anyPopulated(tcidFilter, cidFilter, ridFilter, zephyrFilter, testerIdFilter, atidFilter, atidHostFilter,
            requestTimeFilter, statusFilter, targetExIdFilter, testOutcomeFilter, durationFilter,
            notesFilter, spoofedCliFilter, targetCliFilter)); {

      Map<String, String> map = new HashMap<>();

      map.put("tcid", tcidFilter);
      map.put("cid", cidFilter);
      map.put("rid", ridFilter);
//      map.put("pid", pidFilter); //column pid does not exist (:
      map.put("eid", zephyrFilter);
      map.put("testerid", testerIdFilter);
      map.put("atid", atidFilter);
      map.put("atidhost", atidHostFilter);
      map.put("requesttime", requestTimeFilter);
//      map.put("testprovider", testProviderFilter);
      map.put("orchestrationstatus", statusFilter);
      map.put("connectordata", targetExIdFilter);
      map.put("testoutcome", testOutcomeFilter);
      map.put("duration", durationFilter);
      map.put("notes", notesFilter);
      map.put("spoofcli", spoofedCliFilter);
      map.put("targetcli", targetCliFilter);


      sqlBuilder.append(" WHERE ");
      boolean first = true;

      for (String key : map.keySet()) {
        first = appendString(sqlBuilder, first, key, map.get(key));
      }

    }

    sqlBuilder.append(" ORDER BY requesttime desc LIMIT ").append(rowCount).append(" OFFSET ").append(startIndex);


    Query query = entityManager.createNativeQuery(sqlBuilder.toString(), TestCase.class);

    return query.getResultList();
  }

  private boolean appendString(StringBuilder builder, boolean first, String column, String value) {
    if (value != null && !value.isEmpty()) {
      if (!first) {
        builder.append(" AND ");
      }
      builder.append(" CAST(").append(column).append(" AS TEXT) LIKE '%").append(value).append("%' ");
      first = false;
    }
    return first;
  }

  private boolean anyPopulated(String ... fields) {
    boolean anyPopulated = false;

    for (String field : fields) {
      anyPopulated = (anyPopulated || (field != null && !field.isEmpty()));
    }

    return anyPopulated;
  }
}
