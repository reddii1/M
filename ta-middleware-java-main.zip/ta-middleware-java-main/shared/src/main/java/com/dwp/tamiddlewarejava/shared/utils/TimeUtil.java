package com.dwp.tamiddlewarejava.shared.utils;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

import org.springframework.stereotype.Component;

@Component
public class TimeUtil {

  private TimeUtil() {}

  private static final LocalTime CLOCK_ZERO = LocalTime.parse("00:00:00");

  /**
   * Calculates the duration in milliseconds between a start timestamp and an end local date-time.
   *
   * @param start The starting timestamp.
   * @param end The ending local date-time.
   * @return The duration between the start and end times in milliseconds.
   */
  public static long calculateDurationInMillis(Timestamp start, LocalDateTime end) {
    Duration duration = Duration.between(start.toLocalDateTime(), end);
    return duration.toMillis();
  }

  /**
   * Calculates the duration in milliseconds from midnight to a specified time.
   *
   * @param clock The time string to parse, in HH:mm:ss format.
   * @return The duration in milliseconds from midnight to the specified time, or -1 if the time
   *     string is invalid.
   */
  public static long clockDuration(String clock) {
    try {
      LocalTime time = LocalTime.parse(clock);
      Duration duration = Duration.between(CLOCK_ZERO, time);
      return duration.toMillis();
    } catch (DateTimeParseException e) {
      return -1;
    }
  }

  /**
   * Calculates an expiry Instant based on a specified number of hours ago.
   *
   * @param timeoutHours The number of hours before the current time to calculate the expiry.
   * @return An Instant representing the calculated expiry time.
   */
  public static Instant calculateExpiry(Integer timeoutHours) {
    return Instant.now().minus(timeoutHours, ChronoUnit.HOURS);
  }
}
