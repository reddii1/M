package com.dwp.tamiddlewarejava.shared.model.enums;

public enum TestProviderEnum {
  TestComplete("TestComplete"),
  Nectar("Nectar");

  private final String testProviderName;

  TestProviderEnum(String testProviderName) {
    this.testProviderName = testProviderName;
  }

  @Override
  public String toString() {
    return testProviderName;
  }
}
