package com.dwp.tamiddlewarejava.shared.model.errors;

public class DuplicateRecordException extends RuntimeException {
  public DuplicateRecordException(String message) {
    super(message);
  }
}
