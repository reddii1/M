package com.dwp.tamiddlewarejava.shared.utils;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class PasswordUtils {

  private PasswordUtils() {}

  private static final int MIN_PASSWORD_LENGTH = 12;
  private static final String VALIDATOR_SPECIAL_CHARACTERS = "!\"£$%^&*()#~'@:;<>/,.?|\\-_=+`¬";
  private static final String LOWERCASE_CHARS = "abcdefghijklmnopqrstuvwxyz";
  private static final String DIGITS = "0123456789";
  private static final String GENERATOR_SPECIAL_CHARS = "!@#$%^&*()-_=+[]{}|;:,.<>?";
  private static final SecureRandom random = new SecureRandom();

  /**
   * Validates if a given password meets the specified requirements for length, case, numbers, and
   * special characters.
   *
   * @param password The password string to be validated.
   * @return true if the password meets all requirements, false otherwise.
   * @throws IllegalArgumentException if the password does not meet the requirements.
   */
  public static boolean passwordDWPRequirementsMet(String password)
      throws IllegalArgumentException {
    if (password.length() < MIN_PASSWORD_LENGTH) {
      throw new IllegalArgumentException(
          "Password length "
              + password.length()
              + ". The new password should be a minimum of "
              + MIN_PASSWORD_LENGTH
              + " characters and include uppercase, lowercase, number and special character");
    }

    boolean hasUpper = false, hasLower = false, hasSpecial = false, hasNumber = false;
    for (char ch : password.toCharArray()) {
      if (Character.isUpperCase(ch)) {
        hasUpper = true;
      } else if (Character.isLowerCase(ch)) {
        hasLower = true;
      } else if (Character.isDigit(ch)) {
        hasNumber = true;
      } else if (VALIDATOR_SPECIAL_CHARACTERS.indexOf(ch) >= 0) {
        hasSpecial = true;
      }
    }

    if (!hasUpper) {
      throw new IllegalArgumentException("No upper case character, at least one needed");
    } else if (!hasLower) {
      throw new IllegalArgumentException("No lower case character, at least one needed");
    } else if (!hasNumber) {
      throw new IllegalArgumentException("No number present, at least one needed");
    } else if (!hasSpecial) {
      throw new IllegalArgumentException("No special character, at least one needed");
    }

    return hasUpper && hasLower && hasSpecial && hasNumber;
  }

  /**
   * Generates a cryptographically strong random salt.
   *
   * @return A byte array containing the generated salt.
   * @throws RuntimeException if the SecureRandom algorithm is not available.
   */
  public byte[] generateRandomSalt() {
    byte[] userSalt = new byte[48];
    try {
      SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
      sr.nextBytes(userSalt); // Fills userSalt with random bytes
    } catch (NoSuchAlgorithmException e) {
      // Handle the exception, perhaps use a different random number generator
      // Or rethrow as a RuntimeException if you can't recover
      throw new RuntimeException("Unable to get instance of SecureRandom", e);
    }
    return userSalt;
  }

  /**
   * Generates a random password of a specified length, ensuring it contains a minimum number of
   * digits and special characters.
   *
   * @param length The total length of the generated password.
   * @param minDigits The minimum number of digits the password must contain.
   * @param minSpecialChars The minimum number of special characters the password must contain.
   * @return A string representing the randomly generated password.
   * @throws IllegalArgumentException if the specified length is too short to satisfy the digit and
   *     special character requirements.
   */
  public static String generatePassword(int length, int minDigits, int minSpecialChars) {
    if (length < minDigits + minSpecialChars) {
      throw new IllegalArgumentException("Length is too short to satisfy the requirements.");
    }

    List<Character> charList = new ArrayList<>();

    // Add required number of digits
    for (int i = 0; i < minDigits; i++) {
      charList.add(DIGITS.charAt(random.nextInt(DIGITS.length())));
    }

    // Add required number of special characters
    for (int i = 0; i < minSpecialChars; i++) {
      charList.add(
          GENERATOR_SPECIAL_CHARS.charAt(random.nextInt(GENERATOR_SPECIAL_CHARS.length())));
    }

    // Fill the rest with lowercase letters
    while (charList.size() < length) {
      charList.add(LOWERCASE_CHARS.charAt(random.nextInt(LOWERCASE_CHARS.length())));
    }

    // Shuffle to randomize the character positions
    Collections.shuffle(charList);

    // Build the final password string
    StringBuilder password = new StringBuilder();
    for (char c : charList) {
      password.append(c);
    }

    return password.toString();
  }
}
