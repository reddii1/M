package com.dwp.tamiddlewarejava.shared.service.testcase;

import java.sql.Timestamp;
import java.util.UUID;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.model.testexecution.ExecutionDetails;

import jakarta.persistence.EntityManager;

@Service
public class TestCaseOperationsService {

  private EntityManager entityManager;

  public TestCaseOperationsService(EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  /**
   * Updates the orchestration status, test outcome, and start time of a specific test case.
   *
   * @param recordId The unique identifier of the test case to update.
   * @param status The new orchestration status to set.
   * @param outcome The new test outcome to set.
   * @param startTime The new start time to set.
   */
  @Transactional
  @Modifying
  public void updateStatusAndOutcome(
      UUID recordId, String status, String outcome, Timestamp startTime) {
    String sql =
        "UPDATE testcases SET orchestrationstatus = :orchestrationStatus, testoutcome = :testOutcome, starttime = :startTime WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", recordId)
        .setParameter("orchestrationStatus", status)
        .setParameter("testOutcome", outcome)
        .setParameter("startTime", startTime)
        .executeUpdate();
  }

  /**
   * Updates the connector data of a specific test case.
   *
   * @param id The unique identifier of the test case to update.
   * @param connectorData The new connector data to set.
   */
  @Transactional
  @Modifying
  public void updateConnectorData(UUID id, String connectorData) {
    String sql = "UPDATE testcases SET connectordata = :connectorData WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", id)
        .setParameter("connectorData", connectorData)
        .executeUpdate();
  }

  /**
   * Updates the connector data and start time of a specific test case when it starts running.
   *
   * @param id The unique identifier of the test case to update.
   * @param connectorData The new connector data to set.
   * @param startTime The new start time to set.
   */
  @Transactional
  @Modifying
  public void updateRunning(UUID id, String connectorData, Timestamp startTime) {
    String sql =
        "UPDATE testcases SET connectordata = :connectorData, starttime = :startTime WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", id)
        .setParameter("connectorData", connectorData)
        .setParameter("startTime", startTime)
        .executeUpdate();
  }

  /**
   * Updates the execution details of a test case after it has been executed by Nectar.
   *
   * @param id The unique identifier of the test case to update.
   * @param orchestrationStatus The new orchestration status to set.
   * @param testOutcome The new test outcome to set.
   * @param notes Additional notes related to the execution.
   * @param duration The duration of the test execution.
   * @param startTime The start time of the test execution.
   */
  @Transactional
  @Modifying
  public void updateNectarExecuted(
      UUID id,
      String orchestrationStatus,
      String testOutcome,
      String notes,
      long duration,
      Timestamp startTime) {
    String sql =
        "UPDATE testcases SET orchestrationstatus = :orchestrationStatus, testoutcome = :testOutcome, notes = :notes, duration = :duration, starttime = :startTime WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", id)
        .setParameter("orchestrationStatus", orchestrationStatus)
        .setParameter("testOutcome", testOutcome)
        .setParameter("notes", notes)
        .setParameter("duration", duration)
        .setParameter("startTime", startTime)
        .executeUpdate();
  }

  /**
   * Updates the execution details of a test case after it has been executed by TestComplete.
   *
   * @param id The unique identifier of the test case to update.
   * @param connectorData The new connector data to set.
   * @param testOutcome The new test outcome to set.
   * @param notes Additional notes related to the execution.
   * @param duration The duration of the test execution.
   */
  @Transactional
  @Modifying
  public void updateTestCompleteExecuted(
      UUID id, String connectorData, String testOutcome, String notes, long duration) {
    String sql =
        "UPDATE testcases SET connectordata = :connectorData, testoutcome = :testOutcome, notes = :notes, duration = :duration WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", id)
        .setParameter("connectorData", connectorData)
        .setParameter("testOutcome", testOutcome)
        .setParameter("notes", notes)
        .setParameter("duration", duration)
        .executeUpdate();
  }

  /**
   * Updates the orchestration status of a specific test case.
   *
   * @param id The unique identifier of the test case to update.
   * @param status The new orchestration status to set.
   */
  @Transactional
  @Modifying
  public void updateStatus(UUID id, String status) {
    String sql = "UPDATE testcases SET orchestrationstatus = :status WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", id)
        .setParameter("status", status)
        .executeUpdate();
  }

  /**
   * Updates a test case as failed, setting its orchestration status, test outcome, notes, and start
   * time.
   *
   * @param id The unique identifier of the test case to update.
   * @param status The new orchestration status to set (typically indicating failure).
   * @param outcome The new test outcome to set.
   * @param notes Additional notes related to the failure.
   * @param startTime The time of failure.
   */
  @Transactional
  @Modifying
  public void updateFailed(
      UUID id, String status, String outcome, String notes, Timestamp startTime) {
    String sql =
        "UPDATE testcases SET orchestrationstatus = :status, testoutcome = :outcome, notes = :notes, starttime = :startTime WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", id)
        .setParameter("status", status)
        .setParameter("outcome", outcome)
        .setParameter("notes", notes)
        .setParameter("startTime", startTime)
        .executeUpdate();
  }

  /**
   * Increments the start attempts counter for a specific test case.
   *
   * @param id The unique identifier of the test case to increment the start attempts for.
   */
  @Transactional
  @Modifying
  public void incrementStartAttempts(UUID id) {
    String sql = "UPDATE testcases SET startattempts = startattempts + 1 WHERE id = :id";
    entityManager.createNativeQuery(sql).setParameter("id", id).executeUpdate();
  }

  /**
   * Updates the notes of a specific test case.
   *
   * @param id The unique identifier of the test case to update.
   * @param notes The new notes to set.
   */
  @Transactional
  @Modifying
  public void updateNotes(UUID id, String notes) {
    String sql = "UPDATE testcases SET notes = :notes WHERE id = :id";
    entityManager
        .createNativeQuery(sql)
        .setParameter("id", id)
        .setParameter("notes", notes)
        .executeUpdate();
  }

  /**
   * Updates various fields of a specific test case based on execution details and test provider.
   *
   * @param testCase The test case to update.
   * @param executionDetails The execution details to use for the update.
   * @param provider The provider of the test execution (e.g., 'Nectar' or 'TestComplete').
   */
  @Transactional
  @Modifying
  public void updateTestCase(
      TestCase testCase, ExecutionDetails executionDetails, String provider) {
    String sql =
        "UPDATE testcases SET eid = :eid, atid = :atid, atidhost = :atidHost, testprovider = :provider, testerid = :testerId, spoofcli = :spoofCLI, targetcli = :targetCLI, orchestrationstatus = 'Ready' WHERE id = :id AND orchestrationstatus != 'Cancelled'";
    entityManager
        .createNativeQuery(sql)
        .setParameter("eid", executionDetails.getId())
        .setParameter("atid", executionDetails.getAtid())
        .setParameter("atidHost", executionDetails.getAtidHost())
        .setParameter("provider", provider)
        .setParameter("testerId", executionDetails.getTesterId())
        .setParameter("spoofCLI", executionDetails.getSpoofCLI())
        .setParameter("targetCLI", executionDetails.getTargetCLI())
        .setParameter("id", testCase.getId())
        .executeUpdate();
  }
}
