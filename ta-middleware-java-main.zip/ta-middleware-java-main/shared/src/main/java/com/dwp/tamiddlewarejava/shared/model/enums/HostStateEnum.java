package com.dwp.tamiddlewarejava.shared.model.enums;

public enum HostStateEnum {
  AVAILABLE("Available"),
  EXECUTING("Executing");

  private final String hostState;

  HostStateEnum(String hostState) {
    this.hostState = hostState;
  }

  @Override
  public String toString() {
    return hostState;
  }
}
