package com.dwp.tamiddlewarejava.shared.model.testcase;

import java.sql.Timestamp;
import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "testcases")
public class TestCase {

  @Id private UUID id;
  private Integer cpid;
  private Timestamp startTime;
  private Long duration;
  private Integer eid;
  private Integer testerId;
  private Integer tcid;
  private String connectorData;
  private Timestamp requestTime;
  private Integer rid;
  private Integer cid;
  private Integer startAttempts;
  private String atidHost;
  private String atid;
  private String testProvider;
  private String orchestrationStatus;
  private String testOutcome;
  private String notes = "";
  private String targetCli;
  private String spoofCli;
  private String cidname;
  private String ridname;
  private String projectname;
  private Integer pid;
  private String startedby;
  private String cpname;
  private String tcidname;
}
