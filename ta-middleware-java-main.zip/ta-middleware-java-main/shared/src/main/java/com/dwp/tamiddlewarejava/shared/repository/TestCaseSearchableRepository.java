package com.dwp.tamiddlewarejava.shared.repository;

public interface TestCaseSearchableRepository {
}
