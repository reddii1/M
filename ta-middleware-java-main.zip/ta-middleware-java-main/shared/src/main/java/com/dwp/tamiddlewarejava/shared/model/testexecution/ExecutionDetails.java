package com.dwp.tamiddlewarejava.shared.model.testexecution;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ExecutionDetails {
  private int id;
  private int testerId;
  private String atid;
  private String atidHost;
  private String targetCLI;
  private String spoofCLI;
}
