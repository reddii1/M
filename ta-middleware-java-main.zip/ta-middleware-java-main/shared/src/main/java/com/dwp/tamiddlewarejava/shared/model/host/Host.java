package com.dwp.tamiddlewarejava.shared.model.host;

import com.dwp.tamiddlewarejava.shared.model.enums.TestProviderEnum;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "hosts")
public class Host {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  private String zephyrHostId;
  private String hostName;
  private String hostStatus;
  private String projectsRoot;
  private String teamName;

  @Enumerated(EnumType.STRING)
  private TestProviderEnum testProvider;

  private String username;
  private String password;
}
