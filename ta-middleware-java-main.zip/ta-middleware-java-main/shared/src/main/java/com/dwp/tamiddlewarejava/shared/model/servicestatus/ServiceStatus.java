package com.dwp.tamiddlewarejava.shared.model.servicestatus;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.Id;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "servicestatus")
public class ServiceStatus {
    @Id private int id;
    private String service;
    private String status;
}
