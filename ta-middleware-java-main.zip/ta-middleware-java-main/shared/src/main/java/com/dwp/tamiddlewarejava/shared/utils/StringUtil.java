package com.dwp.tamiddlewarejava.shared.utils;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class StringUtil {

  private StringUtil() {}

  private static final Pattern UUID_PATTERN =
      Pattern.compile(
          "^(?:[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|[0-9a-fA-F]{32})$");

  /**
   * Sanitizes a string by removing all non-printable characters and spaces.
   *
   * @param input The string to be sanitized.
   * @return The sanitized string with non-printable characters and spaces removed. Returns null if
   *     the input string is null.
   */
  public static String sanitizeString(String input) {
    if (input == null) {
      return null;
    }

    // Replace all non-printable characters and spaces with an empty string
    return input.replaceAll("[\\p{C}\\s]", "");
  }

  /**
   * Validates whether a given string is a valid UUID format.
   *
   * @param uuid The string to validate as a UUID.
   * @return true if the string matches the UUID pattern, false otherwise.
   */
  public static boolean isValidUUID(String uuid) {
    return UUID_PATTERN.matcher(uuid).matches();
  }

  /**
   * Checks if a given string is null or empty.
   *
   * @param input The string to check for null or empty condition.
   * @return true if the string is null or empty, false otherwise.
   */
  public static boolean isNullOrEmpty(String input) {
    return input == null || input.isEmpty();
  }

  /**
   * Checks if a given string is null, empty, or contains only whitespace.
   *
   * @param input The string to check for null, empty, or whitespace-only condition.
   * @return true if the string is null, empty, or contains only whitespace, false otherwise.
   */
  public static boolean isNullOrWhiteSpace(String input) {
    return input == null || input.trim().isEmpty();
  }
}
