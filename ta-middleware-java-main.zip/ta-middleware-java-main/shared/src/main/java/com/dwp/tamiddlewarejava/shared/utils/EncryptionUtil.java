package com.dwp.tamiddlewarejava.shared.utils;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

@Component
public class EncryptionUtil {

  private EncryptionUtil() {}

  private static final String ALGORITHM = "AES/GCM/NoPadding";
  private static final int IV_LENGTH_BYTES = 12;
  private static final int TAG_LENGTH_BIT = 128;
  private static final int KEY_LENGTH_BYTE = 16;
  private static final int MINIMUM_SECRET_KEY_LENGTH = 20;

  /**
   * Generates a SecretKeySpec from a given secret key string.
   *
   * @param secret The secret key string from which the AES key is derived.
   * @return A SecretKeySpec for AES encryption.
   * @throws Exception if there's an error during key generation.
   */
  private static SecretKeySpec getKey(String secret) throws Exception {
    MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
    byte[] key = Arrays.copyOf(sha256.digest(secret.getBytes("UTF-8")), KEY_LENGTH_BYTE);
    return new SecretKeySpec(key, "AES");
  }

  /**
   * Encrypts a given input string (password) using AES/GCM/NoPadding.
   *
   * @param input The plaintext password to encrypt.
   * @param secretKey The secret key used for encryption.
   * @return A Base64 encoded string containing the IV and the encrypted password.
   * @throws RuntimeException if encryption fails due to invalid key or algorithm parameters.
   */
  public static String encryptPassword(String input, String secretKey) {
    try {
      if (secretKey == null || secretKey.getBytes("UTF-8").length < MINIMUM_SECRET_KEY_LENGTH) {
        throw new Exception("Secret key is null or empty");
      }

      SecretKeySpec key = getKey(secretKey);
      Cipher cipher = Cipher.getInstance(ALGORITHM);
      byte[] iv = new byte[IV_LENGTH_BYTES];
      SecureRandom.getInstanceStrong().nextBytes(iv);
      GCMParameterSpec spec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);
      cipher.init(Cipher.ENCRYPT_MODE, key, spec);
      byte[] encrypted = cipher.doFinal(input.getBytes("UTF-8"));
      byte[] encryptedIVAndText = new byte[iv.length + encrypted.length];
      System.arraycopy(iv, 0, encryptedIVAndText, 0, iv.length);
      System.arraycopy(encrypted, 0, encryptedIVAndText, iv.length, encrypted.length);
      return Base64.getEncoder().encodeToString(encryptedIVAndText);
    } catch (Exception e) {
      throw new RuntimeException("Encryption error", e);
    }
  }

  /**
   * Decrypts a Base64 encoded input string (encrypted password) using AES/GCM/NoPadding.
   *
   * @param encryptedInput The Base64 encoded string containing the IV and the encrypted password.
   * @param secretKey The secret key used for decryption.
   * @return The decrypted plaintext password.
   * @throws RuntimeException if decryption fails due to invalid key, algorithm parameters, or if
   *     the input data is tampered with or corrupted.
   */
  public static String decryptPassword(String encryptedInput, String secretKey) {
    try {
      if (secretKey == null || secretKey.getBytes("UTF-8").length < MINIMUM_SECRET_KEY_LENGTH) {
        throw new Exception("Secret key is null or empty");
      }

      byte[] decoded = Base64.getDecoder().decode(encryptedInput);
      byte[] iv = Arrays.copyOfRange(decoded, 0, IV_LENGTH_BYTES);
      byte[] encryptedText = Arrays.copyOfRange(decoded, IV_LENGTH_BYTES, decoded.length);
      SecretKeySpec key = getKey(secretKey);
      Cipher cipher = Cipher.getInstance(ALGORITHM);
      GCMParameterSpec spec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);
      cipher.init(Cipher.DECRYPT_MODE, key, spec);
      byte[] decrypted = cipher.doFinal(encryptedText);
      return new String(decrypted, "UTF-8");
    } catch (Exception e) {
      throw new RuntimeException("Decryption error", e);
    }
  }
}
