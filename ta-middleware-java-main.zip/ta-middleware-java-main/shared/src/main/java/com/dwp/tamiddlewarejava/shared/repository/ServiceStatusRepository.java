package com.dwp.tamiddlewarejava.shared.repository;

import com.dwp.tamiddlewarejava.shared.model.servicestatus.ServiceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ServiceStatusRepository  extends JpaRepository<ServiceStatus, Integer> {
    @Query(
            value =
                    "SELECT * FROM servicestatus",
            nativeQuery = true)
    List<ServiceStatus> getAllServiceStatuses();



    @Transactional
    @Modifying
    @Query(
            value =
                    "INSERT INTO servicestatus (service, status) VALUES (?1, ?2)",
            nativeQuery = true)
    void createServiceStatus(
            String service,
            String status);

    @Query(
            value =
                    "SELECT * FROM servicestatus WHERE service = ?1",
            nativeQuery = true)
    List<ServiceStatus> getServiceStatus(
            String service
    );


    @Transactional
    @Modifying
    @Query(
            value =
                    "UPDATE servicestatus SET status = ?1 WHERE service = ?2",
            nativeQuery = true)
    void updateServiceStatus(
            String status,
            String service);

}
