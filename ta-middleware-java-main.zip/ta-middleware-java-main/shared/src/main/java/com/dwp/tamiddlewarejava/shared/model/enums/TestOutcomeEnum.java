package com.dwp.tamiddlewarejava.shared.model.enums;

public enum TestOutcomeEnum {
  NOT_EXECUTED("Not Executed"),
  PASSED("Passed"),
  FAILED("Failed"),
  IN_PROGRESS("In Progress"),
  FAILED_TO_EXECUTE("Failed to Execute"),
  TIMED_OUT("Timed Out"),
  MW_HOST_DOES_NOT_EXIST("MW Host doesn't exist"),
  STOPPED_IN_MIDDLEWARE("Stopped in Middleware"),
  ATID_NOT_DEFINED("ATID not defined"),
  MW_HOST_NOT_DEFINED("Host not defined");

  private final String testOutcomeDescription;

  TestOutcomeEnum(String testOutcomeDescription) {
    this.testOutcomeDescription = testOutcomeDescription;
  }

  @Override
  public String toString() {
    return testOutcomeDescription;
  }
}
