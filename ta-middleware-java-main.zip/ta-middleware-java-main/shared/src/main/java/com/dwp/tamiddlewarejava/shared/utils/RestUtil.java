package com.dwp.tamiddlewarejava.shared.utils;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.springframework.stereotype.Component;

@Component
public class RestUtil {

  private RestUtil() {}

  /**
   * Creates a Basic Authentication header value using provided username and password.
   *
   * @param username The username for authentication.
   * @param password The password for authentication.
   * @return The Basic Authentication header value.
   */
  public static String createBasicAuthHeader(String username, String password) {
    String credentials = username + ":" + password;
    String encodedCredentials =
        Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
    return "Basic " + encodedCredentials;
  }
}
