package com.dwp.tamiddlewarejava.shared.model.enums;

public enum OrchestrationStatusEnum {
  NEW("New"),
  READY("Ready"),
  EXECUTED("Executed"),
  COMPLETED("Completed"),
  FAILED("Failed"),
  CANCELLED("Cancelled"),
  EXECUTING("Executing");

  private final String status;

  OrchestrationStatusEnum(String status) {
    this.status = status;
  }

  @Override
  public String toString() {
    return status;
  }
}
