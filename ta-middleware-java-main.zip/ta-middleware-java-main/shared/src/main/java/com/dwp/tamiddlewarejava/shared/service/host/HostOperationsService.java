package com.dwp.tamiddlewarejava.shared.service.host;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.host.Host;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;

@Service
public class HostOperationsService {

  private final Logger logger = LoggerFactory.getLogger(HostOperationsService.class);
  private TestCaseOperationsService testCaseOperationsService;
  private HostStateService hostStateService;

  private EntityManager entityManager;

  public HostOperationsService(
      EntityManager entityManager,
      TestCaseOperationsService testCaseOperationsService,
      HostStateService hostStateService) {
    this.entityManager = entityManager;
    this.testCaseOperationsService = testCaseOperationsService;
    this.hostStateService = hostStateService;
  }

  /**
   * Retrieves a host entry from the database based on the specified Zephyr host ID and test
   * provider.
   *
   * @param zephyrHostId The Zephyr host ID to search for.
   * @param testProvider The name of the test provider associated with the host.
   * @return The matching Host entity or null if no match is found.
   */
  public Host selectHost(String zephyrHostId, String testProvider) {
    String sql =
        "SELECT * FROM hosts WHERE testprovider = :testProvider AND zephyrhostid = :zephyrHostId LIMIT 1";
    try {
      return (Host)
          entityManager
              .createNativeQuery(sql, Host.class)
              .setParameter("zephyrHostId", zephyrHostId)
              .setParameter("testProvider", testProvider)
              .getSingleResult();
    } catch (NoResultException e) {
      return null;
    }
  }

  /**
   * Retrieves the project root directory for a specified host from the database.
   *
   * @param hostName The name of the host to search for.
   * @return The project root directory as a string, or an empty string if the host is not found.
   */
  public String selectHostProjectRoot(String hostName) {
    String sql = "SELECT projectsroot FROM hosts WHERE hostname = :hostName";

    try {
      return (String)
          entityManager.createNativeQuery(sql).setParameter("hostName", hostName).getSingleResult();
    } catch (NoResultException e) {
      return "";
    }
  }

  /**
   * Retrieves credentials for a specified host from the database.
   *
   * @param hostName The name of the host for which credentials are being requested.
   * @return A HostCredentials object with the retrieved credentials, or null if the host is not
   *     found.
   */
  public HostCredentials selectHostCredentials(String hostName) {
    String sql = "SELECT username, password FROM hosts WHERE hostname = :hostName";
    try {
      return (HostCredentials)
          entityManager
              .createNativeQuery(sql, HostCredentials.class)
              .setParameter("hostName", hostName)
              .getSingleResult();
    } catch (NoResultException e) {
      return null;
    }
  }

  /**
   * Marks a test case as failed and releases the associated host back to an available state.
   *
   * @param testCase The test case that has failed.
   * @param hostName The name of the host to be released.
   * @param failureReason The reason for the test case failure.
   */
  public void failTestAndReleaseHost(TestCase testCase, String hostName, String failureReason) {
    logger.error("Failing Test for {} and releasing Host {} ", testCase.getId(), hostName);

    Timestamp now = new Timestamp(System.currentTimeMillis());
    testCaseOperationsService.updateFailed(
        testCase.getId(),
        OrchestrationStatusEnum.EXECUTED.toString(),
        TestOutcomeEnum.FAILED_TO_EXECUTE.toString(),
        failureReason,
        now);

    logger.error(failureReason);

    hostStateService.updateHostState(hostName, HostStateEnum.AVAILABLE.toString());
  }

  /**
   * Retrieves and constructs a HostCredentials object for a specified host.
   *
   * @param host The name of the host for which credentials are being requested.
   * @return A new HostCredentials object if credentials are found, or null otherwise.
   */
  public HostCredentials getHostCredentials(String host) {
    try {
      HostCredentials hostCredentials = selectHostCredentials(host);

      if (hostCredentials != null) {
        return new HostCredentials(hostCredentials.getUsername(), hostCredentials.getPassword());
      } else {
        logger.error("No credentials found for host: " + host);
      }
    } catch (Error e) {
      logger.error(e.getMessage(), e);
    }
    return null;
  }
}
