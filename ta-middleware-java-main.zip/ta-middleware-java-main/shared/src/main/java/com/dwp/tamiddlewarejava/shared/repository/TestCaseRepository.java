package com.dwp.tamiddlewarejava.shared.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;

public interface TestCaseRepository extends JpaRepository<TestCase, UUID> {
  // Custom query
  @Query(
      value = "SELECT * FROM testcases ORDER BY requesttime desc LIMIT ?2 OFFSET ?1",
      nativeQuery = true)
  List<TestCase> findPaginatedTestCases(Integer startIndex, Integer rowCount);

  @Query(
          value = "SELECT * FROM testcases " +
                  "WHERE " +
                    "CAST(tcid AS TEXT) LIKE ?3 " +
                    "OR CAST(cid AS TEXT) LIKE ?3 " +
                  "ORDER BY requesttime desc LIMIT ?2 OFFSET ?1",
          nativeQuery = true
  )
  List<TestCase> findFilteredPaginatedTestCases(Integer startIndex, Integer rowCount, String filter);

  @Query(
      value =
          "SELECT * FROM testcases WHERE orchestrationstatus IN ('Ready', 'Executing') AND testprovider =?1",
      nativeQuery = true)
  List<TestCase> getTestProviderTestCases(String testProvider);




  @Query(
      value =
          "SELECT * FROM testcases WHERE orchestrationstatus IN ('New', 'Executed', 'Cancelled') ",
      nativeQuery = true)
  List<TestCase> getAllZephyrTestCases();
}
