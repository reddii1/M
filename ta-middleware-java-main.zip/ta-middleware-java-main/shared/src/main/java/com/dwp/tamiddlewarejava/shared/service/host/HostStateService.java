package com.dwp.tamiddlewarejava.shared.service.host;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityManager;

@Service
public class HostStateService {

  private EntityManager entityManager;

  public HostStateService(EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  /**
   * Updates the state of a specified host in the database.
   *
   * @param hostName The name of the host whose state is being updated.
   * @param hostStatus The new state to set for the host.
   */
  @Transactional
  @Modifying
  public void updateHostState(String hostName, String hostStatus) {
    String sql = "UPDATE hosts SET hoststatus = :hostStatus WHERE hostname = :hostName";
    entityManager
        .createNativeQuery(sql)
        .setParameter("hostName", hostName)
        .setParameter("hostStatus", hostStatus)
        .executeUpdate();
  }
}
