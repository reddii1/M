package com.dwp.tamiddlewarejava.shared.model.errors;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustomApplicationError extends Exception {
  private String message;
}
