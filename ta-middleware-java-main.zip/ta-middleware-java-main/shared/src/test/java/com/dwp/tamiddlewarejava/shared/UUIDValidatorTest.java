package com.dwp.tamiddlewarejava.shared;

import org.junit.jupiter.api.Test;
import com.dwp.tamiddlewarejava.shared.utils.StringUtil;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class UUIDValidatorTest {

  @Test
  void testValidUUID() {
    String validUUID = "123e4567-e89b-12d3-a456-426614174000";
    assertTrue(StringUtil.isValidUUID(validUUID), "This should be recognized as a valid UUID.");
  }

  @Test
  void testInvalidUUIDTooShort() {
    String invalidUUID = "123e4567-e89b-12d3-a456-42661417400";
    assertFalse(
        StringUtil.isValidUUID(invalidUUID),
        "This should be recognized as an invalid UUID due to being too short.");
  }

  @Test
  void testInvalidUUIDTooLong() {
    String invalidUUID = "123e4567-e89b-12d3-a456-4266141740000";
    assertFalse(
        StringUtil.isValidUUID(invalidUUID),
        "This should be recognized as an invalid UUID due to being too long.");
  }

  @Test
  void testInvalidUUIDWithIllegalCharacters() {
    String invalidUUID = "123e4567-e89b-12d3-a456-42661417400g";
    assertFalse(
        StringUtil.isValidUUID(invalidUUID),
        "This should be recognized as an invalid UUID due to illegal characters.");
  }

  @Test
  void testValidUUIDNoHyphens() {
    String validUUID = "123e4567e89b12d3a456426614174000";
    assertTrue(
        StringUtil.isValidUUID(validUUID),
        "This should be recognized as a valid UUID even due to missing hyphens.");
  }

  @Test
  void testValidUUIDUpperCase() {
    String validUUID = "123E4567-E89B-12D3-A456-426614174000";
    assertTrue(
        StringUtil.isValidUUID(validUUID),
        "This should be recognized as a valid UUID even with uppercase letters.");
  }

  @Test
  void testValidUUIDMixedCase() {
    String validUUID = "123e4567-E89b-12D3-a456-426614174000";
    assertTrue(
        StringUtil.isValidUUID(validUUID),
        "This should be recognized as a valid UUID even with mixed case.");
  }
}
