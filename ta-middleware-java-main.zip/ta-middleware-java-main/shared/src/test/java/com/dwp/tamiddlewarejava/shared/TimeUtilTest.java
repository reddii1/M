package com.dwp.tamiddlewarejava.shared;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.dwp.tamiddlewarejava.shared.utils.TimeUtil;

import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.Month;

class TimeUtilTest {

  @Test
  void testCalculateDurationInMillis() {
    LocalDateTime startDateTime = LocalDateTime.of(2021, Month.JANUARY, 1, 0, 0, 0);
    Timestamp startTimestamp = Timestamp.valueOf(startDateTime);

    LocalDateTime endDateTime = LocalDateTime.of(2021, Month.JANUARY, 1, 1, 0, 0); // 1 hour later
    long expectedDurationMillis = 3600000;

    long actualDurationMillis = TimeUtil.calculateDurationInMillis(startTimestamp, endDateTime);

    assertEquals(
        expectedDurationMillis,
        actualDurationMillis,
        "The calculated duration in milliseconds should be correct.");
  }

  @Test
  void testClockDurationValidTime() {
    String clock = "01:00:00";
    long expectedMillis = 3600000;

    long actualMillis = TimeUtil.clockDuration(clock);

    assertEquals(
        expectedMillis,
        actualMillis,
        "The duration in milliseconds for a valid time should be correctly calculated.");
  }

  @Test
  void testClockDurationInvalidTime() {
    String invalidClock = "25:00:00";

    long actualMillis = TimeUtil.clockDuration(invalidClock);

    assertEquals(
        -1, actualMillis, "The duration in milliseconds for an invalid time should return -1.");
  }
}
