package com.dwp.tamiddlewarejava.shared;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.host.Host;
import com.dwp.tamiddlewarejava.shared.model.host.HostCredentials;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.service.host.HostOperationsService;
import com.dwp.tamiddlewarejava.shared.service.host.HostStateService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

class HostOperationsTest {

  @Mock private EntityManager entityManager;

  @Mock private TestCaseOperationsService testCaseOperationsService;

  @Mock private HostStateService hostStateService;

  @InjectMocks private HostOperationsService hostOperationsService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    hostOperationsService =
        new HostOperationsService(entityManager, testCaseOperationsService, hostStateService);
  }

  @Test
  void shouldReturnTestCompleteHostWhenGivenZephyrHostIdAndProvider() {
    String zephyrHostId = "someZephyrHostId";
    Host expectedHost = new Host();
    String testProvider = "TestComplete";

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString(), eq(Host.class))).thenReturn(mockedQuery);
    when(mockedQuery.setParameter("zephyrHostId", zephyrHostId)).thenReturn(mockedQuery);
    when(mockedQuery.setParameter("testProvider", testProvider)).thenReturn(mockedQuery);
    when(mockedQuery.getSingleResult()).thenReturn(expectedHost);

    Host result = hostOperationsService.selectHost(zephyrHostId, testProvider);

    assertEquals(expectedHost, result);
  }

  @Test
  void shouldReturnProjectRootPathWhenGivenHostName() {
    String hostName = "hostName";
    String expectedProjectRoot = "/var/projects";

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter("hostName", hostName)).thenReturn(mockedQuery);
    when(mockedQuery.getSingleResult()).thenReturn(expectedProjectRoot);

    String result = hostOperationsService.selectHostProjectRoot(hostName);

    assertEquals(expectedProjectRoot, result);
  }

  @Test
  void shouldReturnHostCredentialsWhenGivenHostName() {
    String hostName = "hostName";
    HostCredentials expectedCredentials = new HostCredentials("user", "pass");

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString(), eq(HostCredentials.class)))
        .thenReturn(mockedQuery);
    when(mockedQuery.setParameter("hostName", hostName)).thenReturn(mockedQuery);
    when(mockedQuery.getSingleResult()).thenReturn(expectedCredentials);

    HostCredentials result = hostOperationsService.selectHostCredentials(hostName);

    assertEquals(expectedCredentials, result);
  }

  @Test
  void shouldFailTestUpdateStatusAndReleaseHostWhenGivenTestDetailsAndReason() {
    String hostName = "hostName";
    String reason = "failure reason";
    TestCase testCase = new TestCase();
    testCase.setId(UUID.randomUUID());

    doNothing()
        .when(testCaseOperationsService)
        .updateFailed(
            eq(testCase.getId()), anyString(), anyString(), eq(reason), any(Timestamp.class));
    doNothing()
        .when(hostStateService)
        .updateHostState(hostName, HostStateEnum.AVAILABLE.toString());

    hostOperationsService.failTestAndReleaseHost(testCase, hostName, reason);

    verify(testCaseOperationsService)
        .updateFailed(
            eq(testCase.getId()),
            eq(OrchestrationStatusEnum.EXECUTED.toString()),
            eq(TestOutcomeEnum.FAILED_TO_EXECUTE.toString()),
            eq(reason),
            any(Timestamp.class));
    verify(hostStateService).updateHostState(hostName, HostStateEnum.AVAILABLE.toString());
  }

  @Test
  void shouldReturnNectarHostWhenGivenZephyrHostIdAndProvider() {
    String zephyrHostId = "someZephyrHostId";
    Host expectedHost = new Host();
    String testProvider = "Nectar";

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString(), eq(Host.class))).thenReturn(mockedQuery);
    when(mockedQuery.setParameter("zephyrHostId", zephyrHostId)).thenReturn(mockedQuery);
    when(mockedQuery.setParameter("testProvider", testProvider)).thenReturn(mockedQuery);
    when(mockedQuery.getSingleResult()).thenReturn(expectedHost);

    Host result = hostOperationsService.selectHost(zephyrHostId, testProvider);

    assertEquals(expectedHost, result);
  }
}
