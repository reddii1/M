package com.dwp.tamiddlewarejava.shared;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dwp.tamiddlewarejava.shared.model.enums.HostStateEnum;
import com.dwp.tamiddlewarejava.shared.service.host.HostStateService;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

class HostStateTest {

  @Mock private EntityManager entityManager;

  @Mock private TestCaseOperationsService testCaseOperationsService;

  @InjectMocks private HostStateService hostStateService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    hostStateService = new HostStateService(entityManager);
  }

  @Test
  void testUpdateHostState() {
    String hostName = "testHost";
    String hostStatus = HostStateEnum.AVAILABLE.toString();

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), anyString())).thenReturn(mockedQuery);

    hostStateService.updateHostState(hostName, hostStatus);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("hostName", hostName);
    verify(mockedQuery, times(1)).setParameter("hostStatus", hostStatus);
    verify(mockedQuery, times(1)).executeUpdate();
  }
}
