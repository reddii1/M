package com.dwp.tamiddlewarejava.shared;

import com.dwp.tamiddlewarejava.shared.utils.EncryptionUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class EncryptionUtilTest {

  @Test
  void testEncryptAndDecryptPassword() {
    String originalPassword = "MySuperSecretPassword";
    String secretKey = "MySecretKey1234567890";

    String encryptedPassword = EncryptionUtil.encryptPassword(originalPassword, secretKey);
    Assertions.assertNotNull(encryptedPassword, "Encrypted password should not be null");

    String decryptedPassword = EncryptionUtil.decryptPassword(encryptedPassword, secretKey);
    Assertions.assertEquals(
        originalPassword, decryptedPassword, "Decrypted password should match the original");
  }

  @Test
  void testEncryptionAndDecryptionWithDifferentKeys() {
    String originalPassword = "AnotherSuperSecretPassword";
    String secretKeyForEncryption = "EncryptionKey123456%^GH";
    String secretKeyForDecryption = "WrongDecryptionKey!!";

    String encryptedPassword =
        EncryptionUtil.encryptPassword(originalPassword, secretKeyForEncryption);
    Assertions.assertNotNull(encryptedPassword, "Encrypted password should not be null");

    // Expecting the decryption to fail due to different keys
    Assertions.assertThrows(
        RuntimeException.class,
        () -> EncryptionUtil.decryptPassword(encryptedPassword, secretKeyForDecryption),
        "Decryption with a wrong key should throw an exception");
  }

  @Test
  void testEncryptWithInvalidKey() {
    String originalPassword = "PasswordToEncrypt";
    String shortSecretKey = ""; // Intentionally using an invalid key length

    // Expecting the encryption to fail due to invalid key
    Assertions.assertThrows(
        RuntimeException.class,
        () -> EncryptionUtil.encryptPassword(originalPassword, shortSecretKey),
        "Encryption with an invalid key should throw an exception");
  }
}
