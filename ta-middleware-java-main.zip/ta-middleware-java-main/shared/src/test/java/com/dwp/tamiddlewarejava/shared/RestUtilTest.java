package com.dwp.tamiddlewarejava.shared;

import org.junit.jupiter.api.Test;

import com.dwp.tamiddlewarejava.shared.utils.RestUtil;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

class RestUtilTest {

  @Test
  void testCreateBasicAuthHeader() {
    String username = "testUser";
    String password = "testPass";

    String expectedCredentials =
        "Basic "
            + Base64.getEncoder()
                .encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));

    String actualHeader = RestUtil.createBasicAuthHeader(username, password);

    assertEquals(
        expectedCredentials,
        actualHeader,
        "The Basic Auth header should match the expected format and value.");
  }
}
