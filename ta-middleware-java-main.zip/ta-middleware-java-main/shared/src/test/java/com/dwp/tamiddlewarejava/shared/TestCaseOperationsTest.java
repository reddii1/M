package com.dwp.tamiddlewarejava.shared;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.dwp.tamiddlewarejava.shared.model.enums.OrchestrationStatusEnum;
import com.dwp.tamiddlewarejava.shared.model.enums.TestOutcomeEnum;
import com.dwp.tamiddlewarejava.shared.model.testcase.TestCase;
import com.dwp.tamiddlewarejava.shared.model.testexecution.ExecutionDetails;
import com.dwp.tamiddlewarejava.shared.service.testcase.TestCaseOperationsService;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

class TestCaseOperationsTest {

  @Mock private EntityManager entityManager;

  private TestCaseOperationsService testCaseOperationsService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    testCaseOperationsService = new TestCaseOperationsService(entityManager);
  }

  @Test
  void testUpdateStatusAndOutcome() {
    UUID recordId = UUID.randomUUID();
    String status = OrchestrationStatusEnum.READY.toString();
    String outcome = TestOutcomeEnum.IN_PROGRESS.toString();
    Timestamp startTime = new Timestamp(System.currentTimeMillis());

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateStatusAndOutcome(recordId, status, outcome, startTime);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", recordId);
    verify(mockedQuery, times(1)).setParameter("orchestrationStatus", status);
    verify(mockedQuery, times(1)).setParameter("testOutcome", outcome);
    verify(mockedQuery, times(1)).setParameter("startTime", startTime);
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testUpdateTestCase() {
    UUID testCaseId = UUID.randomUUID();
    TestCase testCase = new TestCase();
    testCase.setId(testCaseId);

    ExecutionDetails executionDetails = new ExecutionDetails();
    executionDetails.setId(123);
    executionDetails.setAtid("atid123");
    executionDetails.setAtidHost("atidHost123");
    executionDetails.setTesterId(123);
    executionDetails.setSpoofCLI("spoofCLI123");
    executionDetails.setTargetCLI("targetCLI123");

    String provider = "Nectar";

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateTestCase(testCase, executionDetails, provider);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("eid", executionDetails.getId());
    verify(mockedQuery, times(1)).setParameter("atid", executionDetails.getAtid());
    verify(mockedQuery, times(1)).setParameter("atidHost", executionDetails.getAtidHost());
    verify(mockedQuery, times(1)).setParameter("provider", provider);
    verify(mockedQuery, times(1)).setParameter("testerId", executionDetails.getTesterId());
    verify(mockedQuery, times(1)).setParameter("spoofCLI", executionDetails.getSpoofCLI());
    verify(mockedQuery, times(1)).setParameter("targetCLI", executionDetails.getTargetCLI());
    verify(mockedQuery, times(1)).setParameter("id", testCase.getId());
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testUpdateStatus() {
    UUID id = UUID.randomUUID();
    String testStatus = OrchestrationStatusEnum.NEW.toString();

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateStatus(id, testStatus);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", id);
    verify(mockedQuery, times(1)).setParameter("status", testStatus);
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testUpdateNotes() {
    UUID id = UUID.randomUUID();
    String notes = "Cancelled";

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateNotes(id, notes);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", id);
    verify(mockedQuery, times(1)).setParameter("notes", notes);
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testUpdateConnectorData() {
    UUID id = UUID.randomUUID();
    String connectorData =
        "{state: state1, cli: cli1, callerId: callerId1, executionId: executionId1, host: host1}";

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateConnectorData(id, connectorData);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", id);
    verify(mockedQuery, times(1)).setParameter("connectorData", connectorData);
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testUpdateRunning() {
    UUID id = UUID.randomUUID();
    String connectorData =
        "{state: state1, cli: cli1, callerId: callerId1, executionId: executionId1, host: host1}";
    Timestamp startTime = new Timestamp(System.currentTimeMillis());

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateRunning(id, connectorData, startTime);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", id);
    verify(mockedQuery, times(1)).setParameter("connectorData", connectorData);
    verify(mockedQuery, times(1)).setParameter("startTime", startTime);
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testUpdateTestCompleteExecuted() {
    UUID id = UUID.randomUUID();
    String connectorData =
        "{state: state1, cli: cli1, callerId: callerId1, executionId: executionId1, host: host1}";
    String testOutcome = TestOutcomeEnum.PASSED.toString();
    String notes = "";
    Timestamp startTime = new Timestamp(System.currentTimeMillis());
    Duration duration = Duration.between(startTime.toLocalDateTime(), LocalDateTime.now());
    long durationInMillis = duration.toMillis();

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateTestCompleteExecuted(
        id, connectorData, testOutcome, notes, durationInMillis);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", id);
    verify(mockedQuery, times(1)).setParameter("connectorData", connectorData);
    verify(mockedQuery, times(1)).setParameter("testOutcome", testOutcome);
    verify(mockedQuery, times(1)).setParameter("notes", notes);
    verify(mockedQuery, times(1)).setParameter("duration", durationInMillis);
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testUpdateFailed() {
    UUID id = UUID.randomUUID();
    String testStatus = OrchestrationStatusEnum.NEW.toString();
    String testOutcome = TestOutcomeEnum.PASSED.toString();
    String notes = "";
    Timestamp startTime = new Timestamp(System.currentTimeMillis());

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateFailed(id, testStatus, testOutcome, notes, startTime);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", id);
    verify(mockedQuery, times(1)).setParameter("status", testStatus);
    verify(mockedQuery, times(1)).setParameter("outcome", testOutcome);
    verify(mockedQuery, times(1)).setParameter("notes", notes);
    verify(mockedQuery, times(1)).setParameter("startTime", startTime);
    verify(mockedQuery, times(1)).executeUpdate();
  }

  @Test
  void testIncrementStartAttempts() {
    UUID id = UUID.randomUUID();

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.incrementStartAttempts(id);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery).setParameter("id", id);
    verify(mockedQuery).executeUpdate();
  }

  @Test
  void testUpdateNectarExecuted() {
    UUID id = UUID.randomUUID();
    String orchestrationStatus = OrchestrationStatusEnum.EXECUTED.toString();
    String testOutcome = TestOutcomeEnum.PASSED.toString();
    String notes = "";
    Timestamp startTime = new Timestamp(System.currentTimeMillis());
    Duration duration = Duration.between(startTime.toLocalDateTime(), LocalDateTime.now());
    long durationInMillis = duration.toMillis();

    Query mockedQuery = mock(Query.class);
    when(entityManager.createNativeQuery(anyString())).thenReturn(mockedQuery);
    when(mockedQuery.setParameter(anyString(), any())).thenReturn(mockedQuery);

    testCaseOperationsService.updateNectarExecuted(
        id, orchestrationStatus, testOutcome, notes, durationInMillis, startTime);

    verify(entityManager, times(1)).createNativeQuery(anyString());
    verify(mockedQuery, times(1)).setParameter("id", id);
    verify(mockedQuery, times(1)).setParameter("orchestrationStatus", orchestrationStatus);
    verify(mockedQuery, times(1)).setParameter("testOutcome", testOutcome);
    verify(mockedQuery, times(1)).setParameter("notes", notes);
    verify(mockedQuery, times(1)).setParameter("duration", durationInMillis);
    verify(mockedQuery, times(1)).setParameter("startTime", startTime);
    verify(mockedQuery, times(1)).executeUpdate();
  }
}
