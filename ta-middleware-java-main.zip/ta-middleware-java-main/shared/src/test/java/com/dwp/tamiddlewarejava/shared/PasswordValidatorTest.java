package com.dwp.tamiddlewarejava.shared;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import com.dwp.tamiddlewarejava.shared.utils.PasswordUtils;

class PasswordValidatorTest {

  @Test
  void passwordMeetsAllRequirements() {
    String validPassword = "Valid$Password123";
    assertTrue(
        PasswordUtils.passwordDWPRequirementsMet(validPassword),
        "Password should meet all requirements.");
  }

  @Test
  void passwordIsTooShort() {
    String shortPassword = "Sho$1";
    Exception exception =
        assertThrows(
            IllegalArgumentException.class,
            () -> PasswordUtils.passwordDWPRequirementsMet(shortPassword),
            "Short password should throw an exception.");
    assertTrue(
        exception.getMessage().contains("The new password should be a minimum of 12 characters"),
        "Exception message should indicate the password is too short.");
  }

  @Test
  void passwordMissingUppercaseLetter() {
    String noUppercasePassword = "valid$password123";
    Exception exception =
        assertThrows(
            IllegalArgumentException.class,
            () -> PasswordUtils.passwordDWPRequirementsMet(noUppercasePassword),
            "Password without uppercase letter should throw an exception.");
    assertTrue(
        exception.getMessage().contains("No upper case character"),
        "Exception message should indicate no uppercase character is present.");
  }

  @Test
  void passwordMissingLowercaseLetter() {
    String noLowercasePassword = "INVALID$PASSWORD123";
    Exception exception =
        assertThrows(
            IllegalArgumentException.class,
            () -> PasswordUtils.passwordDWPRequirementsMet(noLowercasePassword),
            "Password without lowercase letter should throw an exception.");
    assertTrue(
        exception.getMessage().contains("No lower case character"),
        "Exception message should indicate no lowercase character is present.");
  }

  @Test
  void passwordMissingNumber() {
    String noNumberPassword = "Valid$Password";
    Exception exception =
        assertThrows(
            IllegalArgumentException.class,
            () -> PasswordUtils.passwordDWPRequirementsMet(noNumberPassword),
            "Password without a number should throw an exception.");
    assertTrue(
        exception.getMessage().contains("No number present"),
        "Exception message should indicate no number is present.");
  }

  @Test
  void passwordMissingSpecialCharacter() {
    String noSpecialCharPassword = "ValidPassword123";
    Exception exception =
        assertThrows(
            IllegalArgumentException.class,
            () -> PasswordUtils.passwordDWPRequirementsMet(noSpecialCharPassword),
            "Password without a special character should throw an exception.");
    assertTrue(
        exception.getMessage().contains("No special character"),
        "Exception message should indicate no special character is present.");
  }
}
