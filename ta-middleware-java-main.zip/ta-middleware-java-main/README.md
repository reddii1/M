## Test Automation Middleware

The Test Automation Middleware is indended for use in allowing multiple 3rd party Test Providers to comminicate with one another and for enabling the output of said tests to be available to view in a User Interface..

## Project Structure
This project is organized into multiple Maven modules, each serving a distinct role within the larger application ecosystem. The typical structure includes:

1. ta-middleware-java: The root module that manages common configurations and dependencies for child modules.

2. shared: A module for shared utilities, constants, and common functionality used across other modules.

3. frontend: Contains the UI Vue Application for the Middleware.

4. api-connector: The module that handles requests made via the frontend, such as User and Host CRUD operations, and is also responsible for handling the initial Test Execution request made from the Zephyr Test Execution service.

5. nectar-connector: The module that exposes interfaces with the Nectar Test Provider client, handling HTTP requests, responses and processing of test results.

6. test-complete-connector: The module that interfaces with the Test Complete Test Provider client, handling HTTP requests, responses and processing of test results.

7. zephyr-connector: The module that interfaces with the Zephyr Test Execution client, handling HTTP requests, responses and processing of initial test cases inserted via the api-connector 'execute' endpoint.

## Getting Started

1. Prerequisites

Ensure you have the following installed:

JDK v17
Maven v3.9.6
Node v18.18.2
npm v9.8.1

2. Building the Project
To build the entire project and its modules, navigate to the root directory and run:
```zsh
mvn clean install
```

This command compiles all modules, runs tests, and packages the application.

## Running API Connector against a local Postgres database
The following steps can be followed to get the `api-connector` module up and running against a local Postgres database.

The easiest way to do this is use the `postgres` Docker image and run an instance locally. Update the application.properties file for the api-connector to use the following environment variables:

postgres.host=localhost:5432
postgres.database=test_orchestration_java
host.encryption.key= *random encryption string for development purposes*
spring.datasource.username=postgres
spring.datasource.password=password


1. Launch the postgres database Docker container, located in the 'development' directory.
```zsh
docker run --name some-postgres -e POSTGRES_PASSWORD=password -p 5432:5432 -d postgres
```

2. Provision the database
```zsh
psql -c "CREATE DATABASE test_orchestration_java" -h 127.0.0.1 -p 5432 -U postgres
psql -f ./ta-middleware-java/development/test_orchestration_java.sql -h 127.0.0.1 -p 5432 -U postgres -d test_orchestration_java
```
**n.b.** You will be prompted for a password - this is just `'password'` (as we passed to the Docker container)

3. Start the api-connector application

4. Make a test invocation to the database from the api-connector
```zsh
curl http://localhost:8080/api/status
```

Expected output:
```zsh
{
    "status": "Ok"
}
```
