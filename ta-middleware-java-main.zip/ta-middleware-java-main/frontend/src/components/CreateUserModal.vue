<template>
  <button
    class="btn bg-success rounded text-white disabled:opacity-50 p-2 w-60 border-none"
    @click="toggleCreateUserModal"
  >
    <font-awesome-icon icon="fa-solid fa-user-plus" class="pr-2" />
    Create User
  </button>

  <div v-if="userModalOpen" class="UserModalContainer">
    <form class="modal-box" @submit="createUser">
      <button
        class="btn btn-sm btn-circle absolute right-2 top-2"
        @click="toggleCreateUserModal"
      >
        ✕
      </button>
      <h3 class="font-bold text-white text-lg mb-4">Create User</h3>

      <div class="mb-2">
        <label class="block text-white font-bold mb-2 text-left" for="username"
          >Username</label
        >
        <input
          type="text"
          name="username"
          id="username"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="username"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label
          class="block text-white font-bold mb-2 text-left"
          for="firstname"
          >First Name</label
        >
        <input
          type="text"
          name="firstname"
          id="firstname"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="firstName"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label class="block text-white font-bold mb-2 text-left" for="lastname"
          >Last Name</label
        >
        <input
          type="text"
          name="lastname"
          id="lastname"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="lastName"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label class="block text-white font-bold mb-2 text-left" for="role"
          >Role</label
        >
        <select
          class="select select-sm w-full role-select text-black"
          :disabled="createInProgress"
          name="role"
          v-model="role"
          required
        >
          <option v-for="option in ROLES" :value="option" :key="option">
            {{ option }}
          </option>
        </select>
      </div>

      <div class="mb-2">
        <label class="block text-white font-bold mb-2 text-left" for="team"
          >Team</label
        >
        <input
          type="text"
          name="team"
          id="team"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="team"
          :disabled="createInProgress"
        />
      </div>

      <div class="mx-0"></div>

      <div class="modal-action">
        <span
          class="text-base font-bold text-error-content mx-auto inline-block align-middle"
          id="error"
          v-html="errorMsg"
        />
        <span
          class="text-base font-bold text-success-content mx-auto inline-block align-middle"
          id="success"
          v-html="successMsg"
        />

        <button
          type="submit"
          class="bg-success rounded font-bold text-white disabled:opacity-50 w-48 px-4 py-2 rounded"
          :disabled="createInProgress"
        >
          Create
        </button>
      </div>
    </form>
  </div>
</template>

<script>
const config = {
  headers: {
    "Content-Type": "application/json",
  },
  responseType: "json",
};

export default {
  name: "CreateUserModal",
  emits: ["reloadUsers"],
  props: {
    ROLES: {
      type: Array,
      required: true,
    },
  },
  data: () => ({
    createInProgress: false,
    successMsg: null,
    errorMsg: null,
    username: "",
    firstName: "",
    lastName: "",
    role: "",
    team: "",
    userModalOpen: false,
  }),
  watch: {
    userModalOpen() {
      if (this.userModalOpen) {
        //when modal opens
        this.errorMsg = null;
        this.successMsg = null;
        this.createInProgress = false;
      }
    },
  },
  methods: {
    async createUser(event) {
      event.preventDefault();
      this.errorMsg = null;
      this.successMsg = null;
      this.createInProgress = true;

      const [name] = this.username.split(/(?<=^.+)@(?=[^@]+$)/); //Strip out @ email domain

      config.headers.Authorization = "Bearer " + this.$store.getters.rawJWT; //Make sure we have latest JWT token
      try {
        const { data } = await this.axios.post(
          `/api/users`,
          {
            username: name,
            role: this.role,
            suspendedUser: false, //Always false presently. Potential future feature if requested
            team: this.team,
            firstName: this.firstName,
            lastName: this.lastName,
            loggedInUser: sessionStorage.getItem("username"),
          },
          config
        );

        this.successMsg = `User <pre>${data.username}</pre> created with password: <pre>${data.password}</pre>`;

        this.$emit("reloadUsers");
      } catch (e) {
        console.error(e);
        if (e.response?.status) this.errorMsg = e.response?.data?.message;
        else this.errorMsg = e.message;
        this.createInProgress = false;
      }
    },
    toggleCreateUserModal(event) {
      event.preventDefault();
      this.userModalOpen = !this.userModalOpen;
    },
  },
};
</script>

<style>
.role-select {
  background-color: rgb(226 232 240);
}
.UserModalContainer {
  position: fixed;
  inset: 0px;
  margin: 0px;
  display: grid;
  height: 100%;
  max-height: none;
  width: 100%;
  max-width: none;
  justify-items: center;
  padding: 0px;
  overscroll-behavior: contain;
  z-index: 999;
  background-color: transparent;
  transition-duration: 200ms;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-property: transform, opacity, visibility;
  overflow-y: hidden;
  visibility: visible;
  opacity: 1;
}
:where(.UserModalContainer) {
  align-items: center;
}
</style>
