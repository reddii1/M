<template>
  <button @click="toggleAccessibilityStatement">Accessibility Statement</button>
  <div
    v-if="accessibilityStatementModalOpen"
    class="accessibilityStatementModalContainer"
  >
    <div
      class="modal-box modalBoxAdjustment"
      v-click-away="onAccessibilityStatementClickAway"
    >
      <button
        class="btn btn-sm btn-circle absolute right-2 top-2"
        @click="toggleAccessibilityStatement"
      >
        ✕
      </button>
      <h3 class="font-bold text-white text-lg mb-4">
        Accessibility Statement for Test Orchestration Middleware
      </h3>
      <div class="text-left">
        This accessibility statement applies to the Test Orchestration
        Middleware web application. This application orchestrates automated test
        execution and reporting between Zephyr Enterprise application and
        automation tools including Nectar CXA and TestComplete on behalf of
        Department for Work and Pensions.
        <br /><br />
        This website is run by the Department for Work and Pensions. We want as
        many people as possible to be able to use this website. For example,
        that means you should be able to:
        <br /><br />
        <li>Change colours, contrast levels and fonts.</li>
        <li>Zoom in up to 400% without the text spilling off the screen.</li>
        <li>Navigate most of the website using just a keyboard.</li>
        <li>Navigate most of the website using speech recognition software.</li>
        <li>Listen to most of the website using a screen reader.</li>
        <li>
          We&#39;ve also made the website text as simple as possible to
          understand.
        </li>
        <br /><br />
        <h2 class="block text-white font-bold mb-2 text-left">
          Reporting accessibility problems with this website
        </h2>
        We&#39;re always looking to improve the accessibility of this website.
        If you find any problems not listed on this page or think we&#39;re not
        meeting accessibility requirements, contact the Department for Work and
        Pensions Accessibility Team.
        <br /><br />
        <h2 class="block text-white font-bold mb-2 text-left">
          Enforcement procedure
        </h2>

        The Equality and Human Rights Commission (EHRC) is responsible for
        enforcing the Public Sector Bodies (Websites and Mobile Applications)
        (No. 2) Accessibility Regulations 2018 (the ‘accessibility
        regulations&#39;). If you&#39;re not happy with the response to your
        complaint, contact the Equality Advisory and Support Service (EASS).
        <br /><br />
        <h2 class="block text-white font-bold mb-2 text-left">
          Technical information about this website&#39;s accessibility
        </h2>

        Department for Work and Pensions is committed to making its website
        accessible, in accordance with the Public Sector Bodies (Websites and
        Mobile Applications) (No. 2) Accessibility Regulations 2018.
        <br /><br />
        <h2 class="block text-white font-bold mb-2 text-left">
          Compliance status
        </h2>

        This website is fully compliant with the Web Content Accessibility
        Guidelines version 2.1 AA standard.
        <br /><br />
        <h2 class="block text-white font-bold mb-2 text-left">
          Preparation of this accessibility statement
        </h2>

        This statement was prepared on 11/08/2023 It was last reviewed on
        11/08/2023. This website was last tested on 11/08/2023. The test was
        carried out by Department for Work and Pensions.
      </div>
    </div>
  </div>
</template>

<script>
import { directive } from "vue3-click-away";

export default {
  name: "AccessibilityStatementPopup",
  data: () => ({
    accessibilityStatementModalOpen: false,
  }),
  directives: {
    ClickAway: directive,
  },
  methods: {
    toggleAccessibilityStatement(e) {
      e.preventDefault();
      this.accessibilityStatementModalOpen =
        !this.accessibilityStatementModalOpen;
    },
    onAccessibilityStatementClickAway(e) {
      e.preventDefault();
      this.accessibilityStatementModalOpen = false;
    },
  },
};
</script>

<style>
.modalBoxAdjustment {
  max-width: 50vw;
}
.accessibilityStatementModalContainer {
  position: fixed;
  inset: 0px;
  margin: 0px;
  display: grid;
  height: 100%;
  max-height: none;
  width: 100%;
  max-width: none;
  justify-items: center;
  padding: 0px;
  overscroll-behavior: contain;
  z-index: 999;
  background-color: transparent;
  transition-duration: 200ms;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-property: transform, opacity, visibility;
  overflow-y: hidden;
  visibility: visible;
  opacity: 1;
}
:where(.accessibilityStatementModalContainer) {
  align-items: center;
}
</style>
