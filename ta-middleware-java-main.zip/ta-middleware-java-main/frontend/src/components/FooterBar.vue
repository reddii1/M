<template>
  <footer>
    <AccessibilityStatementPopup />
  </footer>
</template>

<script>
import AccessibilityStatementPopup from "./AccessibilityStatementPopup.vue";

export default {
  components: { AccessibilityStatementPopup },
  name: "FooterBar",
  data() {},
  methods: {},
};
</script>
