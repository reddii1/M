<template>
    <div class="dropdown dropdown-end">
      <label tabindex="2">
        <div
          :class="buttonClasses"
          role="button"
          @click="toggleHostActionsDropdown"
        >
          <a>
            <font-awesome-icon
              v-if="!hostActionsDropdownActive"
              icon="fa-solid fa-chevron-down"
              class="pr-2"
            />
            <font-awesome-icon
              v-else
              icon="fa-solid fa-chevron-up"
              class="pr-2"
            />
            Host Actions
          </a>
        </div>
      </label>
  
      <ul
        v-if="hostActionsDropdownActive"
        v-click-away="onHostActionsDropdownClickAway"
        class="menu zindexadjustment dropdown-content p-2 shadow bg-base-100 w-64 border-2 border-gray-50 mt-1 text-white font-normal"
      >
        <li class="rounded">
          <div @mousedown="() => $emit('editMode', 'zephyrhostid')">
            <font-awesome-icon icon="fa-solid fa-server" />Edit Zephyr Host ID
          </div>
        </li>

        <li class="rounded">
          <div @mousedown="() => $emit('editMode', 'hostname')">
            <font-awesome-icon icon="fa-solid fa-server" />Edit Host Name
          </div>
        </li>
  
        <li class="rounded">
          <div @mousedown="() => $emit('editMode', 'hoststatus')">
            <font-awesome-icon icon="fa-solid fa-gear" />Edit Host Status
          </div>
        </li>
  
        <li class="rounded">
          <div @mousedown="() => $emit('editMode', 'projectsroot')">
            <font-awesome-icon icon="fa-solid fa-desktop" />Edit Project Root
          </div>
        </li>
  
        <li class="rounded">
          <div @mousedown="$emit('editMode', 'teamname')">
            <font-awesome-icon icon="fa-solid fa-people-group" />Edit Team Name
          </div>
        </li>
  
        <li class="rounded">
          <div @mousedown="$emit('editMode', 'testprovider')">
            <font-awesome-icon icon="fa-solid fa-people-group" />Edit Test
            Provider
          </div>
        </li>
  
        <li class="rounded">
          <div @mousedown="$emit('editMode', 'username')">
            <font-awesome-icon icon="fa-solid fa-people-group" />Edit Username
          </div>
        </li>
  
        <li class="rounded">
          <div @mousedown="$emit('editMode', 'password')">
            <font-awesome-icon icon="fa-solid fa-people-group" />Edit Password
          </div>
        </li>
  
        <li class="rounded" @mousedown="$emit('deleteHost', hostname, hostId)">
          <div><font-awesome-icon icon="fa-solid fa-xmark" />Delete Host</div>
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  import { mapGetters } from "vuex";
  import { directive } from "vue3-click-away";
  
  export default {
    name: "HostActionsDropdown",
    props: {
      buttonClasses: {
        type: String,
        required: true,
      },
      hostname: {
        type: String,
        required: true,
      },
      hostId: {
        type: Number,
        required: false,
      },
    },
    emits: ["editMode", "deleteHost"],
    data() {
      return {
        hostActionsDropdownActive: false,
      };
    },
    computed: {
      ...mapGetters(["decodedJWT"]),
    },
    directives: {
      ClickAway: directive,
    },
    methods: {
      toggleHostActionsDropdown() {
        this.hostActionsDropdownActive = !this.hostActionsDropdownActive;
      },
      onHostActionsDropdownClickAway(event) {
        event.preventDefault();
        this.hostActionsDropdownActive = false;
      },
    },
  };
  </script>
  
  <style>
  .zindexadjustment {
    z-index: 1000;
  }
  </style>  
