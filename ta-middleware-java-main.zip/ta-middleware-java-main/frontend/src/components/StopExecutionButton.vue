<template>
    <div>
        <form class="w-full max-w-5xl">
            <div class="flex mb-2">
                <div class="w-full md:w-1/6 pr-3 mb-2 md:mb-0">
                    <label class="block uppercase tracking-wide text-white-700 text-xs font-bold mb-2" for="tcid">
                        TCID
                    </label>
                    <input
                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                        name="tcid" id="tcid" v-model="tcid" type="text" placeholder="" v-on:keypress="allowNumbersOnly" />
                </div>
                <div class="w-full md:w-1/6 pr-3 mb-2 md:mb-0">
                    <label class="block uppercase tracking-wide text-white-700 text-xs font-bold mb-2" for="rid">
                        RID
                    </label>
                    <input
                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                        name="rid" id="rid" v-model="rid" type="text" placeholder="" v-on:keypress="allowNumbersOnly" />
                </div>
                <div class="w-full md:w-1/6 pr-3 mb-2 md:mb-0">
                    <label class="block uppercase tracking-wide text-white-700 text-xs font-bold mb-2" for="cid">
                        CID
                    </label>
                    <input
                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                        name="cid" id="cid" v-model="cid" type="text" placeholder="" v-on:keypress="allowNumbersOnly" />
                </div>
                <div class="w-full md:w-1/6 pr-3 mb-2 md:mb-0">
                    <label class="block uppercase tracking-wide text-white-700 text-xs font-bold mb-2" for="cpid">
                        CPID
                    </label>
                    <input
                        class="appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                        name="cpid" id="cpid" v-model="cpid" type="text" placeholder="" v-on:keypress="allowNumbersOnly" />
                </div>
                <div class="w-full md:w-1/6 pr-3 mb-2 md:mb-0">
                    <div class="py-4 px-4">
                        <button
                            class="shadow bg-red-500 hover:bg-red-400 focus:shadow-outline focus:outline-none text-white text-sm font-bold py-2 px-4 rounded cursor-pointer whitespace-nowrap"
                            type="button" :disabled="(tcid === '' && rid === '' && cid === '' && cpid === '') ||
                                stopExecutionInitiated === true
                                " @click="clickStopExecution">
                            <font-awesome-icon icon="fa-solid fa-circle-stop" class="pr-2" />
                            Stop Execution
                        </button>
                    </div>
                </div>
                <div v-if="stopExecutionInitiated === true" class="w-full md:w-1/6 pr-3 mb-2 md:mb-0">
                    <div class="py-4 px-4">
                        <button
                            class="shadow bg-red-500 hover:bg-red-400 focus:shadow-outline focus:outline-none text-white text-sm font-bold py-2 px-4 rounded cursor-pointer whitespace-nowrap"
                            type="button" @click="cancelStopExecution">
                            <font-awesome-icon icon="fa-solid fa-ban" class="pr-2" />
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
            <div v-if="(errorMsg || successMsg) !== null" class="mb-2">
                <span class="text-white font-bold text-error-content mx-auto inline-block align-middle" id="error"
                    v-html="errorMsg" />
                <span class="text-white font-bold text-success-content mx-auto inline-block align-middle" id="success"
                    v-html="successMsg" />
            </div>
        </form>
    </div>
</template>

<script>
const config = {
    headers: {
        "Content-Type": "application/json",
    },
    responseType: "json",
};

export default {
    name: "StopExecutionButton",
    emits: ["reloadTestCases"],
    data: () => ({
        successMsg: null,
        errorMsg: null,
        tcid: "",
        rid: "",
        cid: "",
        cpid: "",
        stopExecutionInitiated: false,
        cancelStopExecutionInitiated: false,
    }),
    methods: {
        async clickStopExecution(event) {
            event.preventDefault();
            this.errorMsg = null;
            this.successMsg = null;
            this.cancelStopExecutionInitiated = false;
            this.stopExecutionInitiated = true;
            config.headers.Authorization = "Bearer " + this.$store.getters.rawJWT; //Make sure we have latest JWT token

            let stopExecutionInterval = setInterval(async () => {
                if (this.cancelStopExecutionInitiated === true) {
                    this.stopExecutionInitiated = false;
                    clearInterval(stopExecutionInterval);
                    this.successMsg = 'Stop execution cancelled';
                    setTimeout(() => {
                        this.errorMsg = null;
                        this.successMsg = null;
                    }, 2000);
                } else {
                    try {
                        await this.axios.post(
                            `/api/stopExecution`,
                            {
                                tcid: this.tcid,
                                rid: this.rid,
                                cid: this.cid,
                                cpid: this.cpid,
                            },
                            config
                        );
                        this.successMsg = "Stopping execution for specified fields";
                        this.$emit("reloadTestCases");
                    } catch (e) {
                        console.error(e);
                        this.successMsg = null;
                        if (e.response?.status) this.errorMsg = e.response?.data?.message;
                        else this.errorMsg = e.message;
                        clearInterval(stopExecutionInterval);
                        this.stopExecutionInitiated = false;
                        setTimeout(() => {
                            this.errorMsg = null;
                            this.successMsg = null;
                        }, 2000);
                    }
                }
            }, 1000);
        },
        allowNumbersOnly(event) {
            event = event ? event : window.event;
            var charCode = event.which ? event.which : event.keyCode;
            if (
                charCode > 31 &&
                (charCode < 48 || charCode > 57) &&
                charCode !== 46
            ) {
                event.preventDefault();
            } else {
                return true;
            }
        },
        cancelStopExecution(event) {
            event.preventDefault();
            this.cancelStopExecutionInitiated = true;
        },
    },
};
</script>

<style>
button:disabled {
    background-color: grey;
}

#error {
    color: #ef4544;
}

#success {
    color: #00e600;
}
</style>
