<template>
  <button
    class="btn bg-success rounded text-white disabled:opacity-50 p-2 w-60 border-none"
    @click="toggleCreateHostModal"
  >
    <font-awesome-icon icon="fa-solid fa-plus" class="pr-2" />
    Create Host
  </button>

  <div v-if="hostModalOpen" class="HostModalContainer">
    <form class="modal-box" @submit="createHost">
      <button
        class="btn btn-sm btn-circle absolute right-2 top-2"
        @click="toggleCreateHostModal"
      >
        ✕
      </button>
      <h3 class="font-bold text-white text-lg mb-4">Create Host</h3>

      <div class="mb-2">
        <label class="block text-white font-bold mb-2 text-left" for="zephyrHostId"
          >Zephyr Host ID</label
        >
        <input
          type="text"
          name="zephyrHostId"
          id="zephyrHostId"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="zephyrHostId"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label class="block text-white font-bold mb-2 text-left" for="hostName"
          >Host Name</label
        >
        <input
          type="text"
          name="hostName"
          id="hostName"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="hostName"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label
          class="block text-white font-bold mb-2 text-left"
          for="projectsRoot"
          >Project Root</label
        >
        <input
          type="text"
          name="projectsRoot"
          id="projectsRoot"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="projectsRoot"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label class="block text-white font-bold mb-2 text-left" for="teamName"
          >Team</label
        >
        <input
          type="text"
          name="teamName"
          id="teamName"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="teamName"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label
          class="block text-base font-bold mb-2 text-left"
          for="testProvider"
          >Test Provider</label
        >
        <select
          class="select select-sm w-full role-select text-black"
          :disabled="createInProgress"
          name="testProvider"
          v-model="testProvider"
          required
        >
          <option
            v-for="option in testProviders"
            :value="option"
            :key="option"
          >
            {{ option }}
          </option>
        </select>
      </div>

      <div class="mb-2">
        <label class="block text-base font-bold mb-2 text-left" for="username"
          >Username</label
        >
        <input
          type="text"
          name="username"
          id="username"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="username"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="mb-2">
        <label class="block text-base font-bold mb-2 text-left" for="password"
          >Password</label
        >
        <input
          type="password"
          name="password"
          id="password"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
          v-model="password"
          :disabled="createInProgress"
          required
        />
      </div>

      <div class="modal-action">
        <span
          class="text-white font-bold text-error-content mx-auto inline-block align-middle"
          id="error"
          v-html="errorMsg"
        />
        <span
          class="text-white font-bold text-success-content mx-auto inline-block align-middle"
          id="success"
          v-html="successMsg"
        />

        <button
          type="submit"
          class="bg-success rounded font-bold text-white disabled:opacity-50 w-48 px-4 py-2 rounded"
          :disabled="createInProgress"
        >
          Create
        </button>
      </div>
    </form>
  </div>
</template>

<script>
const config = {
  headers: {
    "Content-Type": "application/json",
  },
  responseType: "json",
};

export default {
  name: "CreateHostModal",
  emits: ["reloadHosts"],
  props: {
    testProviders: {
      type: Array,
      required: true,
    },
  },
  data: () => ({
    createInProgress: false,
    successMsg: null,
    errorMsg: null,
    zephyrHostId: "",
    hostName: "",
    projectsRoot: "",
    teamName: "",
    testProvider: "",
    username: "",
    password: "",
    hostModalOpen: false,
  }),
  watch: {
    hostModalOpen() {
      if (this.hostModalOpen) {
        //when modal opens
        this.errorMsg = null;
        this.successMsg = null;
        this.createInProgress = false;
      }
    },
  },
  methods: {
    async createHost(event) {
      event.preventDefault();
      this.errorMsg = null;
      this.successMsg = null;
      this.createInProgress = true;

      const host = this.hostName.trim(); //Trim whitespace

      config.headers.Authorization = "Bearer " + this.$store.getters.rawJWT; //Make sure we have latest JWT token
      try {
        await this.axios.post(
          `/api/hosts/${this.zephyrHostId}`,
          {
            zephyrHostId: this.zephyrHostId,
            hostName: host,
            hostStatus: "Available", //Default status to Available
            projectsRoot: this.projectsRoot,
            teamName: this.teamName,
            testProvider: this.testProvider,
            username: this.username,
            password: this.password,
            loggedInUser: sessionStorage.getItem("username"),
          },
          config
        );

        this.successMsg = `Host <pre>${host}</pre> created`;

        setTimeout(() => {
          this.hostModalOpen = false;
        }, 1500);

        this.$emit("reloadHosts");
      } catch (e) {
        console.error(e);
        if (e.response?.status) this.errorMsg = e.response?.data?.message;
        else this.errorMsg = e.message;
        this.createInProgress = false;
      }
    },
    toggleCreateHostModal(event) {
      event.preventDefault();
      this.hostModalOpen = !this.hostModalOpen;
    },
  },
};
</script>

<style>
.HostModalContainer {
  position: fixed;
  inset: 0px;
  margin: 0px;
  display: grid;
  height: 100%;
  max-height: none;
  width: 100%;
  max-width: none;
  justify-items: center;
  padding: 0px;
  overscroll-behavior: contain;
  z-index: 999;
  background-color: transparent;
  transition-duration: 200ms;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-property: transform, opacity, visibility;
  overflow-y: hidden;
  visibility: visible;
  opacity: 1;
}
:where(.HostModalContainer) {
  align-items: center;
}
</style>
