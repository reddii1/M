<template>
  <header
    class="flex py-2 pl-2 pr-2 mb-3 justify-between fixed items-center top-0 navbar bg-accent text-primary-content z-50"
  >
    <div class="navbar-start">
      <label aria-label="Navbar buttons" tabindex="0" v-if="$slots.default">
        <slot></slot>
      </label>
    </div>

    <div class="navbar-center lg:flex">
      <div class="flex items-center" role="banner" aria-hidden="true">
        <img
          srcset="wp-digital-logo-white-outline.png 10x"
          class="inline pr-1"
          alt="DWP logo"
          aria-hidden="true"
        />
        <h1 class="text-3xl text-slate-200">{{ HeaderTitle }}</h1>
      </div>
    </div>

    <div class="navbar-end">
      <UserMenuDropdown
        buttonClasses="hover:bg-secondary-focus bg-secondary rounded 
                font-bold text-white disabled:opacity-50 py-2 px-4 items-center justify-center flex w-60"
      />
    </div>
  </header>
</template>

<script>
import UserMenuDropdown from "./UserMenuDropdown";

export default {
  name: "HeaderBar",
  props: {
    PAGE_TITLE: {
      type: String,
      required: true,
    },
  },
  components: {
    UserMenuDropdown,
  },
  data: () => ({
    HeaderTitle: "Test Orchestration UI",
  }),
  created() {
    this.HeaderTitle = `Test Orchestration UI - ${this.PAGE_TITLE}`;
  },
};
</script>
