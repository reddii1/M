<script>
export default {
  props: {
    type: { type: String, required: true },
    itemName: { type: String, required: true },
    field: { type: String, required: true },
    options: { type: Array, required: false }, //really object[], but this is not TypeScript
    startingValue: { type: String, required: false, default: "" },
    itemId: { type: Number, required: true },
    itemRequired: { type: Boolean, required: false, default: false },
  },
  emits: ["save", "cancel"],
  data: function () {
    return {
      value: this.startingValue,
    };
  },
  computed: {
    formatDateTimeDisplay() {
      try {
        const d = this.$dayjs(this.value);

        return d.format("DD/MM/YY HH:mm:ss");
      } catch (e) {
        console.warn(e);
        return this.value;
      }
    }
  },
  methods: {
    formatDateTimeSave(event) {
    this.value = this.$moment.utc(event.target.value, "DD-MM-YY HH:mm:ss");
  },
  parseStringAsInteger(event) {
      this.value = parseInt(event.target.value);
    },
}
};
</script>

<template>
  <select
    id="user-role"
    aria-label="Select new user role"
    v-if="type == 'options'"
    :name="field"
    v-model="value"
  >
    <option
      v-for="option in options"
      v-bind:key="option?.id || option"
      v-bind:value="option?.value || option"
    >
      {{ option.name || option }}
    </option>
  </select>

  <select
    id="host-test-provider"
    aria-label="Select new test provider"
    v-if="type == 'testProviderOptions'"
    :name="field"
    v-model="value"
  >
    <option
      v-for="option in options"
      v-bind:key="option?.value || option"
      v-bind:value="option?.value || option"
    >
      {{ option.name || option }}
    </option>
  </select>

  <input v-else-if="type == 'freetext'" :name="field" v-model="value" />

  <input v-else-if="type == 'integer'" :name="field" v-model="value" @change="parseStringAsInteger"/>

  <input
    v-else-if="type == 'datetime'"
    :name="field"
    v-model="formatDateTimeDisplay"
    @change="formatDateTimeSave"
  />

  <button
    :disabled="this.value === '' && itemRequired === true"
    class="hover:bg-success bg-success rounded font-bold text-white disabled:opacity-50 px-1.5 py-0.5 rounded ml-1"
    type="submit"
    @click="$emit('save', itemName, field, this.value, itemId)"
  >
    <font-awesome-icon icon="fa-solid fa-floppy-disk" title="Save" />
  </button>

  <button
    class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 px-2 py-0.5 rounded ml-1"
    @click="$emit('cancel')"
  >
    <font-awesome-icon icon="fa-solid fa-xmark" title="Cancel" />
  </button>
</template>

<style>
.bg-success:hover {
  background-color: #008044;
}
</style>
