<script>
export default {
  props: {
    text: [String, Number, Boolean],
    jsonField: [String],
    type: String,
  },
  data() {
    return {
      showPassword: false,
    };
  },
  computed: {
    formatDateTime() {
      if (!this.text) {
        return "";
      }

      const d = this.$dayjs(this.text);
      if (d.isValid()) {
        return d.format("DD/MM/YY HH:mm:ss");
      } else {
        console.warn("Invalid date:", this.text);
        return "";
      }
    },
    formatDuration() {
      try {
        const d = this.$dayjs.duration(this.text);
        const wholeDays = Math.floor(d.asDays());
        return (
          (wholeDays ? wholeDays + " days" : "") + `${d.format("HH:mm:ss")}`
        );
      } catch (e) {
        console.warn(e);
        return this.text;
      }
    },
    JSONsummary() {
      try {
        const x = Object.keys(JSON.parse(this.text));
        return `[${x.length}]<div><sup>${x.join(", ")}</sup></div>`;
      } catch (e) {
        console.warn(e);
        return "Not valid JSON data";
      }
    },
    formatJSON() {
      try {
        return JSON.stringify(JSON.parse(this.text), null, 2);
      } catch (e) {
        console.warn(e);
        return this.text;
      }
    },
    formatJSONField() {
      try {
        return JSON.parse(this.text)[this.jsonField];
      } catch (e) {
        console.warn(e);
        return this.text;
      }
    },
    formatAsPassword() {
      try {
        let s = "";
        for (let i = 0; i <= this.text.length; i++) {
          s += "*";
        }
        return s;
      } catch (e) {
        console.warn(e);
        return this.text;
      }
    },
    buttonLabel() {
      return this.showPassword ? "Hide" : "Show";
    },
  },
  methods: {
    toggleShow() {
      this.showPassword = !this.showPassword;
    },
  },
};
</script>

<template>
  <td class="border border-slate-300 dark:border-slate-700 p-2">
    <div v-if="type == 'datetime'">
      <span>
        {{ formatDateTime }}
      </span>
    </div>
    <div v-else-if="type == 'pre'">
      <pre>{{ text }}</pre>
    </div>
    <div v-else-if="type == 'JSON'" class="overflow">
      <details>
        <summary class="cursor-pointer truncate" v-html="JSONsummary" />
        <pre>{{ formatJSON }}</pre>
      </details>
    </div>
    <div v-else-if="type == 'JSONField'">
      {{ formatJSONField }}
    </div>
    <div v-else-if="type == 'duration'">
      {{ formatDuration }}
    </div>
    <div v-else-if="type == 'text'">
      {{ text }}
    </div>
    <div v-else-if="type == 'password'">
      <span v-if="!showPassword">{{ formatAsPassword }}</span>
      <span v-else>{{ text }}</span>
      <button aria-label="toggle password visibility button" class="px-2 py-1 ml-2" @click="toggleShow">
        <span class="icon is-right">
          <font-awesome-icon v-if="showPassword" :icon="['fas', 'eye-slash']" />
          <font-awesome-icon v-else :icon="['fas', 'eye']" />
        </span>
      </button>
    </div>
    <div v-else>
      <slot></slot>
    </div>
  </td>
</template>
