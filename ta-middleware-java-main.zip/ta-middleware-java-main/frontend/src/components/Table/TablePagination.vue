<template>
      <div class="flex justify-between pagerContainer">
        <label
          for="paginationRowNumber"
          class="block mb-2 text-sm font-medium text-white dark:text-white pagerLabel"
          >Number of Rows</label
        >
        <select
          @change="onChange($event)"
          id="paginationRowNumber"
          class="mb-2 bg-gray-50 mr-8 mt-2 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-medium p-2.5 dark:bg-gray-700 cursor-pointer dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
        >
          <option
            v-for="(option, index) in options"
            :key="index"
            :value="option.value"
          >
            {{ option.text }}
          </option>
        </select>
        <div class="inline-flex mt-3 xs:mt-0">
          <button
            @click="paginate('previous')"
            :disabled="this.start <= 0"
            class="flex items-center justify-center mr-2 px-3 h-8 text-sm font-medium text-black bg-slate-200 rounded-l hover:bg-slate-500 cursor-pointer dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
          >
            Prev
          </button>
          <button
            @click="paginate('next')"
            :disabled="this.ITEMS?.length < this.paginationRows"
            class="flex items-center justify-center mr-8 px-3 h-8 text-sm font-medium text-black bg-slate-200 border-0 border-l border-gray-700 rounded-r hover:bg-slate-500 cursor-pointer dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
          >
            Next
          </button>
        </div>
      </div>
  </template>
  
  <script>
  export default {
    name: "TablePagination",
    props: {
      ITEMS: {
        type: Array,
        required: true,
      },
      dropdownValues: {
        type: Array,
        required: true,
      },
      defaultRowCount: {
        type: Number,
        required: true,
      },
    },
    data: () => ({
      loaded: false,
      testCases: [],
      start: 0,
      limit: 0,
      paginationRows: 0,
      options: [],
    }),
    mounted: function () {
      this.options = this.generateOptions(this.dropdownValues);
      this.paginationRows = parseInt(this.defaultRowCount);
      this.limit = parseInt(this.paginationRows);
    },
    watch: {
      paginationRows: function () {
        this.limit = parseInt(this.paginationRows);
  
        if (this.limit != this.start && this.start > 0) {
          this.start = parseInt(this.paginationRows);
        }
        this.limit = this.start + parseInt(this.paginationRows);
  
        this.$emit("reloadItems", {
          startIndex: this.start,
          rowCount: this.limit,
        });
      },
    },
    methods: {
      paginate(direction) {
        if (direction === "next") {
          this.start += parseInt(this.paginationRows);
          this.limit = parseInt(this.paginationRows);
        } else if (direction === "previous") {
          this.limit = parseInt(this.paginationRows);
          this.start -= parseInt(this.paginationRows);
        }
        this.$emit("reloadItems", {
          startIndex: this.start,
          rowCount: this.limit,
        });
      },
      onChange(event) {
        this.start = 0;
        this.paginationRows = event.target.value;
      },
      generateOptions(array) {
        return array.map((value) => ({
          value: value,
          text: value,
        }));
      },
    },
  };
  </script>
  
  <style>
  .pagerContainer {
    float: right;
  }
  
  .pagerLabel {
    margin: auto;
    padding-right: 10px;
  }

  button:disabled {
    pointer-events: none;
  }
  </style>