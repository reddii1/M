<script>
import { defineComponent } from 'vue'

export default defineComponent({
    props: {
        text: String
    }
})
</script>

<template>
    <th class="border border-slate-300 dark:border-slate-600 font-semibold p-3 text-slate-900 dark:text-slate-200 text-left">{{ text }}</th>
</template>
<style>    
th {
    white-space: nowrap; 
}
</style>