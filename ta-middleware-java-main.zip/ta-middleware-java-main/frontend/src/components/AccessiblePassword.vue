
<template>
    <div class="relative">
        <input :type="passwordAccessible ? 'text' : 'password'" autocomplete="current-password" 
            id="password" v-model="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-black"
            v-bind="$attrs" />
        <span class="absolute text-primary top-2 right-3 cursor-pointer" @click="passwordAccessible = !passwordAccessible">
            <font-awesome-icon class="fa-icon-std-size" :icon="passwordAccessible ? 'fa-eye' : 'fa-eye-slash'" />
        </span>
    </div>
</template>
<script>

export default {
    name: 'AccessiblePassword',
    data() {
        return {
            passwordAccessible: false,
        };
    }
}
</script>

<style>
.fa-icon-std-size {
    width: 20px;
    padding-top: 4px;
    /* FA icon height is 16px. */
}
</style>