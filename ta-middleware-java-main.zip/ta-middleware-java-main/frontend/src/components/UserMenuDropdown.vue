<template>
  <div class="dropdown dropdown-end">
    <div class="flex">
      <div class="pr-3 mb-2 md:mb-0">
        <p class="text-white py-2">User : {{ decodedJWT?.sub || "Unknown User" }}</p>
      </div>
      <div class="pr-3 mb-2 md:mb-0">
        <button
        aria-description="Button providing access to User features"
        class="hover:bg-secondary-focus bg-secondary border-solid rounded font-bold text-white disabled:opacity-50 py-2 px-4 flexbuttonClasses"
        @click="toggleUserMenuDropdown"
        data-te-toggle="tooltip"
        data-te-placement="top"
        title="User Menu">
        <div>
            <span class="text-left block">
              <font-awesome-icon v-if="userMenuDropdownActive" icon="fa-solid fa-bars-staggered" />
              <font-awesome-icon v-else icon="fa-solid fa-bars"/>
            </span>
        </div>
      </button>
      </div>
    </div>
    <ul
      v-if="userMenuDropdownActive"
      v-click-away="onUserMenuDropdownClickAway"
      tabindex="0"
      class="menu dropdown-content p-2 shadow bg-base-100 w-80 border-2 border-gray-50 mt-1"
    >
      <li class="rounded">
        <a @click="openChangePasswordWindow">
          <font-awesome-icon icon="fa-solid fa-key" />Change Password
        </a>
      </li>

      <div
        class="text-error-content"
        v-if="decodedJWT?.role.includes('test_admin') || false"
      >
        <li class="rounded">
          <router-link to="/user-management">
            <font-awesome-icon icon="fa-solid fa-users-cog" />User Management
          </router-link>
        </li>
      </div>

      <div
        class="text-error-content"
        v-if="decodedJWT?.role.includes('test_admin') || false"
      >
        <li class="rounded">
          <router-link to="/view-audit-log">
            <font-awesome-icon icon="fa-solid fa-clipboard-user" />View Audit
            Log
          </router-link>
        </li>
      </div>

      <li class="rounded">
        <router-link to="/logout">
          <font-awesome-icon icon="fa-solid fa-right-from-bracket" />Logout
          <!-- <small title="Current session expiry time. Re-login to refresh.">
                          Expiry {{ this.$dayjs.unix(decodedJWT.exp).format('h:mm A YYYY-MM-DD') }}
                      </small> -->
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { directive } from "vue3-click-away";

export default {
  name: "UserMenuDropdown",
  props: ["buttonClasses"],
  data() {
    return {
      userMenuDropdownActive: false,
    };
  },
  computed: {
    ...mapGetters(["decodedJWT"]),
  },
  directives: {
    ClickAway: directive,
  },
  methods: {
    toggleUserMenuDropdown() {
      this.userMenuDropdownActive = !this.userMenuDropdownActive;
    },
    openChangePasswordWindow() {
      window.open("/change-password", "_blank");
    },
    onUserMenuDropdownClickAway(event) {
      event.preventDefault();
      this.userMenuDropdownActive = false;
    },
  },
};
</script>
