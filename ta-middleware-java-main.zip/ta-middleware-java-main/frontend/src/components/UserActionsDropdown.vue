<template>
  <div class="dropdown dropdown-end">
    <label tabindex="2">
      <div
        :class="buttonClasses"
        role="button"
        @click="toggleUserActionsDropdown"
      >
        <a>
          <font-awesome-icon
            v-if="!userActionsDropdownActive"
            icon="fa-solid fa-chevron-down"
            class="pr-2"
          />
          <font-awesome-icon
            v-else
            icon="fa-solid fa-chevron-up"
            class="pr-2"
          />
          User Actions
        </a>
      </div>
    </label>

    <ul
      v-if="userActionsDropdownActive"
      v-click-away="onUserActionsDropdownClickAway"
      class="menu zindexadjustment dropdown-content p-2 shadow bg-base-100 w-64 border-2 border-gray-50 mt-1 text-white font-normal"
    >
      <button @click="openResetPasswordWindow">
        <li class="rounded">
          <div><font-awesome-icon icon="fa-solid fa-key" />Reset Password</div>
        </li>
      </button>

      <li class="rounded" @mousedown="$emit('deleteUser', username, userId)">
        <div>
          <font-awesome-icon icon="fa-solid fa-user-xmark" />Delete User
        </div>
      </li>

      <li class="rounded" @mousedown="$emit('editMode', 'suspendeduser')">
        <div>
          <font-awesome-icon icon="fa-solid fa-circle-pause" />Un/Suspend User
        </div>
      </li>

      <li class="rounded">
        <div @mousedown="() => $emit('editMode', 'role')">
          <font-awesome-icon icon="fa-solid fa-hammer" />Change Role
        </div>
      </li>

      <li class="rounded">
        <div @mousedown="() => $emit('editMode', 'firstname')">
          <font-awesome-icon icon="fa-solid fa-1" />Edit First Name
        </div>
      </li>

      <li class="rounded">
        <div @mousedown="() => $emit('editMode', 'lastname')">
          <font-awesome-icon icon="fa-solid fa-2" />Edit Last Name
        </div>
      </li>

      <li class="rounded">
        <div @mousedown="$emit('editMode', 'team')">
          <font-awesome-icon icon="fa-solid fa-person-chalkboard" />Edit Team
        </div>
      </li>

      <li class="rounded">
        <div @mousedown="$emit('editMode', 'passwordexpiresutc')">
          <font-awesome-icon icon="fa-solid fa-calendar-days" />Edit Password Expiry Date
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import { directive } from "vue3-click-away";

export default {
  name: "UserActionsDropdown",
  props: {
    buttonClasses: {
      type: String,
      required: true,
    },
    username: {
      type: String,
      required: true,
    },
    userId: {
      type: Number,
      required: false,
    },
  },
  emits: ["editMode", "deleteUser"],
  data() {
    return {
      userActionsDropdownActive: false,
    };
  },
  computed: {
    ...mapGetters(["decodedJWT"]),
  },
  directives: {
    ClickAway: directive,
  },
  methods: {
    toggleUserActionsDropdown() {
      this.userActionsDropdownActive = !this.userActionsDropdownActive;
    },
    openResetPasswordWindow(event) {
      event.preventDefault();
      this.toggleUserActionsDropdown();
      window.open(`/change-password?username=${this.username}`, "_blank");
    },
    onUserActionsDropdownClickAway(event) {
      event.preventDefault();
      this.userActionsDropdownActive = false;
    },
  },
};
</script>

<style>
.zindexadjustment {
  z-index: 1000;
}
</style>
