import { createWebHistory, createRouter } from "vue-router";

import LoginForm from './Pages/LoginForm'
import LogoutPage from './Pages/LogoutPage'
import MainDashboard from './Pages/MainDashboard'
import ChangePassword from './Pages/ChangePassword'
import UserManagement from './Pages/UserManagement'
import TestHosts from './Pages/TestHosts'
import AuditLog from './Pages/AuditLog'
import ConnectionStatus from "@/Pages/ConnectionStatus.vue";

const routes = [
    { path: '/', component: MainDashboard, name: 'Main Dashboard' },
    { path: '/login', component: LoginForm, name: 'Login' },
    { path: '/logout', component: LogoutPage, name: 'Logout' },
    { path: '/change-password', component: ChangePassword, name: 'Change Password' },
    { path: '/user-management', component: UserManagement, name: 'User Management' },
    { path: '/view-audit-log', component: AuditLog, name: 'View Audit Log' },
    { path: '/hosts', component: TestHosts, name: 'Hosts' },
    { path: '/connection-status', component: ConnectionStatus, name: 'Connection Status' },
];

function makeRouter(store) {
    const router = createRouter({
        history: createWebHistory(),
        routes
    });

    const isAuthenticated = () => store.getters.decodedJWT ? true : false;

    router.beforeEach(async (to) => { //Ensure user is logged in
        if (!isAuthenticated() && to.name !== 'Login')
            return { name: 'Login' };    // redirect the user to the login page
    })

    router.beforeEach((to, from, next) => {
        const globalTitle = "DWP TA";

        document.title = to.name ? `${to.name} - ${globalTitle}` : globalTitle;
        next();
    });

    return router;
}

export default makeRouter;