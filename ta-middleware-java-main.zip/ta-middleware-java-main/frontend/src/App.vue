<template>
  <div class="flex-auto" id="app">
    <router-view v-if="statusError === false" />
    <!-- Error fallback -->
    <div v-else-if="statusError !== null">
      <div class="flex items-center justify-center login-container h-screen text-center text-white">

        <div class="shadow-md rounded px-8 pt-6 pb-4 flex-auto max-w-2xl login-main bg-error">
          <h2 class="text-2xl font-bold text-slate-200 pb-4 flex-auto">
            Error:
            <pre>/api/status</pre> returns status
            <pre>{{ statusError.status }}</pre>
          </h2>

          <img srcset="wp-digital-logo-white-outline.png 2x" class="max-w-fit mx-auto rounded-lg"
           aria-hidden="true" alt="DWP Digital logo">

          <div class="mb-6">{{ statusError.data }}</div>

          <hr class="bg-base-100 border-0 h-px rounded-full my-2" />
          <FooterBar />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import FooterBar from "./components/FooterBar.vue";

//Everything renders in here
export default {
  name: "App",
  components: {
    FooterBar
  },
  data: () => ({
    statusError: null,
  }),
  created() {
    this.axios
      .get('/api/status')
      .then(() => this.statusError = false)
      .catch(error => this.statusError = error.response);
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

pre {
  display: inline;
}
</style>
