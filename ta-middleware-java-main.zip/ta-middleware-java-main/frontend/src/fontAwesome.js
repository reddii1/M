import { library } from '@fortawesome/fontawesome-svg-core'; /* import the fontawesome core */
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'; /* import font awesome icon component */

import { faRightFromBracket, faSpinner, faUsers, faBars, faUsersGear, faUserPen, faKey, faEyeSlash, faEye, faChevronDown, faUserXmark, faHammer, faPersonChalkboard, faFloppyDisk, faXmark, faCirclePause, faUserPlus, faArrowLeft, faServer, faListCheck, fa1, fa2, faClipboardUser, faDesktop, faPeopleGroup, faGear, faPlus, faChevronUp, faBarsStaggered, faCircleStop, faCalendarDays, faBan} from '@fortawesome/free-solid-svg-icons'; /* import specific icons */
library.add(faRightFromBracket, faSpinner, faUsers, faBars, faUsersGear, faUserPen, faKey, faEyeSlash, faEye, faChevronDown, faUserXmark, faHammer, faPersonChalkboard, faFloppyDisk, faXmark, faCirclePause, faUserPlus, faArrowLeft, faServer, faListCheck, fa1, fa2, faClipboardUser, faDesktop, faPeopleGroup, faGear, faPlus, faChevronUp, faBarsStaggered, faCircleStop, faCalendarDays, faBan); /* add icons to the library */

export default FontAwesomeIcon;