import { createStore } from 'vuex';
import jwt_decode from "jwt-decode";

const store = createStore({ // Create a new store instance.
    state: () => ({
        JWT: null,
        name: null
    }),
    mutations: {
        initialiseStore: (state) => {
            const sessionJWT = sessionStorage.getItem('JWT')
            if (sessionStorage.getItem('JWT'))
                state.JWT = sessionJWT;
        },
        login: (state, newToken) => {
            state.JWT = newToken;
            sessionStorage.setItem('JWT', newToken);
        },
        logout: (state) => {
            state.JWT = null;
            sessionStorage.removeItem('JWT');
        },
        setName: (state, username) => {
            state.name = username;
            sessionStorage.setItem('username', username);
        }
    },
    getters: {
        decodedJWT: (state) => {
            try {
                const decoded = jwt_decode(state.JWT);

                const currentEpoch = new Date().valueOf() / 1000;

                const beforeNbf = currentEpoch < decoded.nbf;
                const expired = currentEpoch >= decoded.exp;

                if (beforeNbf)
                    throw new Error("Token not valid yet");
                else if (expired)
                    throw new Error("Token expired");

                return decoded;

            } catch (e) {
                console.warn(e);
                return null;
            }
        },
        rawJWT: ({ JWT }) => JWT,
        loggedInUser: ({ name }) => name,
    }
})

export default store;