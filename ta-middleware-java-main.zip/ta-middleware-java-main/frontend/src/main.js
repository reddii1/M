import { createApp } from 'vue'

/* Axios */
import axios from 'axios';
import VueAxios from 'vue-axios';

/* DayJS */
import * as dayjs from 'dayjs'
import * as moment from 'moment'
import duration from 'dayjs/plugin/duration';
dayjs.extend(duration);

import './index.css';
import App from './App.vue';

import createRouter from "./router";
import store from './store';
import FontAwesomeIcon from "./fontAwesome";
import VueClickAway from "vue3-click-away";


const app = createApp({
  extends: App,
  beforeCreate() { this.$store.commit('initialiseStore') }
})
  .use(VueAxios, axios)
  .component('font-awesome-icon', FontAwesomeIcon);

const router = createRouter(store);
app.use(router);
app.use(store);
app.use(VueClickAway);


app.config.globalProperties.$dayjs = dayjs;
app.config.globalProperties.$moment = moment;
app.mount('#app');
