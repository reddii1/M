<template>
  <HeaderBar PAGE_TITLE="Connection Status">
    <div class="flex">
      <div class="md:w-1/2 pr-3 mb-2 md:mb-0">
        <router-link to="/hosts" custom v-slot="{ navigate }">
          <button @click="navigate"
                  class="hover:bg-secondary-focus bg-secondary border-solid rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
                  data-te-toggle="tooltip" data-te-placement="top" title="Hosts">
            <div>
                <span class="text-left block">
                  <font-awesome-icon icon="fa-solid fa-server" />
                </span>
            </div>
          </button>
        </router-link>
      </div>
      <div class="md:w-1/2 pr-3 mb-2 md:mb-0">
        <router-link to="/" custom v-slot="{ navigate }">
          <button
              @click="navigate"
              class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
              data-te-toggle="tooltip"
              data-te-placement="top"
              title="Test Records"
          >
            <div>
              <span class="text-left block">
                <font-awesome-icon icon="fa-solid fa-list-check" />
              </span>
            </div>
          </button>
        </router-link>
      </div>
    </div>
  </HeaderBar>

  <main class="mt-20" v-if="loaded">
    <div
        class="mx-2"
        v-if="decodedJWT?.role.includes('test_admin') || false"
    >
    </div>

    <div class="py-4 pl-2 pr-2">
      <table
          class="border-collapse w-full border border-slate-400 dark:border-slate-500 bg-white dark:bg-slate-800 text-sm shadow-sm text-black dark:text-slate-400"
      >
        <thead class="bg-slate-200 dark:bg-slate-700">
        <tr>
          <table-header text="Service Name" />
          <table-header text="Status" />
        </tr>
        </thead>
        <tr
            v-for="serviceStatus in serviceStatuses"
            :key="serviceStatus.id"
        >
          <table-cell type="text" :text="serviceStatus.service" />
          <table-cell type="text" :text="serviceStatus.status" />
        </tr>
      </table>
    </div>
  </main>

</template>

<script>

import HeaderBar from "@/components/HeaderBar.vue";
import TableHeader from "@/components/Table/TableHeader.vue";
import TableCell from "@/components/Table/TableCell.vue";
const config = {
  headers: {
    "Content-Type": "application/json",
  },
  responseType: "json",
};

export default {
  components: {
    TableHeader,
    TableCell,
    HeaderBar,
  },

  data: () => ({
    loaded: false,
    serviceStatuses: [],
  }),
  created() {
    this.loadStatuses();
  },

  methods: {
    loadStatuses() {
      // const headers = {
      //   Authorization: "Bearer " + this.$store.getters.rawJWT,
      // };

      config.headers.Authorization = this.$store.getters.rawJWT;

          this.axios.get("/api/hosts/getAllServiceStatus", config).then((response) => {
        this.serviceStatuses = response.data;
        this.loaded = true;
      });
    },
  },
}


</script>

<style>
.highlight-row {
  background-color: rgb(226 232 240);
  /* bg-slate-200 */
  color: rgb(0 0 0);
  font-weight: 600;
}

td:nth-child(-n + 3) {
  width: 18%;
}

td:nth-child(n + 4) {
  text-align: center;
  width: min-content !important;
}
</style>