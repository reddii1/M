<template>
  <HeaderBar PAGE_TITLE="Test Records">
    <div class="flex">
      <div class="md:w-1/2 pr-3 mb-2 md:mb-0">
        <router-link to="/hosts" custom v-slot="{ navigate }">
          <button @click="navigate"
            class="hover:bg-secondary-focus bg-secondary border-solid rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
            data-te-toggle="tooltip" data-te-placement="top" title="Hosts">
            <div>
              <span class="text-left block">
                <font-awesome-icon icon="fa-solid fa-server" />
              </span>
            </div>
          </button>
        </router-link>
      </div>
      <div class="md:w-1/2 pr-3 mb-2 md:mb-0">
        <router-link to="/connection-status" custom v-slot="{ navigate }">
          <button
              @click="navigate"
              class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
              data-te-toggle="tooltip"
              data-te-placement="top"
              title="Connection Status"
          >
            <div>
            <span class="text-left block">
              <font-awesome-icon icon="fa-solid fa-bars-staggered" />
            </span>
            </div>
          </button>
        </router-link>
      </div>
      <div class="md:w-1/2 pr-3 mb-2 md:mb-0"
        v-if="decodedJWT?.role.includes('test_admin') || decodedJWT?.role.includes('test_runner') || false">
        <button
          class="hover:bg-secondary-focus bg-secondary border-solid rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
          @click="toggleStopExecutionElement" data-te-toggle="tooltip" data-te-placement="top" title="Stop Execution">
          <div>
            <span class="text-left block">
              <font-awesome-icon icon="fa-solid fa-circle-stop" />
            </span>
          </div>
        </button>
      </div>
    </div>
  </HeaderBar>

  <div class="mt-20 overflow:scroll">
    <div class="w-full min-h-screen flex justify-center items-center" v-if="!loaded">
      <div class="flex min-h-screen w-full items-center justify-center">
        <div style="border-top-color: transparent"
          class="w-16 h-16 border-4 border-blue-400 border-solid rounded-full animate-spin">
          <div class="h-9 w-9 rounded-full"></div>
        </div>
      </div>
    </div>
    <div class="testcasestable pl-2 pr-2" v-else-if="loaded && testCases">
      <div v-if="stopExecutionElementOpen">
        <StopExecutionButton @reloadTestCases="
          fetchTestCases({
            startIndex: 0,
            rowCount: this.rowCountDropdown[0],
          })
          " />
      </div>
      <button v-show="!toggleSearch" @click="showSearch">Search</button>
      <button v-show="toggleSearch" @click="hideSearch">Hide</button>
      <div v-show="toggleSearch">
        <form onsubmit="return this.fetchFilteredTestCases({
            startIndex: 0,
            rowCount: this.rowCountDropdown[0],
            tcidFilter, cidFilter, ridFilter,
                             zephyrFilter, testerIdFilter, atidFilter, atidHostFilter, requestTimeFilter,
                             testProviderFilter, statusFilter, targetExIdFilter, testOutcomeFilter, durationFilter,
                             notesFilter, spoofedCliFilter, targetCliFilter,
          })">
          <input type="text" id="searchInput"  placeholder="TCID"
                 v-model="tcidFilter">
<!--          <table-header text="TCID" />-->

          <input type="text" placeholder="RID" v-model="ridFilter">
          <input type="text" placeholder="CID" v-model="cidFilter">
<!--          <input type="text" placeholder="PID" v-model="pidFilter">-->
          <input type="text" placeholder="Zephyr Execution ID" v-model="zephyrFilter">
          <input type="text" placeholder="Tester ID" v-model="testerIdFilter">
          <input type="text" placeholder="ATID" v-model="atidFilter">
          <input type="text" placeholder="ATID Host" v-model="atidHostFilter">
          <input type="text" placeholder="Request Time" v-model="requestTimeFilter">
          <input type="text" placeholder="Test Provider" v-model="testProviderFilter">
          <input type="text" placeholder="Status" v-model="statusFilter">
          <input type="text" placeholder="Target Exectuion ID" v-model="targetExIdFilter">
          <input type="text" placeholder="Test Outcome" v-model="testOutcomeFilter">
          <input type="text" placeholder="Start Time" v-model="startTimeFilter">
          <input type="text" placeholder="Duration" v-model="durationFilter">
          <input type="text" placeholder="Notes" v-model="notesFilter">
          <input type="text" placeholder="Spoofed CLI" v-model="spoofedCliFilter">
          <input type="text" placeholder="Target CLI" v-model="targetCliFilter">

          <br>
          <input id="clickMe" type="button" value="Search"

                 class="flex items-center justify-center mr-2 px-3 h-8 text-sm font-medium text-black bg-slate-200 rounded-l hover:bg-slate-500 cursor-pointer dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                 @click="fetchFilteredTestCases({
            startIndex: 0,
            rowCount: this.rowCountDropdown[0],
            tcidFilter, cidFilter, ridFilter,
                             zephyrFilter, testerIdFilter, atidFilter, atidHostFilter, requestTimeFilter,
                             testProviderFilter, statusFilter, targetExIdFilter, testOutcomeFilter, durationFilter,
                             notesFilter, spoofedCliFilter, targetCliFilter,
          })" />

          <input id="clickMe" type="button" value="Reset"

                 class="flex items-center justify-center mr-8 px-3 h-8 text-sm font-medium text-black bg-slate-200 border-0 border-l border-gray-700 rounded-r hover:bg-slate-500 cursor-pointer dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                 @click="resetSearch()" />
        </form>
      </div>
      <div>
        <table
          class="border-collapse border border-slate-400 dark:border-slate-500 bg-white dark:bg-slate-800 text-sm shadow-sm mx-auto text-black dark:text-white">
          <thead class="bg-slate-200 dark:bg-slate-700">
            <tr>
              <table-header text="TCID" />
              <table-header text="RID" />
              <table-header text="CID" />
              <table-header text="PID" />
              <table-header text="Zephyr Execution ID" />
              <table-header text="Tester ID" />
              <table-header text="ATID" />
              <table-header text="ATID Host" />
              <table-header text="Request Time" />
              <table-header text="Test Provider" />
              <table-header text="Status" />
              <table-header text="Target Execution ID" />
              <table-header text="Test Outcome" />
              <table-header text="Start Time" />
              <table-header text="Duration" />
              <table-header text="Notes" />
              <table-header text="Spoofed CLI" />
              <table-header text="Target CLI" />
              <table-header text="Cycle Name" />
              <table-header text="Release Name" />
              <table-header text="Project Name" />
              <table-header text="Test Run By User" />
              <table-header text="Cycle Phase Name" />
              <table-header text="Test Case Name" />
              <table-header text="Project ID" />
            </tr>
          </thead>
          <tbody>
            <tr v-for="testCase in testCases" :key="testCase.id">
              <table-cell type="text" :text="testCase.tcid" />
              <table-cell type="text" :text="testCase.rid" />
              <table-cell type="text" :text="testCase.cid" />
              <table-cell type="text" :text="testCase.cpid" />
              <table-cell type="text" :text="testCase.eid" />
              <table-cell type="text" :text="testCase.testerId" />
              <table-cell type="text" :text="testCase.atid" />
              <table-cell type="text" :text="testCase.atidHost" />
              <table-cell type="datetime" :text="testCase.requestTime" />
              <table-cell type="text" :text="testCase.testProvider" />
              <table-cell type="text" :text="testCase.orchestrationStatus" />
              <table-cell class="executionIDAdjustment" type="JSONField" :text="testCase.connectorData"
                :jsonField="'ExecutionId'" />
              <table-cell type="text" :text="testCase.testOutcome" />
              <table-cell type="datetime" :text="testCase.startTime" />
              <table-cell type="duration" :text="testCase.duration" />
              <table-cell type="text" :text="testCase.notes" />
              <table-cell type="text" :text="testCase.spoofCli" />
              <table-cell type="text" :text="testCase.targetCli" />
              <table-cell type="text" :text="testCase.cidname" />
              <table-cell type="text" :text="testCase.ridname" />
              <table-cell type="text" :text="testCase.projectname" />
              <table-cell type="text" :text="testCase.startedby" />
              <table-cell type="text" :text="testCase.cpname" />
              <table-cell type="text" :text="testCase.tcidname" />
              <table-cell type="text" :text="testCase.pid" />
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div v-if="!testCases" class="w-full mt-10 flex justify-center items-center">
      <div>Test Records Not Found</div>
    </div>
  </div>
  <div class="paginationDiv">
    <TablePagination :ITEMS="testCases" :dropdownValues="rowCountDropdown" :defaultRowCount="this.rowCountDropdown[0]"
      @reloadItems="fetchTestCases" />
  </div>
  <div class="aboutVersionDiv">
    <AboutVersion />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import HeaderBar from "../components/HeaderBar.vue";
import StopExecutionButton from "../components/StopExecutionButton.vue";
import TableCell from "../components/Table/TableCell.vue";
import TableHeader from "../components/Table/TableHeader.vue";
import TablePagination from "../components/Table/TablePagination.vue";
import AboutVersion from "@/Pages/AboutVersion.vue";

export default {
  components: {
    AboutVersion,
    TableHeader,
    TableCell,
    TablePagination,
    HeaderBar,
    StopExecutionButton,
  },
  name: "MainDashboard",
  computed: {
    ...mapGetters(["decodedJWT"]),
  },
  data: () => ({
    loaded: false,
    testCases: [],
    stopExecutionElementOpen: false,
    searchFilter:'',
    toggleSearch:false,
  }),
  created() {
    this.rowCountDropdown = [25, 50, 100];
    this.fetchTestCases({ startIndex: 0, rowCount: this.rowCountDropdown[0] });
  },
  methods: {
    fetchTestCases({ startIndex, rowCount }) {
      this.axios
        .get("/api/testcases/find", {
          headers: {
            Authorization: "Bearer " + this.$store.getters.rawJWT,
          },
          params: {
            startIndex: startIndex,
            rowCount: rowCount,
          },
        })
        .then((response) => {
          this.testCases = response.data;
          this.loaded = true;
        });
    },

    // toggle() {
    //   this.toggleSearch = !this.toggleSearch;
    // },
    showSearch() {
      this.toggleSearch = true;
    },
    hideSearch() {
      this.toggleSearch = false;
    },
    resetSearch() {
      this.tcidFilter ='';
      this.cidFilter ='';
      this.ridFilter ='';
      this.zephyrFilter ='';
      this.testerIdFilter ='';
      this.atidFilter ='';
      this.atidHostFilter ='';
      this.requestTimeFilter ='';
      this.testProviderFilter ='';
      this.statusFilter ='';
      this.targetExIdFilter ='';
      this.testOutcomeFilter ='';
      this.durationFilter ='';
      this.notesFilter ='';
      this.spoofedCliFilter ='';
      this.targetCliFilter ='';

      this.fetchTestCases({ startIndex: 0, rowCount: this.rowCountDropdown[0] });
    },

    fetchFilteredTestCases({ startIndex, rowCount,
                             tcidFilter ='',
                             cidFilter ='',
                             ridFilter ='',
                             zephyrFilter ='',
                             testerIdFilter ='',
                             atidFilter ='',
                             atidHostFilter ='',
                             requestTimeFilter ='',
                             testProviderFilter ='',
                             statusFilter ='',
                             targetExIdFilter ='',
                             testOutcomeFilter ='',
                             durationFilter ='',
                             notesFilter ='',
                             spoofedCliFilter ='',
                             targetCliFilter =''}) {
      this.axios
          .get("/api/testcases/filter", {
            headers: {
              Authorization: "Bearer " + this.$store.getters.rawJWT,
            },
            params: {
              startIndex,
              rowCount,
              tcidFilter,
              cidFilter,
              ridFilter,
              zephyrFilter,
              testerIdFilter,
              atidFilter,
              atidHostFilter,
              requestTimeFilter,
              testProviderFilter,
              statusFilter,
              targetExIdFilter,
              testOutcomeFilter,
              durationFilter,
              notesFilter,
              spoofedCliFilter,
              targetCliFilter,
            },
          })

          .then((response) => {
            this.testCases = response.data;
            this.loaded = true;
          });
    },

    toggleStopExecutionElement(event) {
      event.preventDefault();
      this.stopExecutionElementOpen = !this.stopExecutionElementOpen;
    },
  },
};
</script>

<style>
.paginationDiv {
  background-color: #2c3d4f;
  width: 50%;
  right: 0;
  bottom: 0;
  position: fixed;
}
.aboutVersionDiv {
  background-color: #2c3d4f;
  width: 50%;
  left: 0;
  bottom: 0;
  position: fixed;
}

.executionIDAdjustment {
  white-space: nowrap;
}

.testcasestable {
  margin-bottom: 60px;
}
</style>
