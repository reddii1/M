<template>
  <div style="padding-left: 10px">
    <label
        for="aboutVersionNumber"
        class="block mb-2 text-sm font-large text-white dark:text-white pagerLabel"
    >Version {{versionNumber}} built on {{buildTime}}</label>
  </div>

</template>

<script>

export default {
  data: () => ({
    versionNumber: '9.9.9',
    buildTime: '10/10/2024',
  }),
  created() {
    this.getVersionNumber();
  },
  methods: {
    getVersionNumber() {
      const headers = {
        Authorization: "Bearer " + this.$store.getters.rawJWT,
      };

      this.axios.get("/api/about/version", { headers }).then((response) => {
        this.versionNumber = response.data.version;
        this.buildTime = response.data.timeStamp;
      });
    }
  }
}

</script>

<style scoped>

</style>