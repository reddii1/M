<template>
  <HeaderBar PAGE_TITLE="Hosts">
    <div class="flex">
      <div class="md:w-1/2 pr-3 mb-2 md:mb-0">
        <router-link to="/" custom v-slot="{ navigate }">
        <button
            @click="navigate"
            class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
            data-te-toggle="tooltip"
            data-te-placement="top"
            title="Test Records"
        >
          <div>
          <span class="text-left block">
            <font-awesome-icon icon="fa-solid fa-list-check" />
          </span>
          </div>
        </button>
      </router-link>
      </div>
      <div class="md:w-1/2 pr-3 mb-2 md:mb-0">
        <router-link to="/connection-status" custom v-slot="{ navigate }">
          <button
              @click="navigate"
              class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
              data-te-toggle="tooltip"
              data-te-placement="top"
              title="Connection Status"
          >
            <div>
            <span class="text-left block">
              <font-awesome-icon icon="fa-solid fa-bars-staggered" />
            </span>
            </div>
          </button>
        </router-link>
      </div>
    </div>
  </HeaderBar>
  <main class="mt-20" v-if="loaded">
    <div
      class="mx-2"
      v-if="decodedJWT?.role.includes('test_admin') || false"
    >
      <CreateHostModal
        :testProviders="testProviders"
        @reloadHosts="loadHosts"
      />
    </div>

    <div class="py-4 pl-2 pr-2">
      <table
        class="border-collapse w-full border border-slate-400 dark:border-slate-500 bg-white dark:bg-slate-800 text-sm shadow-sm text-black dark:text-slate-400"
      >
        <thead class="bg-slate-200 dark:bg-slate-700">
          <tr>
            <table-header text="Zephyr Host ID" />
            <table-header text="Host Name" />
            <table-header text="Status" />
            <table-header text="Project Root" />
            <table-header text="Team Name" />
            <table-header text="Test Provider" />
            <table-header
            v-if="decodedJWT?.role.includes('test_admin') || false"
              text="Username"
            />
            <table-header
            v-if="decodedJWT?.role.includes('test_admin') || false"
              text="Password"
            />
            <table-header
            v-if="decodedJWT?.role.includes('test_admin') || false"
              text="Host Actions"
            />
          </tr>
        </thead>
        <tr
          v-for="testHost in testHosts"
          :key="testHost.id"
          :class="{
            'highlight-row': testHost.id == editing.itemId,
          }"
        >
          <table-cell
            v-if="
              testHost.id == editing.itemId && editing.field == 'zephyrhostid'
            "
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemRequired="true"
              :itemId="testHost.id"
              field="zephyrhostid"
              type="integer"
              :startingValue="testHost.zephyrHostId"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell type="text" :text="testHost.zephyrHostId" v-else />

          <table-cell
            v-if="testHost.id == editing.itemId && editing.field == 'hostname'"
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemRequired="true"
              :itemId="testHost.id"
              field="hostname"
              type="freetext"
              :startingValue="testHost.hostName"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell type="text" :text="testHost.hostName" v-else />

          <table-cell
            v-if="
              testHost.id == editing.itemId && editing.field == 'hoststatus'
            "
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemId="testHost.id"
              field="hoststatus"
              type="options"
              :options="AVAILABILITIES"
              :startingValue="testHost.hostStatus"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell type="text" :text="testHost.hostStatus" v-else />

          <table-cell
            v-if="
              testHost.id == editing.itemId && editing.field == 'projectsroot'
            "
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemId="testHost.id"
              field="projectsroot"
              type="freetext"
              :startingValue="testHost.projectsRoot"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell type="text" :text="testHost.projectsRoot" v-else />

          <table-cell
            v-if="testHost.id == editing.itemId && editing.field == 'teamname'"
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemId="testHost.id"
              field="teamname"
              type="freetext"
              :startingValue="testHost.teamName"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell type="text" :text="testHost.teamName" v-else />

          <table-cell
            v-if="
              testHost.id == editing.itemId && editing.field == 'testprovider'
            "
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemId="testHost.id"
              field="testprovider"
              type="testProviderOptions"
              :options="testProviders"
              :startingValue="testHost.testProvider"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell type="text" :text="testHost.testProvider" v-else />

          <table-cell
            v-if="testHost.id == editing.itemId && editing.field == 'username'"
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemId="testHost.id"
              field="username"
              type="freetext"
              :startingValue="testHost.username"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell
            v-else-if="decodedJWT?.role.includes('test_admin') || false"
            type="text"
            :text="testHost.username"
          />

          <table-cell
            v-if="testHost.id == editing.itemId && editing.field == 'password'"
          >
            <TableCellEdit
              :itemName="testHost.hostName"
              :itemId="testHost.id"
              field="password"
              type="freetext"
              :startingValue="testHost.password"
              @cancel="cancelEditing"
              @save="saveField"
            />
          </table-cell>
          <table-cell
            v-else-if="decodedJWT?.role.includes('test_admin') || false"
            type="password"
            :text="testHost.password"
          />

          <table-cell
            v-if="decodedJWT?.role.includes('test_admin') || false"
          >
            <HostActionsDropdown
              :hostname="testHost.hostName"
              :hostId="testHost.id"
              @editMode="
                (field) => editMode(testHost.hostName, field, testHost.id)
              "
              @deleteHost="deleteHost"
              buttonClasses="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 items-center justify-center"
            />
          </table-cell>
        </tr>
      </table>
    </div>
  </main>
</template>

<script>
import TableHeader from "../components/Table/TableHeader.vue";
import TableCell from "../components/Table/TableCell.vue";
import HeaderBar from "../components/HeaderBar.vue";
import TableCellEdit from "../components/Table/TableCellEdit.vue";
import HostActionsDropdown from "@/components/HostActionsDropdown.vue";
import CreateHostModal from "@/components/CreateHostModal.vue";
import { mapGetters } from "vuex";

const config = {
  headers: {
    "Content-Type": "application/json",
  },
  responseType: "json",
};

export default {
  components: {
    TableHeader,
    TableCell,
    TableCellEdit,
    HeaderBar,
    HostActionsDropdown,
    CreateHostModal,
  },
  name: "TestHosts",
  computed: {
    ...mapGetters(["decodedJWT"]),
  },
  data: () => ({
    loaded: false,
    testHosts: [],
    editing: {
      itemName: null,
      field: null,
      itemId: null,
    },
  }),
  created() {
    this.testProviders = ["TestComplete", "Nectar"];
    this.AVAILABILITIES = ["Available", "Unavailable"];
    this.loadHosts();
  },
  methods: {
    loadHosts() {
      const headers = {
        Authorization: "Bearer " + this.$store.getters.rawJWT,
      };

      this.axios.get("/api/hosts/getAll", { headers }).then((response) => {
        this.testHosts = response.data;
        this.loaded = true;
      });
    },
    editMode(itemName, field, itemId) {
      this.editing = { ...this.editing, field, itemName, itemId };
    },
    cancelEditing() {
      this.editing = { itemName: null, field: null, itemId: null };
    },
    async deleteHost(itemName, itemId) {
      if (
        !window.confirm(
          `You are going to delete Host ${itemName}. Are you sure?`
        )
      )
        return;

      //Warn admins before deleting themselves and handle gracefully if they do
      await this.axios
        .delete(`/api/hosts/${itemId}`, {
          headers: {
            Authorization: "Bearer " + this.$store.getters.rawJWT,
          },
          data: {
            host: itemName,
            loggedInUser: sessionStorage.getItem("username"),
          },
        })
        .then(() => {
          this.loadHosts(); //We can do a nice succinct AJAX refresh
        })
        .catch((err) => {
          console.error(err);
          window.alert(`Error on save: ${err.message}`);
        });
    },
    async saveField(itemName, field, value, itemId) {
      this.loaded = false; //Because we are going to reload the users after save is complete
      this.cancelEditing();

      config.headers.Authorization = "Bearer " + this.$store.getters.rawJWT;

      await this.axios
        .put(
          `/api/hosts/${itemId}/${field}`,
          {
            value: value,
            host: itemName,
            loggedInUser: sessionStorage.getItem("username"),
          },
          config
        )
        .then(() => {
          this.loadHosts();
        })
        .catch((err) => {
          console.error(err);
          window.alert(`Error on save: ${err.message}`);
          this.loaded = true;
        });
    },
  },
};
</script>

<style>
.highlight-row {
  background-color: rgb(226 232 240);
  /* bg-slate-200 */
  color: rgb(0 0 0);
  font-weight: 600;
}

td:nth-child(-n + 3) {
  width: 18%;
}

td:nth-child(n + 4) {
  text-align: center;
  width: min-content !important;
}
</style>
