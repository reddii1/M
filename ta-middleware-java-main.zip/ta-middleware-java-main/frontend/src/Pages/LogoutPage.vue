<template>
    <div class="flex items-center justify-center login-container h-screen">

        <div class="shadow-md rounded px-8 pt-6 pb-4 flex-auto max-w-xl login-main bg-accent">
            <h2 class="text-2xl font-bold text-slate-200 pb-4 flex-auto text-center"
                v-if="this.$store.getters.rawJWT == null">Logged out!</h2>
            <img srcset="wp-digital-logo-white-outline.png 2x" class="max-w-fit mx-auto"
                :class="{ 'motion-safe:animate-pulse': inProgress }" aria-hidden="true" alt="DWP Digital logo" />

        </div>
</div>
</template>
  
<script>
export default {
    name: 'LogoutPage',
    async mounted() {
        await this.$store.commit('logout');
        this.inProgress = false;
        setTimeout(() => this.$router.push('/'), 2500);
    },
    data() {
        return {
            inProgress: true
        };
    },
}
</script>
