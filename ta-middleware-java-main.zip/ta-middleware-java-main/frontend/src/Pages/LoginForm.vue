<template>
  <div class="flex items-center justify-center login-container h-screen text-center text-white">

    <div class="shadow-md rounded px-8 pt-6 pb-4 flex-auto max-w-2xl login-main bg-accent">
      <h2 class="text-2xl font-bold text-slate-200 pb-4 flex-auto">Login to DWP Test Orchestration Middleware
      </h2>

      <img srcset="wp-digital-logo-white-outline.png 2x" class="max-w-fit mx-auto rounded-lg"
        :class="{ 'motion-safe:animate-pulse': authInProgress }" aria-hidden="true" alt="DWP Digital logo">

      <form class="login-form" @submit="login">

        <div class="mb-6">
          <label class="block text-base font-bold mb-2 text-left" for="username">Username</label>
          <input type="text" autocomplete="username" name="username" id="username"
            class="shadow appearance-none border rounded w-full py-2 px-3 text-black" v-model="username"
            :disabled="authInProgress" />
        </div>

        <div class="mb-3">
          <label class="block text-base font-bold mb-2 text-left" for="password">Password</label>
          <AccessiblePassword :disabled="authInProgress" v-model="password" name="password" aria-describedby="error" />
        </div>

        <div class="mb-3 mx-0">
          <span class="block text-base font-bold text-error-content" id="error">{{ errorMsg || "&nbsp;" }}</span>
        </div>

        <div class="mb-6 flex items-center justify-between">
          <button class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 
          w-48 px-4 py-2 rounded" type="submit" :disabled="authInProgress">Sign In</button>

          <font-awesome-icon icon="fa-solid fa-spinner" class="animate-spin" role="status" v-if="authInProgress" />

          <button class="bg-slate-200 hover:bg-slate-300 inline-block rounded border
                                                      font-medium align-baseline text-secondary text-center
                                                      px-4 py-2 w-48 " @click="forgotPW">Forgot or Expired
            Password?</button>
        </div>

      </form>
      <hr class="bg-base-100 border-0 h-px rounded-full my-2" />
      <FooterBar />
    </div>
  </div>
</template>

<script>
import FooterBar from "../components/FooterBar.vue";
import AccessiblePassword from "../components/AccessiblePassword.vue";

const config = {
  headers: {
    'Content-Type': 'text/plain'
  },
  responseType: 'json'
};

const REFRESH_GRACE_SECONDS = 10;

async function doLogin(name) {
  let { JWT, passwordExpiry } = (await this.axios.post(`/api/users/${name}/login`, this.password, config)).data;
  await this.$store.commit('login', JWT);
  await this.$store.commit('setName', name);
  passwordExpiry = Date.parse(passwordExpiry);

  const { exp } = this.$store.getters.decodedJWT; // Get JWT expiry time epoch

  const currentEpoch = new Date().valueOf() / 1000;
  const secondsUntilRefresh = Math.floor(exp - currentEpoch) - REFRESH_GRACE_SECONDS;
  console.log(`Will refresh JWT login in ${secondsUntilRefresh} seconds.`);

  setTimeout(() => doLogin.bind(this)(name), secondsUntilRefresh * 1000);

  const passwordDaysLeft = Math.ceil((passwordExpiry - new Date()) / (1000 * 3600 * 24));
  console.log({ passwordDaysLeft });

  if (passwordDaysLeft <= 7)
    window.alert(`Your password will expire in ${passwordDaysLeft} day${passwordDaysLeft == 1 ? '' : 's'}. Please change it soon or you will be locked out the system!`);
}


export default {
  name: 'LoginForm',
  components: {
    AccessiblePassword,
    FooterBar
  },
  data() {
    return {
      username: "",
      password: "",
      passwordAccessible: false,
      authInProgress: false,
      errorMsg: null
    };
  },
  methods: {
    async login(event) {
      event.preventDefault();
      this.errorMsg = null;
      this.authInProgress = true;

      const [name] = this.username.split(/(?<=^.+)@(?=[^@]+$)/); //Strip out @ email domain
      this.username = name.trim();

      try {
        await doLogin.bind(this)(name);

        this.$router.push('/');
      }
      catch (e) {
        console.error(e);
        if (e.response?.status)
          this.errorMsg = e.response?.data?.message
        else
          this.errorMsg = e.message;
      }
      finally {
        this.authInProgress = false;
      }
    },
    forgotPW(event) {
      event.preventDefault();
      this.errorMsg = 'Please contact an Administrator to reset';
    }
  }
}
</script>

<style>
.fa-icon-std-size {
  width: 20px;
  padding-top: 4px;
  /* FA icon height is 16px. */
}
</style>