<template>
  <HeaderBar PAGE_TITLE="Users">
    <router-link to="/" custom v-slot="{ navigate }">
      <button @click="navigate"
        class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
        data-te-toggle="tooltip" data-te-placement="top" title="Test Records">
        <div>
          <span class="text-left block">
            <font-awesome-icon icon="fa-solid fa-list-check" />
          </span>
        </div>
      </button>
    </router-link>
  </HeaderBar>

  <main class="mt-20" v-if="loaded">
    <div class="mx-2">
      <CreateUserModal :ROLES="ROLES" @reloadUsers="loadUsers" />
    </div>

    <div class="py-4 pl-2 pr-2">
      <table
        class="w-full border-collapse border border-slate-400 dark:border-slate-500 bg-white dark:bg-slate-800 text-sm shadow-sm text-black dark:text-slate-400">
        <thead class="bg-slate-200 dark:bg-slate-700">
          <tr>
            <table-header text="Username" />
            <table-header text="First Name" />
            <table-header text="Last Name" />
            <table-header text="Role" />
            <table-header text="Team" />
            <table-header text="Account Status" />
            <table-header text="Password Expires" />
            <table-header text="User Actions" />
          </tr>
        </thead>
        <tr v-for="userRow in allUsers" :key="userRow.id" :class="{
      'highlight-row': userRow.id == editing.itemId,
    }">
          <table-cell type="text" :text="userRow.username" />

          <table-cell v-if="userRow.id == editing.itemId && editing.field == 'firstname'">
            <TableCellEdit :itemRequired="true" :itemName="userRow.username" field="firstname" type="freetext"
              :startingValue="userRow.firstName" :itemId="userRow.id" @cancel="cancelEditing" @save="saveField" />
          </table-cell>
          <table-cell type="text" :text="userRow.firstName" v-else />

          <table-cell v-if="userRow.id == editing.itemId && editing.field == 'lastname'">
            <TableCellEdit :itemRequired="true" :itemName="userRow.username" field="lastname" type="freetext"
              :startingValue="userRow.lastName" :itemId="userRow.id" @cancel="cancelEditing" @save="saveField" />
          </table-cell>
          <table-cell type="text" :text="userRow.lastName" v-else />

          <table-cell v-if="userRow.id == editing.itemId && editing.field == 'role'">
            <TableCellEdit :itemName="userRow.username" field="role" type="options" :startingValue="userRow.role"
              :itemId="userRow.id" :options="ROLES" @cancel="cancelEditing" @save="saveField" />
          </table-cell>
          <table-cell type="text" :text="userRow.role" v-else />

          <table-cell v-if="userRow.id == editing.itemId && editing.field == 'team'">
            <TableCellEdit :itemRequired="true" :itemName="userRow.username" field="team" type="freetext"
              :startingValue="userRow.team" :itemId="userRow.id" @cancel="cancelEditing" @save="saveField" />
          </table-cell>
          <table-cell type="text" :text="userRow.team" v-else />

          <table-cell v-if="userRow.id == editing.itemId && editing.field == 'suspendeduser'
      ">
            <TableCellEdit :itemName="userRow.username" field="suspendeduser" type="options" :options="[
      { name: 'Suspended', value: 'true' },
      { name: 'Current', value: 'false' },
    ]" :startingValue="String(userRow.suspendedUser)" :itemId="userRow.id" @cancel="cancelEditing" @save="saveField" />
          </table-cell>
          <table-cell type="text" :text="userRow.suspendedUser ? 'Suspended' : 'Current'" v-else />

          <table-cell v-if="userRow.id == editing.itemId &&
      editing.field == 'passwordexpiresutc'
      ">
            <TableCellEdit :itemRequired="true" :itemName="userRow.username" field="passwordexpiresutc" type="datetime"
              :startingValue="userRow.passwordExpiresUtc" :itemId="userRow.id" @cancel="cancelEditing"
              @save="saveField" />
          </table-cell>
          <table-cell type="datetime" :text="userRow.passwordExpiresUtc" v-else />

          <table-cell>
            <UserActionsDropdown :username="userRow.username" :userId="userRow.id" @editMode="(field) => editMode(userRow.username, field, userRow.id)
      " @deleteUser="deleteUser"
              buttonClasses="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 items-center justify-center" />
          </table-cell>
        </tr>
      </table>
    </div>
  </main>
</template>

<script>
import CreateUserModal from "@/components/CreateUserModal.vue";
import UserActionsDropdown from "@/components/UserActionsDropdown.vue";
import HeaderBar from "../components/HeaderBar.vue";
import TableCell from "../components/Table/TableCell.vue";
import TableCellEdit from "../components/Table/TableCellEdit.vue";
import TableHeader from "../components/Table/TableHeader.vue";

const config = {
  headers: {
    "Content-Type": "application/json",
  },
  responseType: "json",
};

export default {
  components: {
    TableHeader,
    TableCell,
    TableCellEdit,
    HeaderBar,
    UserActionsDropdown,
    CreateUserModal,
  },
  name: "UserManagement",
  data: () => ({
    loaded: false,
    allUsers: [],
    editing: {
      itemName: null,
      field: null,
      itemId: null,
    },
  }),
  created() {
    this.ROLES = ["test_admin", "test_runner", "test_viewer"];
    this.loadUsers();
  },
  methods: {
    loadUsers() {
      const headers = {
        Authorization: "Bearer " + this.$store.getters.rawJWT,
      };

      this.axios.get("/api/users/getAll", { headers }).then((response) => {
        this.allUsers = response.data;
        this.loaded = true;
      });
    },
    editMode(itemName, field, itemId) {
      this.editing = { ...this.editing, field, itemName, itemId };
    },
    cancelEditing() {
      this.editing = { itemName: null, field: null, itemId: null };
    },
    async deleteUser(itemName, itemId) {
      if (!window.confirm(`You are going to delete user ${itemName}. Are you sure?`)) {
        return;
      }
      let logoutAfter = false;
      //Warn admins before deleting themselves and handle gracefully if they do
      if (itemName == this.$store.getters.decodedJWT?.sub) {
        if (!window.confirm(
          "You are going to delete yourself. This will force logout. Are you sure you REALLY want to do this?"
        )) {
          return;
        }
        logoutAfter = true;
      }

      await this.axios
        .delete(`/api/users/${itemId}`, {
          headers: {
            Authorization: "Bearer " + this.$store.getters.rawJWT,
          },
          data: {
            user: itemName,
            loggedInUser: sessionStorage.getItem("username"),
          },
        })
        .then(() => {
          if (logoutAfter) this.$router.push("/logout");
          else this.loadUsers(); //We can do a nice succinct AJAX refresh
        })
        .catch((err) => {
          console.error(err);
          window.alert(`Error on save: ${err.message}`);
        });
    },
    async saveField(itemName, field, value, itemId) {
      this.loaded = false; //Because we are going to reload the users after save is complete
      this.cancelEditing();

      config.headers.Authorization = "Bearer " + this.$store.getters.rawJWT;

      await this.axios
        .put(
          `/api/users/${itemId}/${field}`,
          {
            value: value,
            user: itemName,
            loggedInUser: sessionStorage.getItem("username"),
          },
          config
        )
        .then(() => {
          this.loadUsers();
        })
        .catch((err) => {
          console.error(err);
          window.alert(`Error on save: ${err.message}`);
          this.loaded = true;
        });
    },
  },
};
</script>

<style>
.highlight-row {
  background-color: rgb(226 232 240);
  /* bg-slate-200 */
  color: rgb(0 0 0);
  font-weight: 600;
}

td:nth-child(-n + 3) {
  width: 18%;
}

td:nth-child(n + 4) {
  text-align: center;
  width: min-content !important;
}
</style>
