<template>
  <div class="flex items-center justify-center login-container h-screen">
    <div
      class="shadow-md rounded px-8 pt-6 pb-4 flex-auto max-w-xl login-main bg-accent"
    >
      <h2 class="text-2xl font-bold text-slate-200 pb-4 flex-auto text-center">
        Change Password for DWP Test Orchestration UI
      </h2>

      <form class="login-form text-white" @submit="changePW">
        <div class="mb-3">
          <input
            type="text"
            class="hidden"
            autocomplete="username"
            name="username"
            id="username"
            v-model="username"
          />

          <label class="block text-sm font-bold mb-2" for="password"
            >Password</label
          >
          <AccessiblePassword
            :disabled="inProgress"
            v-model="password"
            name="password"
            aria-describedby="error"
          />
        </div>

        <div class="mb-3 mx-0">
          <span
            class="block text-base font-bold text-error-content"
            id="error"
            >{{ errorMsg || "&nbsp;" }}</span
          >
        </div>

        <div class="flex items-center justify-between py-2 bg-blue">
          <button
            class="hover:bg-primary-focus bg-primary rounded font-bold text-white disabled:opacity-50 w-40 px-2 py-2"
            type="submit"
            :disabled="inProgress"
          >
            Update Password
          </button>
          <button
            class="hover:bg-primary-focus bg-primary rounded font-bold text-white disabled:opacity-50 w-40 px-2 py-2"
            @click="cancelChangePassword"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import AccessiblePassword from "../components/AccessiblePassword.vue";

export default {
  name: "ChangePassword",
  components: {
    AccessiblePassword,
  },
  data: () => ({
    username: "",
    password: "",
    inProgress: false,
    errorMsg: null,
  }),
  created() {
    this.username =
      this.$route?.query?.username || this.$store.getters.decodedJWT.sub;
  },
  methods: {
    async changePW(event) {
      event.preventDefault();
      this.inProgress = true;
      this.errorMsg = null;

      try {
        const config = {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + this.$store.getters.rawJWT,
          },
          responseType: "json",
        };
        await this.axios.post(
          `/api/users/${this.username}/password`,
          {
            password: this.password,
            loggedInUser: sessionStorage.getItem("username"),
          },
          config
        );
        window.close();
      } catch (e) {
        console.error(e);
        if (e.response?.status) this.errorMsg = e.response?.data?.message;
        else this.errorMsg = e.message;
      } finally {
        this.inProgress = false;
      }
    },
    cancelChangePassword(event) {
      event.preventDefault();
      window.close();
    },
  },
};
</script>
