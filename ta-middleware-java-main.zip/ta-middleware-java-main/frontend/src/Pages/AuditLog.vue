<template>
  <HeaderBar PAGE_TITLE="Audit Log">
    <router-link to="/" custom v-slot="{ navigate }">
      <button @click="navigate"
        class="hover:bg-secondary-focus bg-secondary rounded font-bold text-white disabled:opacity-50 py-2 px-4 flex"
        data-te-toggle="tooltip" data-te-placement="top" title="Test Records">
        <div>
          <span class="text-left block">
            <font-awesome-icon icon="fa-solid fa-list-check" />
          </span>
        </div>
      </button>
    </router-link>
  </HeaderBar>

  <div class="mt-20 py-2 overflow-auto">
    <div class="w-full min-h-screen flex justify-center items-center" v-if="!loaded">
      <div class="flex min-h-screen w-full items-center justify-center">
        <div style="border-top-color: transparent"
          class="w-16 h-16 border-4 border-blue-400 border-solid rounded-full animate-spin">
          <div class="h-9 w-9 rounded-full"></div>
        </div>
      </div>
    </div>
    <div class="auditlogtable pl-2 pr-2" v-if="loaded && auditLog">
      <table
        class="border-collapse border border-slate-400 dark:border-slate-500 bg-white dark:bg-slate-800 text-sm shadow-sm mx-auto text-black dark:text-white">
        <thead class="bg-slate-200 dark:bg-slate-700">
          <tr>
            <table-header text="Username" />
            <table-header text="Action" />
            <table-header text="Details" />
            <table-header text="Date" />
          </tr>
        </thead>
        <tr v-for="log in auditLog" :key="log.id">
          <table-cell type="text" :text="log.username" />
          <table-cell type="text" :text="log.action" />
          <table-cell type="text" :text="log.details" />
          <table-cell type="datetime" :text="log.date" />
        </tr>
      </table>
    </div>
    <div v-if="!auditLog" class="w-full mt-10 flex justify-center items-center">
      <div>Audit Log Entries Not Found</div>
    </div>
  </div>
  <div class="paginationDiv">
    <TablePagination :ITEMS="auditLog" :dropdownValues="rowCountDropdown" :defaultRowCount="this.rowCountDropdown[0]"
      @reloadItems="fetchAuditLog" />
  </div>
</template>

<script>
import HeaderBar from "../components/HeaderBar.vue";
import TableCell from "../components/Table/TableCell.vue";
import TableHeader from "../components/Table/TableHeader.vue";
import TablePagination from "../components/Table/TablePagination.vue";

export default {
  components: {
    TableHeader,
    TableCell,
    HeaderBar,
    TablePagination
  },
  name: "AuditLog",
  data: () => ({
    loaded: false,
    auditLog: [],
  }),
  created() {
    this.rowCountDropdown = [25, 50, 100];
    this.fetchAuditLog({ startIndex: 0, rowCount: this.rowCountDropdown[0] });
  },
  methods: {
    fetchAuditLog({ startIndex, rowCount }) {
      this.axios
        .get("/api/auditlog", {
          headers: {
            Authorization: "Bearer " + this.$store.getters.rawJWT,
          },
          params: {
            startIndex: startIndex,
            rowCount: rowCount,
          },
        })
        .then((response) => {
          this.auditLog = response.data;
          this.loaded = true;
        });
    }
  },
};
</script>

<style>
.paginationDiv {
  background-color: #2c3d4f;
  width: 100%;
  bottom: 0;
  position: fixed;
}

.auditlogtable {
  margin-bottom: 60px;
}
</style>
