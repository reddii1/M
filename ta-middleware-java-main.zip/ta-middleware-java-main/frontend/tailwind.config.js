module.exports = {
    purge: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
    darkMode: false, // or 'media' or 'class'
    theme: {
        extend: {},
    },
    variants: {
        extend: {},
    },
    plugins: [require("daisyui")],

    daisyui: {
        // styled: false,
        // themes: false,
        // base: false,
        themes: [
          {
            light: {
              'primary': '#0b0c0c',
              'secondary': "#505a5f",
              'accent': '#1d70b8',
              // 'accent-focus': '#37807b',
              'neutral': "#b1b4b6",
              'base-100': '#2c3e50',
              // 'base-content': '#0b0c0c',
              'success': '#00703c',
              'error': '#d4351c'
            },
          },
        ],
      },
}