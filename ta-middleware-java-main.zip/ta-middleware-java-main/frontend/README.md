# ui

# Features
- Written in Vue 3
  - And Vue Router to make this a SPA 
  - and Vuex for state management (especially of user login data by way of JWT tokens)
- Dark mode support! (but only when the user wants it/ browser requests this)
  - Otherwise an accessible colour scheme
  - Uses Daisy UI to support a consistent colour scheme/ widgets
- Accessible password boxes (show/ hide feature)
- FontAwesome vector icons (infinitely zoom-able without pixelation)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
